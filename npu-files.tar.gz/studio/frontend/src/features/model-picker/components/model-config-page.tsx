// SPDX-License-Identifier: AGPL-3.0-only
// Copyright 2026-present the Unsloth AI Inc. team. All rights reserved. See /studio/LICENSE.AGPL-3.0

import { InferenceEnginePicker } from "./inference-engines";
import { CustomLlamaConfigEditor } from "./custom-llama-config-editor";
import {
  MANAGED_LLAMA_CPP_CONFIG,
  normalizeLlamaCppConfig,
} from "../model-config/llama-cpp-config";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { InfoHint } from "@/components/ui/info-hint";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { usePlatformStore } from "@/config/env";
import {
  GPU_LAYERS_AUTO,
  fetchGgufStagedMetadata,
  readPersistedGpuMemoryMode,
  readPersistedSpeculativeType,
  resolveStagedDiffusionClassification,
  useChatRuntimeStore,
} from "@/features/chat";
import {
  distributeByWeight,
  rebalanceSplit,
} from "@/features/chat/stores/chat-runtime-store";
import { prepareHfTokenForUse } from "@/features/hf-auth";
import {
  type VramBudgetSettings,
  dropVramBudgetRetry,
  flushVramBudgetSave,
  isVramBudgetLocked,
  loadVramBudgetSettings,
  setVramBudgetLocked,
  settleVramBudgetSave,
  stageVramBudgetSave,
  subscribeVramBudgetLock,
  subscribeVramBudgetSettings,
  updateVramBudgetSettings,
} from "@/features/settings/api/vram-budget";
import {
  type GpuIndexKind,
  type SystemGpuDevice,
  cachedPinnableGpuContext,
  pinnableGpuContext,
  reconcileGpuSelection,
  useGpuDevices,
  useInferenceGpuInfo,
} from "@/hooks/use-gpu-info";
import {
  DEFAULT_VRAM_FRACTION,
  resolveFreeGpuCapacityGb,
  resolveMemoryCapacityGb,
} from "@/hooks/gpu-vram";
import { ChevronDownStandardIcon } from "@/lib/chevron-icons";
import { toast } from "@/lib/toast";
import {
  type ReactNode,
  type Ref,
  type SetStateAction,
  useCallback,
  useEffect,
  useId,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from "react";
import { useShallow } from "zustand/react/shallow";
import {
  type ModelMemorySettings,
  loadModelMemorySettings,
  subscribeModelMemorySettings,
} from "@/features/settings/api/model-memory";
import {
  type LlamaFlagCatalog,
  loadLlamaFlagCatalog,
  loadManagedLlamaFlags,
  subscribeLlamaFlagCatalog,
} from "../api/llama-flags";
import { type MemoryEstimate } from "../api/memory-estimate";
import {
  resolveEstimateContext,
  resolveMlxEstimateContext,
  resolveMlxServedWindow,
  shouldRequestMemoryEstimate,
} from "../model-config/estimate-context";
import { resolveReclaimableMemoryCredit } from "../model-config/memory-fit";
import {
  resolveResidentEstimateRequest,
  selectResidentEstimateSettings,
} from "../model-config/resident-memory-request";
import { useMemoryEstimate } from "../hooks/use-memory-estimate";
import {
  fetchLoadModelOverride,
  fromApiOverride,
  modelOverrideKey,
  panelOverrideRow,
  syncModelOverride,
} from "../api/model-overrides";
import {
  diagnoseExtraArgs,
  extraArgsAreLoadable,
  formatExtraArgs,
  parseExtraArgs,
  sanitizeStoredExtraArgs,
} from "../model-config/llama-extra-args";
import {
  useDefaultChatTemplate,
  useModelMaxPositionEmbeddings,
} from "../hooks/use-model-defaults";
import { perModelConfigsEqual } from "../model-config/apply-per-model-config";
import {
  clearExtraArgsEditForDraft,
  clearModelConfigDraftEdited,
  isExtraArgsHydratedForDraft,
  isModelConfigDraftEdited,
  markModelConfigDraftEdited,
  markExtraArgsHydratedForDraft,
  modelConfigDraftKey,
  patchModelConfigDraft,
  primeModelConfigDraft,
  readExtraArgsEditForDraft,
  readModelConfigDraft,
  replaceModelConfigDraft,
  retainModelConfigDraft,
  setExtraArgsEditForDraft,
  setExtraArgsEditLoadableForDraft,
  setModelConfigDraftRemember,
  setModelConfigDraftSavedRemember,
  subscribeModelConfigDraft,
} from "../model-config/model-config-draft";
import { loadedConfigSignature } from "../model-config/config-signature";
import { ggufQuantLabel } from "../model-config/model-identity";
import {
  CACHE_RAM_LLAMA_DEFAULT,
  CACHE_RAM_MAX,
  CACHE_RAM_MIN,
  CONTEXT_LENGTH_MIN,
  CTX_CHECKPOINTS_LLAMA_DEFAULT,
  CTX_CHECKPOINTS_MAX,
  CTX_CHECKPOINTS_MIN,
  DEFAULT_MAX_SEQ_LENGTH,
  DEFAULT_PER_MODEL_CONFIG,
  DRAFT_N_MAX_SPEC_TYPES,
  KV_CACHE_DTYPES,
  LOAD_MODES,
  LOAD_MODE_DEFAULT,
  MAX_SEQ_LENGTH_MAX,
  MAX_SEQ_LENGTH_MIN,
  MAX_SEQ_LENGTH_STEP,
  MLX_KV_QUANTS,
  mlxKvQuantLabel,
  type MlxKvQuant,
  N_BATCH_LLAMA_DEFAULT,
  N_BATCH_MAX,
  N_BATCH_MIN,
  N_PARALLEL_MAX,
  N_PARALLEL_MIN,
  type PerModelConfig,
  SEPARATE_DRAFT_MODEL_SPEC_TYPES,
  SPECULATIVE_TYPES,
  deletePerModelConfig,
  floorMaxSeqLength,
  isDefaultConfig,
  isReasoningBudgetMessageValid,
  contextPinPatch,
  isServedByMlx,
  savedContextPin,
  normalizeMaxSeqLength,
  normalizePerModelConfig,
  perModelConfigStorageChanged,
  readAdvancedSettingsOpen,
  resolveInitialConfig,
  saveAdvancedSettingsOpen,
  savePerModelConfig,
  subscribeAdvancedSettingsOpen,
  VRAM_BUDGET_PERCENT_STEP,
  vramFractionToPercent,
  vramPercentToFraction,
} from "../model-config/per-model-config";
import { isAudioRuntimeGguf } from "../../audio/audio-cpp-catalog";
import { isNpuModelId, NPU_DEFAULT_CONTEXT_LENGTH } from "../../npu";
import {
  type RunConfigImport,
  SharedRunConfigControls,
  SharedRunConfigReview,
  cancelRunConfigImportForEdit,
  isRunConfigEditorChange,
  isRunConfigVariantUnresolved,
} from "../sharing";
import { ChatTemplateEditorDialog } from "./chat-template-editor-dialog";
import { MemoryEstimateRow } from "./memory-estimate-row";
import type { ModelPickTarget } from "./model-selector/types";
import {
  NumericValueInput,
  type NumericValueInputHandle,
} from "./numeric-value-input";
import {
  ChevronLeftIcon,
} from "lucide-react";

const ROW_CLASS = "flex min-h-8 items-center justify-between gap-3";
const LABEL_CLASS =
  "min-w-0 truncate text-ui-13 font-medium leading-[1.25] tracking-nav text-foreground";
const LABEL_CLASS_WRAP =
  "min-w-0 text-ui-13 font-medium leading-[1.25] tracking-nav text-foreground";
// Same surface token as the panel's fields and textareas.
const CONTROL_SURFACE =
  "rounded-full border-transparent bg-[var(--panel-input-surface)] hover:bg-[var(--panel-input-surface-hover)] dark:bg-[var(--panel-input-surface)] dark:hover:bg-[var(--panel-input-surface-hover)]";
// One width for every typed field: a box that resized per keystroke would jump under the
// caret. Narrow, so the label beside it is not clipped in a ~240px panel.
const INPUT_WIDTH_CLASS = "w-[calc(84px*var(--ui-space-scale,1))] shrink-0";
// A select holds one of a known set of values, so it sizes to that value.
const SELECT_WIDTH_CLASS = "w-auto max-w-full shrink-0";
// .panel-select-trigger carries the surface, padding and type; this adds the layout.
const SELECT_TRIGGER_CLASS = `panel-select-trigger grid h-8! min-w-0 grid-cols-[minmax(0,1fr)_auto] items-center gap-2 ${SELECT_WIDTH_CLASS} [&_[data-slot=select-value]]:min-w-0 [&_[data-slot=select-value]]:truncate [&>svg]:shrink-0`;
// .panel-field carries the surface and the value's alignment; the field adds its size.
const NUMBER_INPUT_CLASS = `panel-field h-8 ${INPUT_WIDTH_CLASS}`;
const TEXT_INPUT_CLASS = `panel-field h-8 ${INPUT_WIDTH_CLASS} min-w-0`;
// Matches the Preset section's Save/Delete pair rather than the Button's own `sm` metrics.
// Width is the label plus this padding, so a pill is never wider than what it says.
const FOOTER_BUTTON_CLASS =
  "h-9 w-auto px-4 rounded-full text-ui-13 font-medium tracking-nav";

// Mirrors the backend's Auto default once GPU-only placement is impossible.
const AUTO_OFFLOAD_CONTEXT_LENGTH = 8192;
const KV_CACHE_DTYPE_DEFAULT = "f16";
const SPECULATIVE_TYPE_LABELS: Record<
  (typeof SPECULATIVE_TYPES)[number],
  string
> = {
  auto: "Auto",
  mtp: "MTP",
  dspark: "DSpark",
  dflash: "DFlash",
  ngram: "Ngram",
  "mtp+ngram": "MTP+Ngram",
  off: "Off",
};

// Lower-case where the value is the flag's own spelling, so the pick reads the same as the launch command.
const LOAD_MODE_LABELS: Record<(typeof LOAD_MODES)[number], string> = {
  auto: "Auto",
  none: "None",
  mmap: "mmap",
  mlock: "mlock",
  "mmap+mlock": "mmap+mlock",
  dio: "DirectIO",
};

// What "Don't reserve system RAM" vetoes: allocated or locked host weight buffers. Windows mmap can still hold the
// file pages resident, which is what the DirectIO policy is for.
// Mirrors _LOAD_MODE_MLOCK_VALUES | _LOAD_MODE_RESERVING_VALUES in llama_server_args.py.
const RAM_RESERVING_LOAD_MODES = new Set(["none", "mlock", "mmap+mlock"]);

/** What Model Memory does to this load mode, or null when the pick reaches the command line
 *  untouched: a row showing the pick alone would name a flag the child never sees. Keep
 *  resident is first, because it wins outright. */
function loadModeOverrideNotice(
  mode: string | null,
  settings: ModelMemorySettings | null,
): string | null {
  if (mode == null || settings == null) {
    return null;
  }
  if (settings.keepResident && !settings.noRamReserve) {
    return mode === "mmap+mlock"
      ? null
      : "This will be replaced by mmap+mlock: Keep model in GPU memory, in Settings, owns how the weights are held.";
  }
  if (settings.noRamReserve && RAM_RESERVING_LOAD_MODES.has(mode)) {
    return "This will be removed: Don't reserve system RAM, in Settings, chooses the loading policy. Supported Windows builds skip the mapping for a full GPU offload; other placements use the default mmap path.";
  }
  return null;
}

/** The batch size llama-server will not go below for this load. Two is its own hard floor, and
 *  above that the floor follows the slots the launch SERVES, which is not always the number
 *  chosen here: a build without --kv-unified serves one slot however many are asked for. */
function effectiveBatchFloor(
  requestedSlots: number | null | undefined,
  limits:
    | { defaultParallelSlots?: number; parallelSlotsClamped?: boolean }
    | null
    | undefined,
): number {
  if (limits?.parallelSlotsClamped) {
    return 2;
  }
  return Math.max(2, requestedSlots ?? limits?.defaultParallelSlots ?? 2);
}

function hasNonDefaultAdvanced(config: PerModelConfig): boolean {
  return (
    config.kvCacheDtype != null ||
    (config.speculativeType ?? "auto") !== "auto" ||
    config.specDraftNMax != null ||
    config.specDraftCacheDtype != null ||
    config.nParallel != null ||
    config.reasoningBudget !== -1 ||
    config.reasoningBudgetMessage !== "" ||
    config.nBatch != null ||
    config.nUbatch != null ||
    config.loadMode != null ||
    config.ctxCheckpoints != null ||
    config.cacheRam != null ||
    config.tensorParallel ||
    config.disableVision ||
    config.chatTemplateOverride != null ||
    // Hidden flags can change what the model does, so a panel that opens collapsed over them says
    // "defaults" about a load that is anything but.
    (config.llamaExtraArgs != null && config.llamaExtraArgs.length > 0) ||
    (config.gpuMemoryMode ?? "auto") !== "auto" ||
    (config.gpuLayers != null && config.gpuLayers >= 0) ||
    (config.nCpuMoe ?? 0) > 0 ||
    config.selectedGpuIds != null
  );
}

function withoutUnsupportedDiffusionSettings(
  config: PerModelConfig,
  currentGpuIndexKind: GpuIndexKind | null = null,
): PerModelConfig {
  const hasUnsupportedGpuPick =
    config.selectedGpuIds != null &&
    (config.selectedGpuIndexKind === "vulkan" ||
      currentGpuIndexKind === "vulkan");
  if (
    (config.gpuMemoryMode ?? "auto") === "auto" &&
    config.gpuLayers == null &&
    config.nCpuMoe == null &&
    config.reasoningBudget === -1 &&
    config.reasoningBudgetMessage === "" &&
    !config.tensorParallel &&
    !config.disableVision &&
    config.nBatch == null &&
    config.nUbatch == null &&
    (config.llamaExtraArgs == null || config.llamaExtraArgs.length === 0) &&
    config.llamaCppConfig?.mode !== "custom" &&
    !hasUnsupportedGpuPick
  ) {
    return config;
  }
  return {
    ...config,
    gpuMemoryMode: "auto",
    gpuLayers: undefined,
    nCpuMoe: undefined,
    reasoningBudget: -1,
    reasoningBudgetMessage: "",
    tensorParallel: false,
    disableVision: false,
    // the diffusion runner ignores the llama-server batch flags
    nBatch: null,
    nUbatch: null,
    // The diffusion shim never appends llama-server flags to its command, but the load records
    // them as though it had, so a box filled before classification flipped would leave the
    // model running without what it says.
    llamaExtraArgs: null,
    // The diffusion runner has no llama-server; explicit managed, since omitted inherits the stored custom.
    ...(config.llamaCppConfig?.mode === "custom"
      ? { llamaCppConfig: MANAGED_LLAMA_CPP_CONFIG }
      : {}),
    ...(hasUnsupportedGpuPick
      ? {
          selectedGpuIds: undefined,
          selectedGpuIndexKind: undefined,
        }
      : {}),
  };
}

function reconcileConfigGpuSelection(
  config: PerModelConfig,
  isDiffusion: boolean,
  gpuDevices?: SystemGpuDevice[],
): PerModelConfig {
  const context = cachedPinnableGpuContext(isDiffusion, gpuDevices);
  const supported = isDiffusion
    ? withoutUnsupportedDiffusionSettings(config, context.indexKind ?? null)
    : config;
  if (supported.selectedGpuIds == null) {
    return supported;
  }
  const reconciled = reconcileGpuSelection(
    supported.selectedGpuIds,
    supported.selectedGpuIndexKind,
    context.indexKind,
    context.ids,
  );
  const next = {
    ...supported,
    selectedGpuIds: reconciled.ids ?? undefined,
    selectedGpuIndexKind:
      reconciled.ids === null ? undefined : reconciled.indexKind,
  };
  return perModelConfigsEqual(next, supported) ? supported : next;
}

function ChatTemplateSetting({
  config,
  onEditTemplate,
  readOnly = false,
}: {
  config: PerModelConfig;
  onEditTemplate: () => void;
  readOnly?: boolean;
}) {
  return (
    <div className={ROW_CLASS}>
      <div className="flex min-w-0 items-center gap-1.5">
        <span className={LABEL_CLASS}>Chat Template</span>
        <InfoHint>
          {readOnly
            ? "Preview the model's chat template. This backend cannot take a custom one."
            : "Replace the model's chat template with custom Jinja. Applies on load."}
        </InfoHint>
      </div>
      <div className="flex shrink-0 items-center gap-2">
        {readOnly ? null : (
          <span className="text-ui-12 text-muted-foreground">
            {config.chatTemplateOverride ? "Custom" : "Default"}
          </span>
        )}
        <Button
          type="button"
          size="sm"
          variant="ghost"
          className={`h-8 px-3.5 text-ui-13 ${CONTROL_SURFACE}`}
          onClick={onEditTemplate}
        >
          {readOnly ? "View" : "Edit"}
        </Button>
      </div>
    </div>
  );
}

function MaxSeqLengthSetting({
  value,
  max,
  inputMax,
  onChange,
  inputRef,
  isMlx,
  pinned,
  fittedToMemory,
  windowUnknown,
  hint,
}: {
  value: number;
  max: number;
  inputMax: number;
  onChange: (value: number) => void;
  inputRef?: Ref<NumericValueInputHandle>;
  isMlx?: boolean;
  pinned?: boolean;
  fittedToMemory?: boolean;
  windowUnknown?: boolean;
  hint?: string;
}) {
  // MLX sizes itself when unpinned, so the control is the GGUF path's Context Length and
  // shows the length that will be served, not "Auto". A dash only while it is unknown.
  const label = isMlx ? "Context Length" : "Max Seq Length";
  return (
    <div className="space-y-2">
      <div className={ROW_CLASS}>
        <div className="flex min-w-0 items-center gap-1.5">
          <span className={LABEL_CLASS}>{label}</span>
          <InfoHint>
            {hint ?? (isMlx
              ? "Tokens of context the model is sized for." +
                (fittedToMemory
                  ? " Fitted to this machine's memory, which is less than the model's own " +
                    "window. Set a length to ask for a different one."
                  : "")
              : "Maximum context window in tokens. Applies on load.")}
          </InfoHint>
        </div>
        <NumericValueInput
          ref={inputRef}
          value={value}
          min={MAX_SEQ_LENGTH_MIN}
          max={inputMax}
          step={MAX_SEQ_LENGTH_STEP}
          onChange={onChange}
          displayValue={isMlx && windowUnknown ? "—" : undefined}
          derived={isMlx && !pinned}
          ariaLabel={label}
          className={NUMBER_INPUT_CLASS}
          fixedWidth={true}
          size={8}
        />
      </div>
      <Slider
        min={MAX_SEQ_LENGTH_MIN}
        max={max}
        step={MAX_SEQ_LENGTH_STEP}
        // Outside the control's range it sits at the nearer edge, or the first nudge
        // would step from the shown number onto the bound.
        value={[Math.min(Math.max(value, MAX_SEQ_LENGTH_MIN), max)]}
        onValueChange={([next]) => onChange(next)}
        className="panel-slider"
        aria-label={label}
      />
    </div>
  );
}

function clampMaxSeqLength(value: number, max: number): number {
  const normalized = normalizeMaxSeqLength(value) ?? MAX_SEQ_LENGTH_MIN;
  return Math.max(MAX_SEQ_LENGTH_MIN, Math.min(max, normalized));
}

function AdvancedGpuSlider({
  label,
  value,
  min,
  max,
  onChange,
  displayValue,
  info,
  inputRef,
  step = 1,
  disabled = false,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (value: number) => void;
  displayValue?: string;
  info?: ReactNode;
  inputRef?: Ref<NumericValueInputHandle>;
  step?: number;
  disabled?: boolean;
}) {
  return (
    <div className="space-y-2">
      <div className={ROW_CLASS}>
        <div className="flex min-w-0 items-center gap-1.5">
          <span className={LABEL_CLASS}>{label}</span>
          {info && <InfoHint>{info}</InfoHint>}
        </div>
        <NumericValueInput
          ref={inputRef}
          value={value}
          min={min}
          max={max}
          step={step}
          onChange={onChange}
          displayValue={displayValue}
          ariaLabel={label}
          className={NUMBER_INPUT_CLASS}
          fixedWidth={true}
          size={8}
          disabled={disabled}
        />
      </div>
      <Slider
        min={min}
        max={max}
        step={step}
        value={[value]}
        onValueChange={([next]) => onChange(next)}
        className="panel-slider"
        aria-label={label}
        disabled={disabled}
      />
    </div>
  );
}

// How much of each card a load may claim. SERVER-WIDE, not a per-model override: it replaces
// two constants the fit reads. Driven in whole percent so a dragged value round-trips
// exactly; the fraction is rebuilt at the API boundary.
function VramBudgetRow() {
  // macOS is gated here too: it reports no discrete GPUs, so the Metal path sizes itself from
  // _APPLE_UNIFIED_MEMORY_FRACTION and fits with budget_frac = 1.0, and the slider would
  // promise "applies on the next load" for a setting it ignores.
  const isMac = usePlatformStore((s) => s.deviceType === "mac");
  const [settings, setSettings] = useState<VramBudgetSettings | null>(null);
  const [percent, setPercent] = useState<number | null>(null);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const adviceId = useId();
  const modelLoading = useChatRuntimeStore((s) => s.modelLoading);
  const wasModelLoading = useRef(false);
  // Closed while a Run is settling this budget: an edit made in that window would be flushed by
  // the teardown alongside the load request.
  const [locked, setLocked] = useState(isVramBudgetLocked);
  useEffect(() => subscribeVramBudgetLock(setLocked), []);

  // Adopt what the last save or read published: the row's own GET races the PUT a previous
  // unmount fired. A queued edit outranks the publish, or a save landing mid-drag would pull
  // the slider out from under the pointer.
  useEffect(() => {
    if (isMac) {
      return;
    }
    return subscribeVramBudgetSettings((next) => {
      if (saveTimer.current) {
        return;
      }
      setSettings(next);
      setPercent(vramFractionToPercent(next.fraction));
    });
  }, [isMac]);

  useEffect(() => {
    let cancelled = false;
    if (isMac) {
      // Nothing to show, so do not even ask; the row is hidden below.
      return;
    }
    loadVramBudgetSettings().then((loaded) => {
      if (cancelled || !loaded) {
        return;
      }
      setSettings(loaded);
      setPercent(vramFractionToPercent(loaded.fraction));
    });
    return () => {
      cancelled = true;
    };
    // deviceType settles once /api/health answers, so re-run if the seed guess flips.
  }, [isMac]);

  // reloadRequired describes the running child, so it goes stale the moment a load finishes and
  // nothing remounts this row. Only the falling edge: the read during a load answers about
  // the child being replaced.
  useEffect(() => {
    const finished = wasModelLoading.current && !modelLoading;
    wasModelLoading.current = modelLoading;
    if (isMac || !finished) {
      return;
    }
    let cancelled = false;
    // Forced: a read that began before the load finished describes the child being replaced, and
    // sharing it would republish the notice this refresh is clearing.
    loadVramBudgetSettings({ force: true }).then((loaded) => {
      if (cancelled || !loaded) {
        return;
      }
      setSettings(loaded);
    });
    return () => {
      cancelled = true;
    };
  }, [isMac, modelLoading]);

  // Flush, do not drop: the timer is cleared so nothing fires against a torn-down view, but the
  // fraction is still sent, since it is held nowhere else. The response only reaches
  // subscribers, the view being gone.
  useEffect(
    () => () => {
      if (saveTimer.current) {
        clearTimeout(saveTimer.current);
        saveTimer.current = null;
      }
      flushVramBudgetSave()?.catch((error: unknown) => {
        toast.error(
          error instanceof Error ? error.message : "Failed to save VRAM budget",
        );
      });
    },
    [],
  );

  // A null response means an older backend; hide rather than render a dead control.
  if (isMac || !settings || percent === null) {
    return null;
  }

  const defaultPercent = vramFractionToPercent(settings.defaultFraction);
  // Stored beats UNSLOTH_VRAM_FRACTION, so once the slider has been touched there is otherwise
  // no way back to inheriting it. Clearing is what the null the API accepts is for.
  const resetBudget = () => {
    if (saveTimer.current) {
      clearTimeout(saveTimer.current);
      saveTimer.current = null;
    }
    // Drop a queued drag, or its debounce would store back what this clears.
    stageVramBudgetSave(null);
    updateVramBudgetSettings(null)
      .then((next) => {
        setSettings(next);
        setPercent(vramFractionToPercent(next.fraction));
      })
      .catch((error: unknown) => {
        toast.error(
          error instanceof Error ? error.message : "Failed to reset VRAM budget",
        );
      });
  };
  const commit = (next: number) => {
    setPercent(next);
    // Debounced: the slider fires per pointer move, so a drag would be dozens of writes, each
    // invalidating the read cache.
    if (saveTimer.current) {
      clearTimeout(saveTimer.current);
    }
    stageVramBudgetSave(vramPercentToFraction(next));
    saveTimer.current = setTimeout(() => {
      saveTimer.current = null;
      flushVramBudgetSave()
        ?.then(setSettings)
        .catch((error: unknown) => {
          // The client re-stages it, where the write generation can say whether it is still the newest intent.
          toast.error(
            error instanceof Error ? error.message : "Failed to save VRAM budget",
          );
        });
    }, 400);
  };

  return (
    <div className="space-y-1">
      <AdvancedGpuSlider
        label="VRAM Budget"
        value={percent}
        min={vramFractionToPercent(settings.minFraction)}
        max={vramFractionToPercent(settings.maxFraction)}
        step={VRAM_BUDGET_PERCENT_STEP}
        displayValue={`${percent}%`}
        onChange={commit}
        disabled={locked}
        info={
          <div className="flex flex-col gap-1.5">
            <div>
              Share of each GPU Unsloth will claim when it sizes the model and
              context. The rest is left for memory fragmentation, the per-device
              CUDA context on a multi-GPU split, and MoE routing.
            </div>
            <div>
              Applies to every model, not just this one, and takes effect on the
              next load. Default {defaultPercent}%. Even at 100% a load leaves a
              margin on each card, up to the 512 MiB llama.cpp keeps for its own
              fitter, and never more than the default would have reserved.
            </div>
            <div>
              Reset clears the stored value, so UNSLOTH_VRAM_FRACTION applies
              again if it is set.
            </div>
          </div>
        }
      />
      {percent !== defaultPercent && (
        <p id={adviceId} className="text-ui-11 text-amber-500">
          {percent > defaultPercent
            ? "Above the default fits more context but leaves less slack, so a load can run out of memory. llama.cpp treats that as a hard failure rather than falling back."
            : "Below the default is safer on a shared GPU, but a tight fit may push layers onto the CPU and generate slowly."}
        </p>
      )}
      {settings.isStored && (
        <button
          type="button"
          disabled={locked}
          onClick={resetBudget}
          className="text-ui-11 text-muted-foreground underline underline-offset-2 hover:text-foreground"
        >
          Reset to the server default
        </button>
      )}
      {settings.reloadRequired && (
        <p className="text-ui-11 text-muted-foreground">
          The loaded model was sized with a different budget. Reload it to apply
          this one.
        </p>
      )}
    </div>
  );
}

// GPU Memory placement controls, GGUF only. Slider ceilings come from the GGUF header dims;
// --tensor-split is set per GPU row but not persisted per model.
function GpuMemorySettings({
  config,
  update,
  layerCount,
  moeLayerCount,
  isDiffusion,
  gpuDevices,
  gpuLayersInputRef,
  moeLayersInputRef,
}: {
  config: PerModelConfig;
  update: (patch: Partial<PerModelConfig>) => void;
  layerCount: number | null;
  moeLayerCount: number | null;
  isDiffusion: boolean;
  gpuDevices: SystemGpuDevice[];
  gpuLayersInputRef?: Ref<NumericValueInputHandle>;
  moeLayersInputRef?: Ref<NumericValueInputHandle>;
}) {
  const mode = config.gpuMemoryMode ?? "auto";
  const isManual = mode === "manual";
  const gpuLayers = config.gpuLayers ?? GPU_LAYERS_AUTO;
  // Slider at Auto: llama.cpp --fit owns the layout, so MoE-offload does not apply.
  const autoLayers = isManual && gpuLayers < 0;
  // Ceiling = layer count + 1 (llama.cpp counts the output layer as offloadable), else a fallback.
  const gpuLayersMax = layerCount != null ? layerCount + 1 : 256;
  const nCpuMoe = config.nCpuMoe ?? 0;
  const moeLayersMax = moeLayerCount ?? 0;
  const showMoeSlider = isManual && !autoLayers && moeLayersMax > 0;
  const selectedGpuIds = config.selectedGpuIds ?? null;
  const gpuContext = pinnableGpuContext(gpuDevices, isDiffusion);
  const pinnableDevices = gpuContext.devices ?? [];
  const gpuIndexKind = gpuContext.indexKind ?? null;
  const singleGpuInUse = (selectedGpuIds ?? gpuContext.ids ?? []).length <= 1;
  // Multi-GPU only, with one backend-declared index namespace. null = automatic.
  const showGpuPicker = (gpuContext.ids?.length ?? 0) > 1;
  const isGpuChecked = (index: number) =>
    selectedGpuIds === null || selectedGpuIds.includes(index);
  // The list order IS the device order the backend pins, so a re-checked GPU goes
  // to the end rather than back to its numeric slot.
  const orderedGpuIds = selectedGpuIds ?? gpuContext.ids ?? [];
  // Mirrors the backend's --tensor-split gate.
  const splitTotal = Math.max(0, Math.min(gpuLayers, gpuLayersMax));
  const showSplit =
    !isDiffusion &&
    isManual &&
    !autoLayers &&
    splitTotal > 0 &&
    showGpuPicker &&
    orderedGpuIds.length > 1;
  const splitIsPercent = Boolean(config.tensorParallel);
  const splitScale = splitIsPercent ? 100 : splitTotal;
  const tensorSplit = config.tensorSplit ?? null;
  const splitIsCustom =
    tensorSplit != null && tensorSplit.length === orderedGpuIds.length;
  // Untouched: show a VRAM-proportional split and send nothing.
  const splitShares = showSplit
    ? distributeByWeight(
        splitScale,
        splitIsCustom
          ? tensorSplit
          : orderedGpuIds.map(
              (id) =>
                pinnableDevices.find((d) => d.index === id)?.memoryTotalGb ?? 1,
            ),
      )
    : [];
  const setSplitShare = (id: number, value: number) => {
    const k = orderedGpuIds.indexOf(id);
    if (k < 0) return;
    update({ tensorSplit: rebalanceSplit(splitScale, splitShares, k, value) });
  };
  const commitGpuIds = (next: number[], nextSplit: number[] | null = null) => {
    if (next.length === 0) return; // keep at least one GPU selected
    update({
      selectedGpuIds: next,
      selectedGpuIndexKind: gpuIndexKind,
      // Positional, so a different GPU set invalidates it.
      tensorSplit: nextSplit,
    });
  };
  const toggleGpu = (index: number) => {
    commitGpuIds(
      orderedGpuIds.includes(index)
        ? orderedGpuIds.filter((i) => i !== index)
        : [...orderedGpuIds, index],
    );
  };
  // Selected devices in the order they will be given to the model, then the rest.
  const orderedPinnableDevices = [
    ...orderedGpuIds
      .map((id) => pinnableDevices.find((d) => d.index === id))
      .filter((d): d is SystemGpuDevice => d !== undefined),
    ...pinnableDevices.filter((d) => !orderedGpuIds.includes(d.index)),
  ];
  const moveGpu = (index: number, delta: -1 | 1) => {
    const from = orderedGpuIds.indexOf(index);
    const to = from + delta;
    if (from < 0 || to < 0 || to >= orderedGpuIds.length) return;
    const next = [...orderedGpuIds];
    [next[from], next[to]] = [next[to], next[from]];
    let nextSplit: number[] | null = null;
    if (splitIsCustom) {
      nextSplit = [...tensorSplit];
      [nextSplit[from], nextSplit[to]] = [nextSplit[to], nextSplit[from]];
    }
    commitGpuIds(next, nextSplit);
  };
  return (
    <>
      <div className={isDiffusion ? "hidden" : ROW_CLASS}>
        <div className="flex min-w-0 items-center gap-1.5">
          <span className={LABEL_CLASS}>GPU Memory</span>
          <InfoHint>
            <div className="flex flex-col gap-1.5">
              <div>
                <span className="font-medium">Default:</span> Unsloth fits the
                model and context to your GPUs.
              </div>
              <div>
                <span className="font-medium">Manual:</span> set GPU Layers
                yourself.
              </div>
            </div>
          </InfoHint>
        </div>
        <Select
          value={mode}
          onValueChange={(v) =>
            // Default clears every Manual-only setting.
            update(
              v === "manual"
                ? { gpuMemoryMode: "manual" }
                : {
                    gpuMemoryMode: "auto",
                    gpuLayers: undefined,
                    nCpuMoe: undefined,
                    selectedGpuIds: undefined,
                    selectedGpuIndexKind: undefined,
                    tensorSplit: null,
                  },
            )
          }
        >
          <SelectTrigger
            animateRadius={false}
            icon={ChevronDownStandardIcon}
            iconClassName="size-3.5"
            className={SELECT_TRIGGER_CLASS}
          >
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="menu-soft-surface ring-0 border-0 rounded-lg">
            <SelectItem value="auto">Default</SelectItem>
            <SelectItem value="manual">Manual</SelectItem>
          </SelectContent>
        </Select>
      </div>
      {/* A fixed manual layer count is the one placement the budget cannot move, and a CPU-only host
          has no GPU to act on, so "applies on the next load" would be false. Manual + Auto is
          included: --fit-target still carries the budget to llama.cpp's fitter. */}
      {!isDiffusion && (!isManual || autoLayers) && gpuDevices.length > 0 && (
        <VramBudgetRow />
      )}
      {!isDiffusion && isManual && (
        <>
          <AdvancedGpuSlider
            label="GPU Layers"
            inputRef={gpuLayersInputRef}
            value={Math.max(GPU_LAYERS_AUTO, Math.min(gpuLayers, gpuLayersMax))}
            min={GPU_LAYERS_AUTO}
            max={gpuLayersMax}
            onChange={(v) =>
              update(v < 0 ? { gpuLayers: v, tensorSplit: null } : { gpuLayers: v })
            }
            displayValue={autoLayers ? "Auto" : undefined}
            info={
              <>
                Layers to keep on the GPU (--gpu-layers); the rest run on CPU.
                Auto sizes the split to fit VRAM.
              </>
            }
          />
          {showMoeSlider && (
            <AdvancedGpuSlider
              label="MoE Layers on CPU"
              inputRef={moeLayersInputRef}
              value={Math.min(nCpuMoe, moeLayersMax)}
              min={0}
              max={moeLayersMax}
              onChange={(v) => update({ nCpuMoe: v })}
              info={
                <>
                  Keep the experts of this many MoE layers on the CPU
                  (--n-cpu-moe) to save VRAM. 0 keeps every expert on the GPU.
                </>
              }
            />
          )}
        </>
      )}
      {showGpuPicker && (
        <div className="space-y-2">
          <div className="flex min-w-0 items-center gap-1.5">
            <span className={LABEL_CLASS}>GPUs</span>
            <InfoHint>
              Unsloth picks GPUs automatically. Checking them here limits it to
              those.
              {!isDiffusion &&
                " Their order here is the order the model gets them."}{" "}
              Keep at least one selected.
              {showSplit &&
                (splitIsPercent
                  ? " The number beside each is its share of every layer, in percent (--tensor-split)."
                  : " The number beside each is how many of the GPU Layers it holds (--tensor-split).")}
            </InfoHint>
            {showSplit && splitIsCustom && (
              <button
                type="button"
                className="ml-auto shrink-0 rounded px-1 text-ui-12 text-muted-foreground hover:text-foreground"
                onClick={() => update({ tensorSplit: null })}
              >
                Reset split
              </button>
            )}
          </div>
          <div className="flex flex-col gap-2">
            {orderedPinnableDevices.map((d, position) => (
              <div
                key={d.index}
                className="flex items-center justify-between gap-3"
              >
                <span className="min-w-0 truncate text-ui-12 text-muted-foreground">
                  GPU {d.index}: {d.name}
                  {d.memoryTotalGb
                    ? ` · ${Math.round(d.memoryTotalGb)} GiB`
                    : ""}
                </span>
                {showSplit && isGpuChecked(d.index) && (
                  <div className="ml-auto flex shrink-0 items-center gap-1">
                    <NumericValueInput
                      value={splitShares[orderedGpuIds.indexOf(d.index)] ?? 0}
                      min={0}
                      max={splitScale}
                      step={1}
                      onChange={(v) => setSplitShare(d.index, v)}
                      derived={!splitIsCustom}
                      ariaLabel={
                        splitIsPercent
                          ? `Share of each layer on GPU ${d.index}, percent`
                          : `Layers on GPU ${d.index}`
                      }
                      className="panel-field h-7 w-[calc(52px*var(--ui-space-scale,1))] shrink-0"
                      fixedWidth={true}
                      size={4}
                    />
                    <span className="w-[3.25em] text-ui-12 text-muted-foreground">
                      {splitIsPercent ? "%" : "layers"}
                    </span>
                  </div>
                )}
                {/* Not for diffusion: that runner drives one device and matches_gpu_ids
                    reduces the request to its lowest id, so the arrows would move a row
                    without moving the model, under help text promising the opposite. */}
                {isGpuChecked(d.index) && !singleGpuInUse && !isDiffusion && (
                  <div className="flex shrink-0 items-center gap-0.5">
                    <button
                      type="button"
                      className="rounded px-1 text-ui-12 text-muted-foreground hover:text-foreground disabled:opacity-30"
                      aria-label={`Move GPU ${d.index} earlier`}
                      disabled={position === 0}
                      onClick={() => moveGpu(d.index, -1)}
                    >
                      ↑
                    </button>
                    <button
                      type="button"
                      className="rounded px-1 text-ui-12 text-muted-foreground hover:text-foreground disabled:opacity-30"
                      aria-label={`Move GPU ${d.index} later`}
                      disabled={position >= orderedGpuIds.length - 1}
                      onClick={() => moveGpu(d.index, 1)}
                    >
                      ↓
                    </button>
                  </div>
                )}
                <Switch
                  className="panel-switch shrink-0"
                  checked={isGpuChecked(d.index)}
                  onCheckedChange={() => toggleGpu(d.index)}
                  disabled={isGpuChecked(d.index) && singleGpuInUse}
                />
              </div>
            ))}
          </div>
        </div>
      )}
    </>
  );
}

const MLX_KV_QUANT_AUTO = "auto";

function AdvancedSettingsToggle({
  checked,
  onCheckedChange,
}: {
  checked: boolean;
  onCheckedChange: (next: boolean) => void;
}) {
  return (
    // Ruled off from the context controls above, matching the estimate row's divider.
    <div className={`${ROW_CLASS} border-t border-border pt-5`}>
      <div className="flex min-w-0 items-center gap-1.5">
        <span className="min-w-0 text-ui-13 font-medium leading-[1.25] tracking-nav text-muted-foreground">
          Advanced settings
        </span>
        <InfoHint>
          Extra options for how the model loads. Unsloth already picks the best
          settings for your device, so most setups don't need these.
        </InfoHint>
      </div>
      <Switch
        className="panel-switch shrink-0"
        checked={checked}
        onCheckedChange={onCheckedChange}
        aria-label="Show advanced settings"
      />
    </div>
  );
}

const GGUF_PARALLEL_HINT =
  "Decode slots (--parallel) for concurrent requests. Leave blank for the server " +
  "default. More slots share the context pool and use more VRAM.";

const MLX_PARALLEL_HINT =
  "Chat replies this model decodes at once (--parallel). Leave blank for the " +
  "default. Replies sharing a decode finish sooner together, but each one holds " +
  "its own context in memory for as long as it runs, and nothing reduces the " +
  "number to fit — raise it only if the memory is there.";

function ParallelSlotsRow({
  config,
  update,
  hint,
}: {
  config: PerModelConfig;
  update: (patch: Partial<PerModelConfig>) => void;
  hint: string;
}) {
  return (
    <div className={ROW_CLASS}>
      <div className="flex min-w-0 items-center gap-1.5">
        <span className={LABEL_CLASS}>Parallel Slots</span>
        <InfoHint>{hint}</InfoHint>
      </div>
      <input
        type="number"
        min={N_PARALLEL_MIN}
        max={N_PARALLEL_MAX}
        step={1}
        value={config.nParallel ?? ""}
        placeholder="auto"
        onChange={(event) => {
          const raw = event.target.value;
          if (raw === "") {
            update({ nParallel: null });
            return;
          }
          const parsed = Number.parseInt(raw, 10);
          if (Number.isFinite(parsed)) {
            update({
              nParallel: Math.max(
                N_PARALLEL_MIN,
                Math.min(N_PARALLEL_MAX, parsed),
              ),
            });
          }
        }}
        aria-label="Parallel decode slots"
        className={NUMBER_INPUT_CLASS}
      />
    </div>
  );
}

function MlxAdvancedSettings({
  config,
  update,
  outcome,
  servedByMlx,
  onEditTemplate,
  templateOutcome,
}: {
  config: PerModelConfig;
  update: (patch: Partial<PerModelConfig>) => void;
  /** What the backend reported for this exact setting on the loaded model. */
  outcome: string | null;
  /** KV quantization is MLX-only; a CUDA safetensors model has no such control. */
  servedByMlx: boolean;
  onEditTemplate: () => void;
  /** Why the loaded model could not take the override it was given. */
  templateOutcome: string | null;
}) {
  return (
    // Same row spacing as the GGUF rows, whose fragment sits in the list above.
    <div className="flex flex-col gap-5">
      {servedByMlx && (
        <div className="space-y-1">
      <div className={ROW_CLASS}>
        <div className="flex min-w-0 items-center gap-1.5">
          <span className={LABEL_CLASS}>KV Cache Dtype</span>
          <InfoHint>
            Lower KV cache precision to save memory, at some cost to quality.
            Auto keeps full precision; 8-bit is the safest step down.
            TurboQuant holds quality better at the low widths and adds 3.5-bit,
            which uses 3-bit keys beside 4-bit values; sliding-window and
            recurrent layers keep their native cache under it.
          </InfoHint>
        </div>
        <Select
          value={config.mlxKvQuant ?? MLX_KV_QUANT_AUTO}
          onValueChange={(v) =>
            update({ mlxKvQuant: v === MLX_KV_QUANT_AUTO ? null : (v as MlxKvQuant) })
          }
        >
          <SelectTrigger
            animateRadius={false}
            icon={ChevronDownStandardIcon}
            iconClassName="size-3.5"
            className={SELECT_TRIGGER_CLASS}
          >
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="menu-soft-surface ring-0 border-0 rounded-lg">
            <SelectItem value={MLX_KV_QUANT_AUTO}>Auto</SelectItem>
            {MLX_KV_QUANTS.map((quant) => (
              <SelectItem key={quant} value={quant}>
                {mlxKvQuantLabel(quant)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      {outcome ? (
        <p className="text-ui-11 text-muted-foreground">{outcome}</p>
      ) : null}
        </div>
      )}
      {servedByMlx && (
        <ParallelSlotsRow config={config} update={update} hint={MLX_PARALLEL_HINT} />
      )}
      <div className="space-y-1">
        <ChatTemplateSetting
          config={config}
          onEditTemplate={onEditTemplate}
          readOnly={!servedByMlx}
        />
        {templateOutcome ? (
          <p className="text-ui-11 text-muted-foreground">{templateOutcome}</p>
        ) : null}
      </div>
    </div>
  );
}

/** Mmap/Mlock, with the note that says when Settings wins. Its own component because it
 *  subscribes to the Model Memory settings and must keep following them. */
function LoadModeRow({
  config,
  update,
}: {
  config: PerModelConfig;
  update: (patch: Partial<PerModelConfig>) => void;
}) {
  const adviceId = useId();
  const [modelMemory, setModelMemory] = useState<ModelMemorySettings | null>(
    null,
  );
  useEffect(() => {
    let cancelled = false;
    loadModelMemorySettings()
      .then((loaded) => {
        if (!cancelled) {
          setModelMemory(loaded);
        }
      })
      .catch(() => {});
    const unsubscribe = subscribeModelMemorySettings(setModelMemory);
    return () => {
      cancelled = true;
      unsubscribe();
    };
  }, []);
  const notice = loadModeOverrideNotice(config.loadMode ?? null, modelMemory);
  return (
    <div className="space-y-1">
      <div className={ROW_CLASS}>
        <div className="flex min-w-0 items-center gap-1.5">
          <span className={LABEL_CLASS}>Mmap/Mlock</span>
          <InfoHint>
            How the weights are read off disk (--load-mode). Auto is the
            default and lets Unsloth pick. mmap maps the file, mlock keeps the
            model in RAM, DirectIO streams it, and None asks for no special
            mode.
            Model Memory, in Settings, overrides this when it is on.
          </InfoHint>
        </div>
        <Select
          value={config.loadMode ?? LOAD_MODE_DEFAULT}
          onValueChange={(v) =>
            update({ loadMode: v === LOAD_MODE_DEFAULT ? null : v })
          }
        >
          <SelectTrigger
            animateRadius={false}
            icon={ChevronDownStandardIcon}
            iconClassName="size-3.5"
            className={SELECT_TRIGGER_CLASS}
            aria-describedby={notice ? adviceId : undefined}
          >
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="menu-soft-surface ring-0 border-0 rounded-lg">
            {LOAD_MODES.map((mode) => (
              <SelectItem key={mode} value={mode}>
                {LOAD_MODE_LABELS[mode]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      {notice && (
        <p id={adviceId} className="text-ui-11 text-amber-500">
          {notice}
        </p>
      )}
    </div>
  );
}

// Outside the managed lock: custom launches still honour disable_vision.
function VisionRow({
  config,
  update,
}: {
  config: PerModelConfig;
  update: (patch: Partial<PerModelConfig>) => void;
}) {
  return (
    <div className={ROW_CLASS}>
      <div className="flex min-w-0 items-center gap-1.5">
        <span className={LABEL_CLASS}>Vision</span>
        <InfoHint>
          Loads the vision projector so the model can read images. Turning
          it off frees that VRAM for more layers on the GPU. Text generation
          is unaffected either way.
        </InfoHint>
      </div>
      <Switch
        className="panel-switch shrink-0"
        checked={!config.disableVision}
        onCheckedChange={(checked) => update({ disableVision: !checked })}
      />
    </div>
  );
}

function GgufAdvancedSettings({
  config,
  update,
  showDraftTokens,
  showSpecDraftCacheDtype,
  speculativeFallback,
  onEditTemplate,
  layerCount,
  moeLayerCount,
  isDiffusion,
  gpuDevices,
  gpuLayersInputRef,
  moeLayersInputRef,
  onExtraArgsLoadableChange,
  draftKey,
  hideVision = false,
}: {
  config: PerModelConfig;
  update: (patch: Partial<PerModelConfig>) => void;
  showDraftTokens: boolean;
  showSpecDraftCacheDtype: boolean;
  speculativeFallback: string;
  onEditTemplate: () => void;
  layerCount: number | null;
  moeLayerCount: number | null;
  isDiffusion: boolean;
  gpuDevices: SystemGpuDevice[];
  gpuLayersInputRef?: Ref<NumericValueInputHandle>;
  moeLayersInputRef?: Ref<NumericValueInputHandle>;
  /** Which stored entries the extra-arguments row reads, most specific first. */
  onExtraArgsLoadableChange: (loadable: boolean) => void;
  draftKey: string;
  hideVision?: boolean;
}) {
  const batchAdviceId = useId();
  const ubatchAdviceId = useId();
  // llama-server aborts below 2 and below the slot count, so the loader raises the emitted value
  // to max(slots, 2). Surfaced so the number typed here is not silently different from the
  // one that runs. With Slots blank only the hard floor of 2 is asserted.
  // GGML_ASSERT(n_tokens_all <= cparams.n_batch) below 2, and
  // GGML_ASSERT(n_outputs_max <= cparams.n_outputs_max) below the slot count.
  const batchFloor = Math.max(2, config.nParallel ?? 2);
  const batchBelowFloor = config.nBatch != null && config.nBatch < batchFloor;
  // llama.cpp runs at min(batch, ubatch) and the /status echo is the REQUESTED size, so the
  // control would keep showing a value the server never used: batch 8 / ubatch 4096 measured 8.8x
  // slower. Measured against the EMITTED batch, or the two advisories contradict, since batch 4 /
  // slots 8 launches at 8. A blank batch runs llama.cpp's own 2048, which extras or
  // LLAMA_ARG_BATCH can move without this page seeing it.
  const effectiveBatch =
    config.nBatch != null
      ? Math.max(config.nBatch, batchFloor)
      : N_BATCH_LLAMA_DEFAULT;
  const ubatchExceedsBatch =
    config.nUbatch != null && config.nUbatch > effectiveBatch;
  return (
    <>
      <div className={ROW_CLASS}>
        <div className="flex min-w-0 items-center gap-1.5">
          <span className={LABEL_CLASS}>KV Cache Dtype</span>
          <InfoHint>
            Lower KV cache precision to save VRAM, at some cost to quality. f16
            is the default; q8_0 through iq4_nl are quantized.
          </InfoHint>
        </div>
        <Select
          value={config.kvCacheDtype ?? KV_CACHE_DTYPE_DEFAULT}
          onValueChange={(v) =>
            update({ kvCacheDtype: v === KV_CACHE_DTYPE_DEFAULT ? null : v })
          }
        >
          <SelectTrigger
            animateRadius={false}
            icon={ChevronDownStandardIcon}
            iconClassName="size-3.5"
            className={SELECT_TRIGGER_CLASS}
          >
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="menu-soft-surface ring-0 border-0 rounded-lg">
            <SelectItem value={KV_CACHE_DTYPE_DEFAULT}>
              {KV_CACHE_DTYPE_DEFAULT}
            </SelectItem>
            {KV_CACHE_DTYPES.map((dtype) => (
              <SelectItem key={dtype} value={dtype}>
                {dtype}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className={ROW_CLASS}>
        <div className="flex min-w-0 items-center gap-1.5">
          <span className={LABEL_CLASS_WRAP}>Speculative Decoding</span>
          <InfoHint>
            Faster generation. Auto picks the best strategy for the model and
            platform, or choose one to force it. DSpark and DFlash download a
            drafter sidecar (about 11 GB and 1.5 GB) and trade VRAM for speed;
            MTP and ngram do not change output.
          </InfoHint>
        </div>
        <Select
          value={config.speculativeType ?? speculativeFallback}
          onValueChange={(v) =>
            update({
              speculativeType: v,
              specDraftNMax: DRAFT_N_MAX_SPEC_TYPES.has(v)
                ? config.specDraftNMax
                : null,
              // Dropped with the drafter, like the depth above: the draft context exists only while a
              // separate model is loaded.
              specDraftCacheDtype: SEPARATE_DRAFT_MODEL_SPEC_TYPES.has(v)
                ? config.specDraftCacheDtype
                : null,
            })
          }
        >
          <SelectTrigger
            animateRadius={false}
            icon={ChevronDownStandardIcon}
            iconClassName="size-3.5"
            className={SELECT_TRIGGER_CLASS}
          >
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="menu-soft-surface ring-0 border-0 rounded-lg">
            {SPECULATIVE_TYPES.map((type) => (
              <SelectItem key={type} value={type}>
                {SPECULATIVE_TYPE_LABELS[type]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {showDraftTokens && (
        <div className={ROW_CLASS}>
          <div className="flex min-w-0 items-center gap-1.5">
            <span className={LABEL_CLASS}>Draft Tokens</span>
            <InfoHint>
              Max draft tokens per step. Leave blank for the default (2 or 3,
              depending on the strategy and device).
            </InfoHint>
          </div>
          <input
            type="number"
            min={1}
            max={16}
            step={1}
            value={config.specDraftNMax ?? ""}
            placeholder="auto"
            onChange={(event) => {
              const raw = event.target.value;
              if (raw === "") {
                update({ specDraftNMax: null });
                return;
              }
              const parsed = Number.parseInt(raw, 10);
              if (Number.isFinite(parsed)) {
                update({ specDraftNMax: Math.max(1, Math.min(16, parsed)) });
              }
            }}
            aria-label="Speculative decoding draft tokens"
            className={NUMBER_INPUT_CLASS}
          />
        </div>
      )}

      {showSpecDraftCacheDtype && (
        <div className={ROW_CLASS}>
          <div className="flex min-w-0 items-center gap-1.5">
            <span className={LABEL_CLASS_WRAP}>Spec Decoding KV Cache Dtype</span>
            <InfoHint>
              KV cache precision for the draft model's own context, separate
              from the KV Cache Dtype above. f16 is the default; quantizing it
              saves VRAM on a drafter the target verifies anyway.
            </InfoHint>
          </div>
          <Select
            value={config.specDraftCacheDtype ?? KV_CACHE_DTYPE_DEFAULT}
            onValueChange={(v) =>
              update({
                specDraftCacheDtype: v === KV_CACHE_DTYPE_DEFAULT ? null : v,
              })
            }
          >
            <SelectTrigger
              animateRadius={false}
              icon={ChevronDownStandardIcon}
              iconClassName="size-3.5"
              className={SELECT_TRIGGER_CLASS}
            >
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="menu-soft-surface ring-0 border-0 rounded-lg">
              <SelectItem value={KV_CACHE_DTYPE_DEFAULT}>
                {KV_CACHE_DTYPE_DEFAULT}
              </SelectItem>
              {KV_CACHE_DTYPES.map((dtype) => (
                <SelectItem key={dtype} value={dtype}>
                  {dtype}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      <ParallelSlotsRow config={config} update={update} hint={GGUF_PARALLEL_HINT} />

      {!isDiffusion && (
        <div className="space-y-1">
          <div className={ROW_CLASS}>
            <div className="flex min-w-0 items-center gap-1.5">
              <span className={LABEL_CLASS}>Batch Size</span>
              <InfoHint>
                Logical prompt batch size (--batch-size). Leave blank for the
                default (2048). The micro-batch below usually matters more.
              </InfoHint>
            </div>
            <input
              type="number"
              min={N_BATCH_MIN}
              max={N_BATCH_MAX}
              step={1}
              value={config.nBatch ?? ""}
              placeholder="auto"
              onChange={(event) => {
                const raw = event.target.value;
                if (raw === "") {
                  update({ nBatch: null });
                  return;
                }
                const parsed = Number.parseInt(raw, 10);
                if (Number.isFinite(parsed)) {
                  update({
                    nBatch: Math.max(N_BATCH_MIN, Math.min(N_BATCH_MAX, parsed)),
                  });
                }
              }}
              aria-label="Prompt batch size"
              aria-describedby={batchBelowFloor ? batchAdviceId : undefined}
              className={NUMBER_INPUT_CLASS}
            />
          </div>
          {batchBelowFloor && (
            <p id={batchAdviceId} className="text-ui-11 text-muted-foreground">
              Too small for llama-server, so the load will raise it to {batchFloor}.
              {config.nParallel != null && config.nParallel > 2
                ? " It needs one output slot per parallel slot."
                : " It cannot run a batch below 2."}
            </p>
          )}
        </div>
      )}

      {!isDiffusion && (
        <div className="space-y-1">
          <div className={ROW_CLASS}>
            <div className="flex min-w-0 items-center gap-1.5">
              <span className={LABEL_CLASS}>Micro-batch Size</span>
              <InfoHint>
                Physical prompt micro-batch size (--ubatch-size). Leave blank
                for the default (512, or 1120 on Gemma 4 vision models). Larger
                values speed up prompt processing but use more VRAM; capped at
                the batch size.
              </InfoHint>
            </div>
            <input
              type="number"
              min={N_BATCH_MIN}
              max={N_BATCH_MAX}
              step={1}
              value={config.nUbatch ?? ""}
              placeholder="auto"
              onChange={(event) => {
                const raw = event.target.value;
                if (raw === "") {
                  update({ nUbatch: null });
                  return;
                }
                const parsed = Number.parseInt(raw, 10);
                if (Number.isFinite(parsed)) {
                  update({
                    nUbatch: Math.max(N_BATCH_MIN, Math.min(N_BATCH_MAX, parsed)),
                  });
                }
              }}
              aria-label="Prompt micro-batch size"
              aria-describedby={ubatchExceedsBatch ? ubatchAdviceId : undefined}
              className={NUMBER_INPUT_CLASS}
            />
          </div>
          {ubatchExceedsBatch && (
            <p id={ubatchAdviceId} className="text-ui-11 text-muted-foreground">
              Micro-batch is larger than the batch size, so llama.cpp will run at{" "}
              {effectiveBatch}. Raise the batch size to use {config.nUbatch}.
            </p>
          )}
        </div>
      )}

      {/* withoutUnsupportedDiffusionSettings forces tensorParallel back to false and the diffusion
          runner never reads it, so the switch flipped back under the pointer. */}
      {!isDiffusion && (
        <div className={ROW_CLASS}>
          <div className="flex min-w-0 items-center gap-1.5">
            <span className={LABEL_CLASS}>Tensor Parallelism</span>
            <InfoHint>
              Speeds up dense models across multiple GPUs. No effect on a single
              GPU, and MoE models don't benefit.
            </InfoHint>
          </div>
          <Switch
            className="panel-switch shrink-0"
            checked={config.tensorParallel}
            onCheckedChange={(checked) => update({ tensorParallel: checked })}
          />
        </div>
      )}

      {/* withoutUnsupportedDiffusionSettings forces disableVision back to false on a diffusion model
          and the runner never reads it, so the switch would flip back under the pointer. */}
      {!isDiffusion && (
        hideVision ? null : <VisionRow config={config} update={update} />
      )}

      {!isDiffusion && (
        <div className={ROW_CLASS}>
          <div className="flex min-w-0 items-center gap-1.5">
            <span className={LABEL_CLASS}>Reasoning Budget</span>
            <InfoHint>
              Maximum thinking tokens. -1 is unlimited and 0 turns reasoning
              off.
            </InfoHint>
          </div>
          <input
            type="number"
            min={-1}
            max={2_147_483_647}
            step={1}
            value={config.reasoningBudget}
            onChange={(event) => {
              const raw = event.target.value;
              if (raw === "") {
                update({ reasoningBudget: -1 });
                return;
              }
              const parsed = Number.parseInt(raw, 10);
              if (Number.isFinite(parsed)) {
                update({
                  reasoningBudget: Math.max(
                    -1,
                    Math.min(2_147_483_647, parsed),
                  ),
                });
              }
            }}
            aria-label="Reasoning Budget"
            className={NUMBER_INPUT_CLASS}
          />
        </div>
      )}

      {!isDiffusion && (
        <div className={ROW_CLASS}>
          <div className="flex min-w-0 items-center gap-1.5">
            <span className={LABEL_CLASS_WRAP}>Reasoning Budget Message</span>
            <InfoHint>
              Optional text added before the end-of-thinking tag when the budget
              runs out.
            </InfoHint>
          </div>
          <input
            type="text"
            value={config.reasoningBudgetMessage}
            placeholder="None"
            onChange={(event) => {
              if (isReasoningBudgetMessageValid(event.target.value)) {
                update({ reasoningBudgetMessage: event.target.value });
              }
            }}
            aria-label="Reasoning Budget Message"
            className={TEXT_INPUT_CLASS}
          />
        </div>
      )}

      <GpuMemorySettings
        config={config}
        update={update}
        layerCount={layerCount}
        moeLayerCount={moeLayerCount}
        isDiffusion={isDiffusion}
        gpuDevices={gpuDevices}
        gpuLayersInputRef={gpuLayersInputRef}
        moeLayersInputRef={moeLayersInputRef}
      />

      <ChatTemplateSetting config={config} onEditTemplate={onEditTemplate} />

      {/* Host-side knobs, after the ones that shape the model itself. All three are llama-server's
          own, and the diffusion runner launches no llama-server, so they are hidden for it. */}
      {!isDiffusion && (
        <>
          <LoadModeRow config={config} update={update} />

          <div className={ROW_CLASS}>
            <div className="flex min-w-0 items-center gap-1.5">
              <span className={LABEL_CLASS}>Checkpoints</span>
              <InfoHint>
                Checkpoints kept per slot (--ctx-checkpoints), which let a
                sliding-window model rewind instead of re-processing the prompt.
                Leave blank for the default ({CTX_CHECKPOINTS_LLAMA_DEFAULT}); 0
                disables them. Each one costs host memory.
              </InfoHint>
            </div>
            <input
              type="number"
              min={CTX_CHECKPOINTS_MIN}
              max={CTX_CHECKPOINTS_MAX}
              step={1}
              value={config.ctxCheckpoints ?? ""}
              placeholder="auto"
              onChange={(event) => {
                const raw = event.target.value;
                if (raw === "") {
                  update({ ctxCheckpoints: null });
                  return;
                }
                const parsed = Number.parseInt(raw, 10);
                if (Number.isFinite(parsed)) {
                  update({
                    ctxCheckpoints: Math.max(
                      CTX_CHECKPOINTS_MIN,
                      Math.min(CTX_CHECKPOINTS_MAX, parsed),
                    ),
                  });
                }
              }}
              aria-label="Context checkpoints per slot"
              className={NUMBER_INPUT_CLASS}
            />
          </div>

          <div className={ROW_CLASS}>
            <div className="flex min-w-0 items-center gap-1.5">
              <span className={LABEL_CLASS}>Cache RAM</span>
              <InfoHint>
                Host memory in MiB for caching prompt state evicted from a slot
                (--cache-ram), so a returning conversation is not re-processed.
                Leave blank for the default ({CACHE_RAM_LLAMA_DEFAULT}); 0
                disables it and -1 lifts the limit.
              </InfoHint>
            </div>
            <input
              type="number"
              min={CACHE_RAM_MIN}
              max={CACHE_RAM_MAX}
              step={1}
              value={config.cacheRam ?? ""}
              placeholder="auto"
              onChange={(event) => {
                const raw = event.target.value;
                if (raw === "") {
                  update({ cacheRam: null });
                  return;
                }
                const parsed = Number.parseInt(raw, 10);
                if (Number.isFinite(parsed)) {
                  update({
                    cacheRam: Math.max(
                      CACHE_RAM_MIN,
                      Math.min(CACHE_RAM_MAX, parsed),
                    ),
                  });
                }
              }}
              aria-label="Host prompt cache size in MiB"
              className={NUMBER_INPUT_CLASS}
            />
          </div>
        </>
      )}

      {/* Last, because it is the escape hatch for everything the rows above do not cover, and
          llama.cpp's last-wins parsing means these really are appended after them. GGUF only. */}
      {!isDiffusion && (
        <ExtraArgsRow
          config={config}
          update={update}
          onLoadableChange={onExtraArgsLoadableChange}
          draftKey={draftKey}
        />
      )}
    </>
  );
}

/** Pass-through llama-server arguments for this model. llama-server documents 283 flags and
 *  Unsloth manages about 115, so the long tail is a text box rather than 168 more controls.
 *  The boundary is `validate_extra_args`; this row shows that judgement early, plus a check
 *  against the flags THIS build documents. */
function ExtraArgsRow({
  config,
  update,
  onLoadableChange,
  draftKey,
}: {
  config: PerModelConfig;
  update: (patch: Partial<PerModelConfig>) => void;
  onLoadableChange: (loadable: boolean) => void;
  draftKey: string;
}) {
  const [catalog, setCatalog] = useState<LlamaFlagCatalog | null>(null);
  const adviceId = useId();
  // What is typed, not what is stored (argv tokens). On the draft, or the second editor
  // re-quotes a half-typed line into balanced text and judges it loadable.
  const edit = useSyncExternalStore(
    subscribeModelConfigDraft,
    () => readExtraArgsEditForDraft(draftKey),
  );
  const external = formatExtraArgs(config.llamaExtraArgs);
  // Comparing against what the edit published, not the config, is what stops a re-quote per
  // keystroke. Reset and hydration drop the edit outright.
  const text = edit && edit.source === external ? edit.text : external;

  // Re-read on invalidation, not only on mount: updating llama.cpp from the banner replaces the
  // binary while this panel stays open, and the old catalogue would judge arity against help
  // text that no longer describes the server.
  const [catalogEpoch, setCatalogEpoch] = useState(0);
  useEffect(
    () => subscribeLlamaFlagCatalog(() => setCatalogEpoch((epoch) => epoch + 1)),
    [],
  );
  useEffect(() => {
    let cancelled = false;
    loadLlamaFlagCatalog().then((loaded) => {
      if (!cancelled) {
        // Null is "cannot verify": adopted as well, or the row would keep checking against the
        // previous binary after an update it cannot read.
        setCatalog(loaded);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [catalogEpoch]);

  // Model Memory removes some of these before the launch: apply_model_memory_policy emits its
  // own load mode and strips the rest, so an --mlock typed here would be shown, saved, and
  // never passed. A failed read leaves the row quiet rather than claiming a removal.
  const [modelMemory, setModelMemory] = useState<ModelMemorySettings | null>(
    null,
  );
  useEffect(() => {
    let cancelled = false;
    loadModelMemorySettings()
      .then((loaded) => {
        if (!cancelled) {
          setModelMemory(loaded);
        }
      })
      .catch(() => {});
    const unsubscribe = subscribeModelMemorySettings(setModelMemory);
    return () => {
      cancelled = true;
      unsubscribe();
    };
  }, []);

  const diagnostics = diagnoseExtraArgs(text, catalog, {
    gpuSelectionActive: config.selectedGpuIds != null,
    manualGpuMemory: config.gpuMemoryMode === "manual",
    // Only manual mode with a resolved layer count of 0 or more rewrites --tensor-split; at Auto
    // layers the launcher drops it, so the value never reaches llama-server.
    gpuLayers: config.gpuLayers,
    // The same floor the batch control shows: with Slots blank the count is the server default
    // this page cannot see, so only the hard 2 holds. A build that clamps serves one slot
    // whatever is chosen, so an explicit Slots value must not raise the floor.
    batchFloor: effectiveBatchFloor(config.nParallel, catalog),
    keepResident: modelMemory?.keepResident ?? false,
    noRamReserve: modelMemory?.noRamReserve ?? false,
  });
  const tokenCount = parseExtraArgs(text).tokens.length;

  // The panel owns the Load button, and an error here is one validate_extra_args would refuse.
  // Reported up rather than only painted red, so the load is not started just to fail.
  const loadable = extraArgsAreLoadable(diagnostics);
  useEffect(() => {
    onLoadableChange(loadable);
    // On the draft too: only this row reads the raw text. An unprobed row may only LOWER the
    // verdict, or it clears a refusal another row verified; a parse failure still holds.
    if (catalog !== null || !loadable) {
      setExtraArgsEditLoadableForDraft(draftKey, loadable);
    }
    // Deliberately no cleanup: collapsing Advanced settings unmounts this row while the tokens
    // stay in the config and still go out with the load. The panel clears it on model change.
  }, [loadable, onLoadableChange, draftKey, catalog]);

  const commit = (next: string) => {
    const { tokens } = parseExtraArgs(next);
    // Before the update, so the config change it causes still matches this edit's own source.
    setExtraArgsEditForDraft(draftKey, {
      text: next,
      source: formatExtraArgs(tokens.length > 0 ? tokens : null),
    });
    // null, not [], so the panel's own "no flags" reads the same as the stored one; toApiOverride
    // turns it into the explicit [] that clears the server's copy.
    update({ llamaExtraArgs: tokens.length > 0 ? tokens : null });
  };

  return (
    <div className="space-y-2">
      <div className="flex min-w-0 items-center gap-1.5">
        <span className={LABEL_CLASS}>Extra Arguments</span>
        <InfoHint>
          <div className="flex flex-col gap-1.5">
            <div>
              Passed straight to llama-server after the settings above, so
              anything set in both is taken from here.
            </div>
            <div>
              Quote values with spaces or backslashes. Nothing runs a shell, so
              $HOME, ; and | are ordinary characters. Flags Unsloth owns, like
              the model and the port, are refused.
            </div>
          </div>
        </InfoHint>
      </div>
      {/* Grouped so the notes sit 4px under the field, as advice does elsewhere. */}
      <div className="space-y-1">
        <div className="panel-text-surface h-20 w-full overflow-hidden corner-squircle">
          <textarea
            value={text}
            onChange={(event) => commit(event.target.value)}
            spellCheck={false}
            placeholder="--rope-scaling yarn --yarn-orig-ctx 32768"
            aria-label="Extra llama-server arguments"
            aria-describedby={diagnostics.length > 0 ? adviceId : undefined}
            className="block size-full resize-none bg-transparent px-3.5 py-2.5 text-left font-mono text-ui-12 leading-relaxed text-foreground outline-none placeholder:text-muted-foreground"
          />
        </div>
        {(tokenCount > 0 || diagnostics.length > 0) && (
          <div id={adviceId} className="space-y-1">
            {tokenCount > 0 && (
              <p className="text-ui-11 text-muted-foreground">
                {tokenCount === 1 ? "1 argument" : `${tokenCount} arguments`}
              </p>
            )}
            {diagnostics.map((diagnostic) => (
              <p
                key={diagnostic.message}
                className={
                  diagnostic.level === "error"
                    ? "text-ui-11 text-red-500"
                    : diagnostic.level === "warning"
                      ? "text-ui-11 text-amber-500"
                      : "text-ui-11 text-muted-foreground"
                }
              >
                {diagnostic.message}
              </p>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

interface ModelConfigPageProps {
  target: ModelPickTarget;
  onBack?: () => void;
  onRun: (config: PerModelConfig, isDiffusion?: boolean) => void;
  loadedConfig?: PerModelConfig | null;
  loadedContextLength?: number | null;
  initialConfig?: PerModelConfig | null;
  isDiffusion?: boolean;
  variant?: "page" | "sidebar";
  /** Page variant only: render the built-in "Run settings" title block. A host that already shows
   *  the model name as its page heading turns this off. */
  showHeader?: boolean;
}

export function ModelConfigPage({
  target,
  onBack,
  onRun,
  loadedConfig = null,
  loadedContextLength = null,
  initialConfig = null,
  isDiffusion = false,
  variant = "page",
  showHeader = true,
}: ModelConfigPageProps) {
  const rememberId = useId();
  const platformDeviceType = usePlatformStore((s) => s.deviceType);
  // Apple Silicon specifically, and used ONLY for wording: "Unified" is what Apple calls its
  // pool, where an AMD APU's is "Shared". NOT the signal for capacity - see hasUnifiedMemory.
  const isAppleUnifiedMemory = usePlatformStore((s) => s.appleSilicon);
  const platformChatOnlyReason = usePlatformStore((s) => s.chatOnlyReason);
  const mlxKvQuantReason = useChatRuntimeStore((s) => s.mlxKvQuantReason);
  const chatTemplateOverrideReason = useChatRuntimeStore(
    (s) => s.chatTemplateOverrideReason,
  );
  const loadedChatTemplateOverride = useChatRuntimeStore(
    (s) => s.loadedChatTemplateOverride,
  );
  const loadedLlamaExtraArgs = useChatRuntimeStore((s) => s.loadedLlamaExtraArgs);
  const loadedGpuIds = useChatRuntimeStore((s) => s.loadedGpuIds);
  const loadedGpuIndexKind = useChatRuntimeStore((s) => s.loadedGpuIndexKind);
  const loadedCpuFallback = useChatRuntimeStore((s) => s.loadedCpuFallback);
  const residentModelLoading = useChatRuntimeStore((s) => s.modelLoading);
  const residentEstimateSettings = useChatRuntimeStore(
    useShallow(selectResidentEstimateSettings),
  );
  const mlxKvQuantNote = useChatRuntimeStore((s) => s.mlxKvQuantNote);
  const loadedMlxKvQuantRequested = useChatRuntimeStore(
    (s) => s.loadedMlxKvQuantRequested,
  );
  const isActiveModel = loadedConfig != null;
  const sharedVariantUnresolved = isRunConfigVariantUnresolved(target);
  const hfToken = useChatRuntimeStore((s) => s.hfToken);
  const activeNativePathToken = useChatRuntimeStore(
    (s) => s.activeNativePathToken,
  );
  const loadedDefaultChatTemplate = useChatRuntimeStore(
    (s) => s.defaultChatTemplate,
  );
  const loadedMaxContextLength = useChatRuntimeStore(
    (s) => s.maxContextLength,
  );
  // What settings are stored under, which is not always what loads; the probes keep target.id.
  const configId = target.configId ?? target.id;
  // FastFlowLM on the NPU takes a context length and nothing else.
  const targetIsNpu = isNpuModelId(target.id);
  const gpuDevices = useGpuDevices();
  const resolveInitial = () => {
    const resolved = resolveInitialConfig(configId, target.ggufVariant);
    if (loadedConfig) {
      return { config: loadedConfig, remembered: resolved.remembered };
    }
    if (initialConfig) {
      return {
        config: initialConfig,
        remembered:
          resolved.remembered &&
          perModelConfigsEqual(initialConfig, resolved.config),
      };
    }
    return resolved;
  };
  const draftKey = modelConfigDraftKey(configId, target.ggufVariant);
  const liveSignature = loadedConfigSignature(loadedConfig);
  // LAYOUT, above the prime: a live change remounts under the same key, and only layout
  // cleanups run before the new instance re-primes. Released passively it deleted its draft.
  useLayoutEffect(() => retainModelConfigDraft(draftKey), [draftKey]);
  // biome-ignore lint/correctness/useExhaustiveDependencies: liveSignature summarizes loadedConfig
  useLayoutEffect(() => {
    const resolved = resolveInitial();
    primeModelConfigDraft(
      draftKey,
      {
        config: reconcileConfigGpuSelection(
          resolved.config,
          isDiffusion,
          gpuDevices,
        ),
        remembered: resolved.remembered,
      },
      liveSignature,
    );
  }, [draftKey, liveSignature]);
  const draftSnapshot = useSyncExternalStore(
    subscribeModelConfigDraft,
    () => readModelConfigDraft(draftKey),
  );
  const initialFallback = useMemo(
    () => resolveInitial(),
    [configId, target.ggufVariant, loadedConfig, initialConfig],
  );
  const configState =
    draftSnapshot?.config ??
    reconcileConfigGpuSelection(initialFallback.config, isDiffusion, gpuDevices);
  const remember = draftSnapshot?.remember ?? initialFallback.remembered;
  const savedRemember =
    draftSnapshot?.savedRemember ?? initialFallback.remembered;
  // The peer's row may be refusing what is typed while this editor has none: Advanced starts
  // collapsed, and the check below judges the TOKENS, which formatExtraArgs rebalances.
  const sharedExtraArgsEdit = useSyncExternalStore(
    subscribeModelConfigDraft,
    () => readExtraArgsEditForDraft(draftKey),
  );
  const sharedExtraArgsCurrent =
    sharedExtraArgsEdit != null &&
    sharedExtraArgsEdit.source === formatExtraArgs(configState.llamaExtraArgs);
  const sharedExtraArgsRefused =
    sharedExtraArgsCurrent && sharedExtraArgsEdit.loadable === false;
  // This editor's row keeps its refusal after unmounting, so a peer that fixed the text lifts it.
  const sharedExtraArgsCleared =
    sharedExtraArgsCurrent && sharedExtraArgsEdit.loadable === true;
  // The live config, for the async reads below: an effect that closed over it would hold
  // whatever it was when the request started.
  const configRef = useRef(configState);
  configRef.current = configState;
  const rememberRef = useRef(remember);
  rememberRef.current = remember;
  const setConfig = useCallback(
    (action: SetStateAction<PerModelConfig>) => {
      // A plain value REPLACES, as the useState setter this stands in for does. Merging left
      // Reset's DEFAULT_PER_MODEL_CONFIG, which names no GPU field, unable to clear a pick.
      patchModelConfigDraft(draftKey, (current) =>
        typeof action === "function" ? action(current) : action,
      );
    },
    [draftKey],
  );
  const setRemember = useCallback(
    (value: boolean) => {
      setModelConfigDraftRemember(draftKey, value);
    },
    [draftKey],
  );
  const setSavedRemember = useCallback(
    (value: boolean) => {
      setModelConfigDraftSavedRemember(draftKey, value);
    },
    [draftKey],
  );
  const [speculativeFallback] = useState(readPersistedSpeculativeType);
  // Same substitution as speculativeFallback: only "manual" is persisted per model, so an absent
  // mode means "follow the standing preference" rather than Auto, and pricing the absence as
  // Auto rated a Manual launch against the wrong plan.
  const [gpuMemoryModeFallback] = useState(readPersistedGpuMemoryMode);
  const [templateOpen, setTemplateOpen] = useState(false);
  // Raised by the extra-arguments row when what is typed is something validate_extra_args would
  // refuse. Held by the panel rather than the row, since the row unmounts whenever Advanced
  // settings collapse while its tokens stay in the config.
  const [extraArgsLoadable, setExtraArgsLoadable] = useState(true);
  const [customConfigLoadable, setCustomConfigLoadable] = useState(true);
  // True until the server-row read below settles: a load started before it lands sends none of the
  // row's settings, and with Remember unchecked it forgets the row it never read.
  const [extraArgsHydrating, setExtraArgsHydrating] = useState(
    () => !isDiffusion,
  );
  // The row does not withdraw its own objection when it unmounts, or collapsing Advanced settings
  // would re-enable Load for arguments the backend refuses. Only a different model retires it.
  // biome-ignore lint/correctness/useExhaustiveDependencies: keyed on the model, not on the setter
  useEffect(() => {
    setExtraArgsLoadable(true);
    setExtraArgsHydrating(!isDiffusion);
  }, [configId, target.ggufVariant, target.isGguf, isDiffusion]);

  // Compare against what the backend was asked for, not what it applied: staging a new value
  // must retire a verdict that answered a different request.
  const chatTemplateOutcome =
    isActiveModel &&
    (configState.chatTemplateOverride ?? null) ===
      (loadedChatTemplateOverride ?? null)
      ? chatTemplateOverrideReason
      : null;
  const mlxKvQuantOutcome =
    isActiveModel &&
    (configState.mlxKvQuant ?? null) === (loadedMlxKvQuantRequested ?? null)
      ?  // Both, not either: dropping the note promises savings before the offset where quantization actually starts.
        [mlxKvQuantReason, mlxKvQuantNote].filter(Boolean).join(". ") || null
      : null;
  const servedByMlx = isServedByMlx(
    target.isGguf,
    platformDeviceType,
    platformChatOnlyReason,
  );
  // Read live, not snapshotted at mount: the sidebar copy stays mounted while collapsed.
  const advancedPreference = useSyncExternalStore(
    subscribeAdvancedSettingsOpen,
    readAdvancedSettingsOpen,
    () => null,
  );
  // Until the switch is used anywhere, a model carrying non-default advanced values opens the
  // section itself. Frozen at mount so editing a field back to its default cannot close it.
  const [autoOpenAdvanced, setAutoOpenAdvanced] = useState(() =>
    hasNonDefaultAdvanced(configState),
  );
  const [importedConfig, setImportedConfig] = useState<RunConfigImport | null>(
    null,
  );
  const handleSharedConfigImport = useCallback((imported: RunConfigImport) => {
    setImportedConfig(imported);
    if (Object.keys(imported.changes).length > 0) {
      setAutoOpenAdvanced(true);
    }
  }, []);
  // Frozen like the rest of the auto-open decision, so editing the width does not reopen the
  // section the user just closed.
  const [initialMlxKvQuant] = useState(() => configState.mlxKvQuant ?? null);
  // Applicability stays live, unlike the snapshot above: MLX can become available after mount,
  // and a width that starts applying then has to surface.
  const autoOpenForMlxKvQuant = servedByMlx && initialMlxKvQuant != null;
  const showAdvanced =
    advancedPreference ?? (autoOpenAdvanced || autoOpenForMlxKvQuant);
  const toggleAdvanced = saveAdvancedSettingsOpen;
  const contextInputRef = useRef<NumericValueInputHandle>(null);
  const maxSeqLengthInputRef = useRef<NumericValueInputHandle>(null);
  const gpuLayersInputRef = useRef<NumericValueInputHandle>(null);
  const moeLayersInputRef = useRef<NumericValueInputHandle>(null);
  const nativePathToken =
    target.meta.nativePathToken ??
    (isActiveModel ? activeNativePathToken : null);
  const templateDefaults = useDefaultChatTemplate(
    target.id,
    target.ggufVariant,
    templateOpen,
    nativePathToken,
  );
  const modelMaxPosition = useModelMaxPositionEmbeddings(
    target.id,
    !target.isGguf && !targetIsNpu,
  );
  const hasLoadedDefaultTemplate =
    isActiveModel && loadedDefaultChatTemplate != null;
  const resolvedDefaultTemplate = hasLoadedDefaultTemplate
    ? loadedDefaultChatTemplate
    : templateDefaults.template;
  const resolvedDefaultLoading = hasLoadedDefaultTemplate
    ? false
    : templateDefaults.loading;

  // Fetch GGUF header dims to size the GPU Memory sliders; the context also fills in below.
  const contextFetchKey = target.isGguf && !sharedVariantUnresolved
    ? `${target.id}\n${target.ggufVariant ?? ""}\n${hfToken || ""}\n${nativePathToken ?? ""}`
    : null;
  const [fetchedStagedDims, setFetchedStagedDims] = useState<{
    key: string;
    contextLength: number | null;
    layerCount: number | null;
    moeLayerCount: number | null;
    isDiffusion?: boolean;
    diffusionUnknown?: boolean;
  } | null>(null);
  useEffect(() => {
    if (contextFetchKey == null) {
      return;
    }
    let cancelled = false;
    const settleWithoutMetadata = () => {
      if (!cancelled) {
        setFetchedStagedDims({
          key: contextFetchKey,
          contextLength: null,
          layerCount: null,
          moeLayerCount: null,
          isDiffusion: undefined,
        });
      }
    };
    void (async () => {
      const preparedToken = await prepareHfTokenForUse(hfToken || null);
      if (cancelled) {
        return;
      }
      if (!preparedToken.proceed) {
        settleWithoutMetadata();
        return;
      }
      const dims = await fetchGgufStagedMetadata({
        model_path: target.id,
        gguf_variant: target.ggufVariant ?? null,
        hf_token: preparedToken.token,
        nativePathToken,
      });
      if (!cancelled) {
        setFetchedStagedDims({ key: contextFetchKey, ...dims });
      }
    })().catch(() => {
      settleWithoutMetadata();
    });
    return () => {
      cancelled = true;
    };
  }, [
    contextFetchKey,
    target.id,
    target.ggufVariant,
    hfToken,
    nativePathToken,
  ]);
  const stagedDims =
    fetchedStagedDims?.key === contextFetchKey ? fetchedStagedDims : null;
  // Tri-state on purpose: an inconclusive probe stays undefined so onRun hands "unknown" on.
  // Collapsing it to false would let a compare pane inherit another model's split (#7574).
  const classifiedIsDiffusion = resolveStagedDiffusionClassification(
    isDiffusion,
    stagedDims,
  );
  const resolvedIsDiffusion = classifiedIsDiffusion === true;
  // Speech, music and ASR GGUFs the backend runs on its audio runtime: no llama-server launches,
  // so none of its knobs apply. Their own options live under Advanced on the Audio page.
  const audioRuntimeGguf =
    target.isGguf && isAudioRuntimeGguf(target.id, target.meta.audioType);

  // The one field on this page whose stored value the local config may never have seen:
  // llama_extra_args can be set through the overrides API with no UI involved, so an empty box
  // would read as "none" and the first edit would drop them. Fetched, not guessed. A verdict
  // reached before the catalogue arrived did not know this build's flags, so while the row is
  // unmounted the panel re-judges the config once the catalogue lands.
  const [hiddenCatalogEpoch, setHiddenCatalogEpoch] = useState(0);
  useEffect(
    () =>
      subscribeLlamaFlagCatalog(() =>
        setHiddenCatalogEpoch((epoch) => epoch + 1),
      ),
    [],
  );
  // biome-ignore lint/correctness/useExhaustiveDependencies: the arguments, the section and the binary are the inputs
  useEffect(() => {
    if (showAdvanced || !target.isGguf || resolvedIsDiffusion) {
      return;
    }
    const args = configState.llamaExtraArgs;
    if (args == null || args.length === 0) {
      // The row leaves its objection standing when it unmounts, because those tokens still go out
      // with the load. Once there are none there is nothing to object to: Reset with Advanced
      // collapsed used to leave Load disabled.
      setExtraArgsLoadable(true);
      return;
    }
    let cancelled = false;
    loadLlamaFlagCatalog().then((catalog) => {
      if (cancelled || !catalog) {
        // Null is "cannot verify": leaving the standing verdict alone is the same benefit of the doubt
        // the row gives an unprobed build.
        return;
      }
      const loadable = extraArgsAreLoadable(
        diagnoseExtraArgs(formatExtraArgs(args), catalog, {
          gpuSelectionActive: configState.selectedGpuIds != null,
          manualGpuMemory: configState.gpuMemoryMode === "manual",
          // The server-wide default when the Slots field is blank: that is the count the launch will
          // serve, and llama-server aborts on a batch below it.
          batchFloor: effectiveBatchFloor(configState.nParallel, catalog),
        }),
      );
      // Only ever tightens. This judges the TOKENS, and formatExtraArgs quotes them back into a
      // balanced string, so an unclosed quote the row objected to reads as fine here and raising
      // the verdict would re-enable Load over unfinished input.
      if (!loadable) {
        setExtraArgsLoadable(false);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [
    showAdvanced,
    configState.llamaExtraArgs,
    configState.selectedGpuIds,
    configState.gpuMemoryMode,
    configState.nParallel,
    target.isGguf,
    resolvedIsDiffusion,
    hiddenCatalogEpoch,
  ]);

  // The server copy is shared by Desktop, LAN, and tunnel origins, so hydrate the whole
  // remembered config here; localStorage is only the immediate seed. This also runs while
  // Advanced is closed, since the row reaches every load whether or not it is shown.
  // biome-ignore lint/correctness/useExhaustiveDependencies: the model is the identity
  useEffect(() => {
    if (resolvedIsDiffusion) {
      // A diffusion model runs through the shim, which appends no llama-server flags, so it keeps
      // Load free of this read.
      setExtraArgsHydrating(false);
      return;
    }
    // The order the auto-switch loader tries, and for the same reason: the settings UI keys a local
    // row by the path it loads from while configId is a derived alias, so reading the alias
    // first let an older entry stay the one API loads apply.
    const loadId = target.id;
    const fileVariant =
      !target.ggufVariant && loadId.toLowerCase().endsWith(".gguf")
        ? ggufQuantLabel(loadId.replace(/\\/g, "/").split("/").pop() ?? loadId)
        : null;
    const keys = [
      modelOverrideKey(loadId, target.ggufVariant),
      modelOverrideKey(configId, target.ggufVariant),
      loadId,
      ...(fileVariant ? [`${loadId}:${fileVariant}`] : []),
      configId,
    ].filter((key, index, all) => all.indexOf(key) === index);
    // The draft alone, never a string built from `keys`: the hosts derive different candidate
    // lists. Retaining an unedited draft clears it, so a fresh editor still sees a newer row.
    if (isExtraArgsHydratedForDraft(draftKey)) {
      setExtraArgsHydrating(false);
      return;
    }
    let cancelled = false;
    // What the config held BEFORE the request went out. Anything else at the end of it was typed
    // while the request was in flight, and sanitizing that would rewrite live input.
    const configAtStart = configRef.current;
    const storedAtStart = resolveInitialConfig(configId, target.ggufVariant);
    const rememberAtStart = rememberRef.current;
    const localAtStart = configAtStart.llamaExtraArgs;
    // The denylist, not the catalogue: sanitizing a stored list needs only the flags Unsloth
    // refuses, and that route answers without running `llama-server --help`. A last-resort
    // release, so a request that never settles cannot disable Load for good.
    const release = setTimeout(() => setExtraArgsHydrating(false), 15000);
    Promise.all([
      // Resolved by the backend, which owns the rules; the local resolver stays as the fallback for
      // a backend that predates the parameter.
      fetchLoadModelOverride(loadId, configId, target.ggufVariant, keys).then(
        (row) => panelOverrideRow(row, target.isGguf),
      ),
      target.isGguf ? loadManagedLlamaFlags() : null,
    ])
      .then(([resolvedOverride, managed]) => {
        // Marked here rather than before the request: StrictMode replays the effect, so a key marked
        // up front would leave the first fetch cancelled and the box never filled in development.
        if (cancelled) {
          return;
        }
        markExtraArgsHydratedForDraft(draftKey);
        const resolvedArgs = {
          tokens: resolvedOverride?.llama_extra_args ?? [],
          explicit: Array.isArray(resolvedOverride?.llama_extra_args),
        };
        // Through the resolver, not a literal lookup: the backend folds identities and reads whole
        // entries in its own order. Sanitised before it becomes a request, since hydrating turns a
        // stored list into an EXPLICIT one that /load validates strictly, so an install upgraded
        // across a denylist change would otherwise stop loading a model that worked yesterday.
        const stored = sanitizeStoredExtraArgs(
          resolvedArgs.tokens,
          managed?.managed ?? new Set<string>(),
          // The host's bounds, not the constants: a Windows server takes 24 KiB and holds a
          // quoted-command budget as well, so trimming to 32 KiB here sends a list /load 400s on.
          {
            maxBytes: managed?.maxBytes,
            windowsCommandBudget: managed?.windowsCommandBudget,
          },
        );
        // A list this build refuses can equally have come from local storage, saved by a build that
        // still allowed it, and nothing else would catch it while Advanced stays collapsed.
        const local = target.isGguf
          ? configRef.current.llamaExtraArgs
          : undefined;
        // Kept for the merge below as well as for the box: a row that carries no arguments leaves the
        // local list standing, and handing back a refused list would re-enable Load.
        let sanitizedLocal = localAtStart;
        if (local != null && local.length > 0 && local === localAtStart) {
          const cleaned = sanitizeStoredExtraArgs(
            local,
            managed?.managed ?? new Set<string>(),
            {
              maxBytes: managed?.maxBytes,
              windowsCommandBudget: managed?.windowsCommandBudget,
            },
          );
          if (cleaned.length !== local.length) {
            sanitizedLocal = cleaned.length > 0 ? cleaned : null;
            setConfig((current) =>
              current.llamaExtraArgs === local
                ? { ...current, llamaExtraArgs: sanitizedLocal }
                : current,
            );
          }
        }
        // The row as it should be read: its own fields, with the arguments it carries sanitized against
        // what this build refuses.
        const resolvedRow = resolvedOverride
          ? {
              ...resolvedOverride,
              ...(resolvedArgs.explicit ? { llama_extra_args: stored } : {}),
            }
          : null;
        const serverConfig = resolvedRow
          ? fromApiOverride(resolvedRow, {
              ...configAtStart,
              llamaExtraArgs: sanitizedLocal,
            })
          : null;
        // What hydration would leave in the config: the row's list when it carries one, this browser's
        // when it does not. Judged as a whole, or a local flag the expanded row already refused is
        // declared loadable by a verdict read off the empty server list.
        const hydratedArgs = serverConfig?.llamaExtraArgs ?? stored;
        const hydratedIsLoadable =
          !target.isGguf || hydratedArgs.length === 0
            ? true
            : extraArgsAreLoadable(
                diagnoseExtraArgs(
                  formatExtraArgs(hydratedArgs),
                  {
                    flags: {},
                    managed: managed?.managed ?? new Set<string>(),
                    switches: new Set<string>(),
                    maxBytes: managed?.maxBytes ?? 0,
                    windowsCommandBudget: managed?.windowsCommandBudget ?? 0,
                    defaultParallelSlots: managed?.defaultParallelSlots ?? 0,
                    parallelSlotsClamped:
                      managed?.parallelSlotsClamped ?? false,
                    probeOk: false,
                  },
                  {
                    batchFloor: effectiveBatchFloor(
                      serverConfig?.nParallel ?? configRef.current.nParallel,
                      managed,
                    ),
                  },
                ),
              );

        // The shared row outranks the local seed for every field it carries, so LAN and Desktop cannot
        // show different remembered values; fromApiOverride keeps the rest of this browser's config,
        // since an absent field is as much a gap in the mirror as a chosen default. Never over an
        // edit made while the request was in flight.
        // The edited check is load-bearing: an edit the OTHER editor made before this read
        // started is already in configAtStart, so the comparison below reads as untouched.
        if (
          resolvedRow &&
          serverConfig &&
          !isModelConfigDraftEdited(draftKey) &&
          configRef.current === configAtStart &&
          rememberRef.current === rememberAtStart
        ) {
          const storedConfig = resolveInitialConfig(
            configId,
            target.ggufVariant,
          );
          if (perModelConfigStorageChanged(storedAtStart, storedConfig)) {
            return;
          }
          setExtraArgsLoadable(hydratedIsLoadable);
          replaceModelConfigDraft(draftKey, serverConfig, {
            remember: true,
            savedRemember: true,
          });
          if (hasNonDefaultAdvanced(serverConfig)) {
            setAutoOpenAdvanced(true);
          }
          // Unconditionally, because savePerModelConfig says "no settings" by DELETING the entry: a merge
          // that comes out default is a clear that has to travel. Skipping it stranded the old flag
          // for model-selector's quick select; writing when no record exists is already a no-op.
          const rememberedConfig = fromApiOverride(
            resolvedRow,
            storedConfig.config,
          );
          // Same budget as any other write, so the same clean-up: eviction is silent and still reports
          // success, and a dropped model would keep applying its server row to API loads. Not a
          // Forget: only the mirrored fields go.
          const hydrationEvicted: {
            modelId: string;
            ggufVariant: string | null;
          }[] = [];
          // Checked for the same reason the Save path checks it: the write can fail outright and say so
          // in the return rather than throwing. Marked saved regardless, the panel would claim the
          // settings are remembered while quick select and background loads, which read
          // resolveInitialConfig and never open this panel, still saw the stale record or none.
          const hydrationSaved = savePerModelConfig(
            configId,
            target.ggufVariant,
            rememberedConfig,
            hydrationEvicted,
          );
          setSavedRemember(hydrationSaved);
          for (const dropped of hydrationEvicted) {
            syncModelOverride(dropped.modelId, dropped.ggufVariant, null, {
              keepLaunchFlags: true,
            });
          }
          return;
        }
        if (stored.length === 0) {
          // An EXPLICIT empty row is a decision, not an absence: the settings page writes one when the
          // box is cleared for a quant whose bare-repository row still carries arguments. Left
          // undefined the panel omits the field on Load, and /load carries the resident model's
          // arguments over. Only when nothing was typed here meanwhile.
          const local = configRef.current.llamaExtraArgs;
          if (resolvedArgs.explicit && local === undefined) {
            setExtraArgsLoadable(true);
            setConfig((current) =>
              current.llamaExtraArgs === undefined
                ? { ...current, llamaExtraArgs: [] }
                : current,
            );
          }
          return;
        }
        // Read from a ref rather than inside the updater below: an updater must stay free of side
        // effects (StrictMode calls it twice), and this decides one.
        if (configRef.current.llamaExtraArgs !== undefined) {
          // Typed into while this was in flight: the row is judging that text and its verdict is the
          // live one, so this answer about the stored list must not overwrite either.
          return;
        }
        setExtraArgsLoadable(hydratedIsLoadable);
        setConfig((current) =>
          // Guarded again, because the ref is only as fresh as the last render.
          current.llamaExtraArgs === undefined
            ? { ...current, llamaExtraArgs: stored }
            : current,
        );
        // The frozen snapshot above was taken before this answer arrived, so without this a model whose
        // arguments live only on the server opens looking like every default. A preference wins.
        setAutoOpenAdvanced(true);
      })
      .catch(() => {
        // Nothing to say: the panel is still usable, and the load would report a real problem with the
        // overrides service far more clearly.
      })
      .finally(() => {
        // Including the failure: an overrides service that is down must not leave Load disabled for good.
        if (!cancelled) {
          setExtraArgsHydrating(false);
        }
      });
    return () => {
      cancelled = true;
      clearTimeout(release);
    };
  }, [
    configId,
    target.id,
    target.ggufVariant,
    target.isGguf,
    resolvedIsDiffusion,
    draftKey,
  ]);
  const config = reconcileConfigGpuSelection(
    configState,
    resolvedIsDiffusion,
    gpuDevices,
  );
  // Held for the window where Run is waiting on a budget PUT rather than on the load it looks like it started.
  const [budgetSettling, setBudgetSettling] = useState(false);
  // The budget is on no per-model field, so changing it leaves this page at its baseline and the
  // Reload button disabled, with the row asking for a reload the user could not start. Read
  // off the same publish the row uses.
  const [budgetReloadRequired, setBudgetReloadRequired] = useState(false);
  useEffect(
    () =>
      subscribeVramBudgetSettings((next) => {
        setBudgetReloadRequired(next.reloadRequired);
      }),
    [],
  );
  const stagedMetadataPending =
    contextFetchKey != null &&
    stagedDims == null &&
    (config.gpuMemoryMode === "manual" ||
      config.selectedGpuIds != null ||
      config.nBatch != null ||
      config.nUbatch != null);
  const gpuIndexKind =
    pinnableGpuContext(gpuDevices, resolvedIsDiffusion).indexKind ?? null;
  const handleSharedConfigEdit = () => {
    cancelRunConfigImportForEdit(draftKey);
    setImportedConfig(null);
  };
  const update = (patch: Partial<PerModelConfig>) => {
    handleSharedConfigEdit();
    // Every control lands here and nothing else does: the hydration effect's own sanitising
    // writes go through setConfig, and marking those would have the read refuse its result.
    markModelConfigDraftEdited(draftKey);
    setConfig((current) => ({
      ...reconcileConfigGpuSelection(current, resolvedIsDiffusion, gpuDevices),
      ...patch,
    }));
  };

  // True for every mode that takes a draft depth, DSpark included, so this gates the Draft
  // Tokens row rather than naming a drafter.
  const showDraftTokens =
    config.speculativeType != null &&
    DRAFT_N_MAX_SPEC_TYPES.has(config.speculativeType);
  // Narrower than the row above: the dtype needs a second context, and only the sidecar modes
  // always load one. MTP may read baked-in heads out of the target GGUF.
  const showSpecDraftCacheDtype =
    config.speculativeType != null &&
    SEPARATE_DRAFT_MODEL_SPEC_TYPES.has(config.speculativeType);
  const nativeContextLength =
    target.meta.contextLength ?? stagedDims?.contextLength ?? null;
  const activeLoadedContext =
    isActiveModel && target.isGguf ? loadedContextLength : null;
  // resolveLoadMaxSeqLength returns 0 for a builtin-default GGUF load before it looks at the
  // resident context, so the estimate must not fall back to it either.
  const activePresetSource = useChatRuntimeStore((s) => s.activePresetSource);
  const minContext = CONTEXT_LENGTH_MIN;
  const maxContext = Math.max(
    minContext,
    Math.max(
      nativeContextLength ?? 0,
      activeLoadedContext ?? 0,
      config.customContextLength ?? 0,
    ) || 32768,
  );
  const contextValue = Math.min(
    Math.max(
      config.customContextLength ??
        activeLoadedContext ??
        nativeContextLength ??
        maxContext,
      minContext,
    ),
    maxContext,
  );
  const contextIsAuto = config.customContextLength == null;
  const contextInputValue = contextIsAuto
    ? Math.min(
        Math.max(
          activeLoadedContext ?? AUTO_OFFLOAD_CONTEXT_LENGTH,
          minContext,
        ),
        maxContext,
      )
    : contextValue;
  const contextSliderValue = contextIsAuto ? 0 : contextValue;
  const setContextLength = (v: number) => update({ customContextLength: v });
  const setContextSliderValue = (v: number) =>
    update({ customContextLength: v === 0 ? null : v });
  const rawBaseline = loadedConfig ?? DEFAULT_PER_MODEL_CONFIG;
  const baseline = resolvedIsDiffusion
    ? withoutUnsupportedDiffusionSettings(rawBaseline, gpuIndexKind)
    : rawBaseline;
  const platform = usePlatformStore();
  const targetIsMlx = isServedByMlx(
    target.isGguf,
    platform.deviceType,
    platform.chatOnlyReason,
  );
  // Backends that pin in customContextLength as GGUF does, so unpinned sends nothing.
  const pinsContextLength = targetIsMlx || targetIsNpu;
  const atBaseline = perModelConfigsEqual(config, baseline, {
    followGlobal: true,
  });
  // The fitted value is an outcome, not an override. Auto stays at the default even
  // when a loaded model reports less than its native context. A non-GGUF pin is an
  // override too, read from whichever field it was saved in.
  const contextAtDefault = !target.isGguf
    ? savedContextPin(config) == null
    : config.customContextLength == null;
  const atDefault =
    contextAtDefault &&
    perModelConfigsEqual(
      { ...config, customContextLength: null },
      DEFAULT_PER_MODEL_CONFIG,
    );
  const nativeMaxSeqLength =
    floorMaxSeqLength(
      targetIsNpu
        ? target.meta.contextLength
        : modelMaxPosition.maxPositionEmbeddings,
    ) ?? MAX_SEQ_LENGTH_MAX;
  // The pin, else the length a self-sizing backend would serve, so the control states a
  // context rather than declining to. Only an unread window falls back to the app default,
  // and Reset clears the pin to null so no fallback may rebuild one from a runtime value.
  // Reported as it stands, not snapped to the request step: 2,056 would read 2,048.
  const servedWindow = (value: unknown) =>
    typeof value === "number" && Number.isFinite(value) && value > 0
      ? Math.floor(value)
      : null;
  const mlxNativeWindow = targetIsMlx
    ? servedWindow(modelMaxPosition.maxPositionEmbeddings)
    : null;
  // What a load would serve. The backend clamps an auto-sized window to the request
  // ceiling, so a wider native one (Scout declares 10,485,760) would name a length no
  // load can serve. Native above stays raw: metadata, not a promise.
  const mlxProspectiveWindow =
    mlxNativeWindow == null
      ? null
      : Math.min(mlxNativeWindow, MAX_SEQ_LENGTH_MAX);
  // An auto-fit-below-native GGUF shows activeLoadedContext while
  // customContextLength stays null. If the user fixes GPU Layers (Manual) and
  // remembers, pin that shown context so a later fresh load keeps the fitted
  // placement instead of sending native/0 for fixed layers and recreating the OOM.
  const loadableConfig = resolvedIsDiffusion
    ? withoutUnsupportedDiffusionSettings(config, gpuIndexKind)
    : config;
  // A model classified as diffusion after the box was typed into keeps the row's objection while
  // the arguments are stripped from what loads, and the row does not withdraw it on unmount.
  // Retired here, or Load stays disabled over arguments the request no longer carries.
  // biome-ignore lint/correctness/useExhaustiveDependencies: keyed on the classification, not on the setter
  useEffect(() => {
    if (resolvedIsDiffusion) {
      setExtraArgsLoadable(true);
    }
  }, [resolvedIsDiffusion]);
  const pinFixedLayerContext =
    target.isGguf &&
    loadableConfig.gpuMemoryMode === "manual" &&
    loadableConfig.gpuLayers != null &&
    loadableConfig.gpuLayers >= 0 &&
    loadableConfig.customContextLength == null &&
    activeLoadedContext != null;
  // Kept as-is so isDefaultConfig clears a remembered override rather than pinning the
  // app default; the write rule already settled which field holds the pin.
  const runtimeConfig = target.isGguf
    ? pinFixedLayerContext
      ? { ...loadableConfig, customContextLength: activeLoadedContext }
      : loadableConfig
    : loadableConfig;
  const runtimeGpuMemoryMode =
    runtimeConfig.gpuMemoryMode ?? gpuMemoryModeFallback;
  // Priced against the config that would actually load, at the context on screen. Diffusion
  // stands down, since its runner allocates on a different plan. The tri-state is read as a
  // tri-state, not through resolvedIsDiffusion: a GGUF still being classified may be
  // DiffusionGemma, and guessing paints a footprint from the wrong plan that never clears.
  // A custom INI owns llama.cpp tuning: the managed rows lock and Studio cannot price it.
  const customActive =
    config.llamaCppConfig?.mode === "custom" && !resolvedIsDiffusion;
  const memoryEstimateRequest =
    !customActive &&
    shouldRequestMemoryEstimate({
      isGguf: Boolean(target.isGguf),
      isAppleUnifiedMemory,
      classifiedIsDiffusion,
    })
      ? {
          modelPath: target.id,
          ggufVariant: target.ggufVariant ?? null,
          hfToken: hfToken || null,
          nativePathToken,
          // The context the Load button sends, not the one the control displays: an unset length with no
          // header yet shows 32,768 and loads at native.
          nCtx: resolveEstimateContext(
            runtimeConfig.customContextLength ?? null,
            activeLoadedContext,
            // The two shapes where resolveLoadMaxSeqLength answers 0 before it reaches the resident
            // context: --fit owns the sizing, or a builtin-default preset on a GGUF load.
            (target.isGguf === true &&
              runtimeGpuMemoryMode === "manual" &&
              (runtimeConfig.gpuLayers ?? GPU_LAYERS_AUTO) < 0) ||
              (target.isGguf === true && activePresetSource === "builtin-default"),
          ),
          cacheTypeKv: runtimeConfig.kvCacheDtype,
          maxSeqLength: target.isGguf
            ? null
            : resolveMlxEstimateContext(savedContextPin(config)),
          mlxKvQuant: runtimeConfig.mlxKvQuant ?? null,
          nParallel: runtimeConfig.nParallel,
          nBatch: runtimeConfig.nBatch,
          nUbatch: runtimeConfig.nUbatch,
          ctxCheckpoints: runtimeConfig.ctxCheckpoints ?? null,
          // The same substitution applyPerModelConfigToRuntime makes at load: a model with no per-model
          // override sends null, which the backend reads as Auto, while the selector has been showing
          // the global fallback. With the global Off and an 11 GB DSpark sidecar in the repo, the row
          // charged the sidecar for a load that disables it.
          speculativeType: runtimeConfig.speculativeType ?? speculativeFallback ?? null,
          specDraftNMax: runtimeConfig.specDraftNMax,
          specDraftCacheType: runtimeConfig.specDraftCacheDtype ?? null,
          tensorParallel: runtimeConfig.tensorParallel,
          disableVision: runtimeConfig.disableVision,
          gpuMemoryMode: runtimeGpuMemoryMode,
          gpuLayers:
            runtimeConfig.gpuLayers != null &&
            runtimeConfig.gpuLayers !== GPU_LAYERS_AUTO
              ? runtimeConfig.gpuLayers
              : null,
          nCpuMoe: runtimeConfig.nCpuMoe ?? null,
          selectedGpuIds: runtimeConfig.selectedGpuIds ?? null,
          llamaExtraArgs: runtimeConfig.llamaExtraArgs ?? null,
        }
      : null;
  const memoryEstimate = useMemoryEstimate(memoryEstimateRequest);
  const mlxFittedWindow = targetIsMlx
    ? servedWindow(memoryEstimate.estimate?.contextFitted)
    : null;
  const mlxServedWindow = resolveMlxServedWindow(
    targetIsMlx && isActiveModel ? servedWindow(loadedContextLength) : null,
    mlxFittedWindow,
    mlxProspectiveWindow,
  );
  // Auto on the NPU is FastFlowLM's default held to the model's limit, or what the resident got.
  const npuServedWindow = targetIsNpu
    ? ((isActiveModel ? servedWindow(loadedContextLength) : null) ??
      Math.min(NPU_DEFAULT_CONTEXT_LENGTH, nativeMaxSeqLength))
    : null;
  const maxSeqLengthValue =
    servedWindow(savedContextPin(config)) ??
    mlxServedWindow ??
    npuServedWindow ??
    clampMaxSeqLength(DEFAULT_MAX_SEQ_LENGTH, nativeMaxSeqLength);
  const maxSeqLengthMax = Math.min(
    MAX_SEQ_LENGTH_MAX,
    Math.max(nativeMaxSeqLength, maxSeqLengthValue),
  );
  // No resident credit without a reported context; pending settings cannot price it.
  // activeLoadedContext is GGUF-only; an MLX resident reports its served window here.
  const residentContext = servedWindow(
    targetIsMlx && isActiveModel ? loadedContextLength : activeLoadedContext,
  );
  const residentEstimateRequest = resolveResidentEstimateRequest(
    isActiveModel ? memoryEstimateRequest : null,
    residentEstimateSettings,
    residentContext,
    targetIsMlx && !residentModelLoading
      ? { kvQuant: loadedMlxKvQuantRequested ?? null }
      : undefined,
  );
  const residentEstimate = useMemoryEstimate(residentEstimateRequest, {
    refreshMemory: true,
  });
  // Only settled estimates can establish resident credit.
  const reclaimableEstimate =
    residentEstimateRequest &&
    residentEstimate.estimate?.available &&
    !residentEstimate.loading &&
    !residentEstimate.stale
      ? residentEstimate.estimate
      : null;
  const reclaimableCredit = resolveReclaimableMemoryCredit(
    reclaimableEstimate,
    { ids: loadedGpuIds, indexKind: loadedGpuIndexKind },
    {
      ids: runtimeConfig.selectedGpuIds ?? null,
      indexKind: runtimeConfig.selectedGpuIndexKind ?? null,
    },
    {
      cpuFallback: loadedCpuFallback,
      devices: gpuDevices,
      // Fitted placement does not report its final layer count.
      gpuPlacementKnown:
        residentEstimateRequest?.gpuMemoryMode === "manual" &&
        residentEstimateRequest.gpuLayers != null &&
        residentEstimateRequest.gpuLayers >= 0 &&
        !loadedLlamaExtraArgs?.length,
      appleUnifiedMemory: isAppleUnifiedMemory,
    },
  );
  const [memoryBreakdownOpen, setMemoryBreakdownOpen] = useState(false);
  const inferenceGpu = useInferenceGpuInfo();
  // A pin can only draw on the cards it names, so the verdict is measured against those: judging
  // a one-card pin against a two-card total called an 8 GB load a fit on 16 GB it cannot reach.
  const pinnedGpuIds = runtimeConfig.selectedGpuIds;
  // Whether the devices THIS LOAD will use draw on one pool with the rest of the system, from
  // the backend's per-device unified_memory flag rather than from the platform: adding VRAM to
  // system RAM on a shared pool counts the same bytes twice. `.every()` is the right question
  // for CAPACITY, since one independent-memory device means real VRAM beside system RAM: reading
  // the host-wide flag collapsed totalCapacityGb from 143.5 to 15.5 GiB, and `.some()` under a pin
  // reported 62.1. The empty set is excluded explicitly, since `[].every()` is true, and the Apple
  // fallback stays host-wide, covering the window before the per-device probe lands. use-gpu-info.ts
  // deliberately uses `.some()` for its own flag, which answers a different question.
  const hasUnifiedMemory = useMemo(() => {
    if (isAppleUnifiedMemory) return true;
    const governing =
      pinnedGpuIds && pinnedGpuIds.length > 0
        ? gpuDevices.filter((device) => pinnedGpuIds.includes(device.index))
        : gpuDevices;
    if (governing.length === 0) return false;
    return governing.every((device) => device.unifiedMemory === true);
  }, [gpuDevices, pinnedGpuIds, isAppleUnifiedMemory]);
  // The VRAM Budget slider caps what the next load may claim per GPU, so the verdict is measured
  // against the capped figure or the row contradicts the control above it. Subscribed as well
  // as read once, since dragging must re-classify without a remount. Seeded with the loader's
  // own default rather than a full card, since the read is async and null on failure.
  // Seeded with the loader's own default: the read is async and returns null on an older backend, and
  // in both windows the launch still applies VRAM_FRACTION_DEFAULT. Starting at 1 claimed a reserve
  // no setting of that slider ever gives back.
  const [memoryVramBudgetFraction, setMemoryVramBudgetFraction] =
    useState(DEFAULT_VRAM_FRACTION);
  useEffect(() => {
    let cancelled = false;
    loadVramBudgetSettings().then((loaded) => {
      if (!cancelled && loaded) {
        setMemoryVramBudgetFraction(loaded.fraction);
      }
    });
    const unsubscribe = subscribeVramBudgetSettings((next) => {
      setMemoryVramBudgetFraction(next.fraction);
    });
    return () => {
      cancelled = true;
      unsubscribe();
    };
  }, []);
  // What is free RIGHT NOW on the cards this load may use: _select_gpus admits on free-minus-
  // reserve, not on totals. WARNS, never refuses: the bytes a pending load reclaims are mostly
  // the resident model's own, which cannot be attributed per device from here. A fixed Manual
  // placement is launched verbatim, so the server-wide budget never reaches the planner.
  // A fixed Manual placement is launched verbatim -- load_model empties its probed GPU set and emits
  // --gpu-layers N --fit off -- so the VRAM Budget never reaches the planner. Discounting capacity
  // by it called a 16 GiB fixed placement on a 24 GiB card over budget at 50%. Auto is still budgeted.
  const memoryBudgetGovernsLaunch =
    runtimeGpuMemoryMode !== "manual" ||
    (runtimeConfig.gpuLayers ?? GPU_LAYERS_AUTO) < 0;
  const memoryEffectiveBudgetFraction = memoryBudgetGovernsLaunch
    ? memoryVramBudgetFraction
    : 1;
  // _HOST_RAM_HEADROOM_MIB: the 2 GiB the loader keeps for the rest of the system before
  // admitting an offloaded load. The HOST reading, not the sum-shaped one beside it, which is
  // zeroed whenever ANY device shares system RAM. Hoisted for the free-capacity memo.
  const memoryUsableSystemRamGb = Math.max(
    0,
    (inferenceGpu.systemRamAvailableHostGb || 0) - 2,
  );
  const memorySystemRamReserveDeficitGb = Math.max(
    0,
    2 - (inferenceGpu.systemRamAvailableHostGb || 0),
  );
  // The rule itself lives in gpu-vram.ts, beside the aggregates it is built from and
  // reachable from the test runner: memory-unified-apu.test.ts exercises the non-Apple
  // unified path directly rather than reading these lines back as text, which is what
  // broke twice as the block around them moved.
  const {
    gb: memoryFreeGpuCapacityGb,
    known: memoryFreeGpuCapacityKnown,
    reserveDeficitGb: memoryFreeGpuReserveDeficitGb,
  } = useMemo(
    () =>
      resolveFreeGpuCapacityGb({
        devices: gpuDevices,
        pinnedGpuIds,
        budgetFraction: memoryEffectiveBudgetFraction,
        unifiedMemory: hasUnifiedMemory,
        unifiedPoolReportedAsGpuMemory: isAppleUnifiedMemory,
        usableSystemRamGb: memoryUsableSystemRamGb,
        systemRamReserveDeficitGb: memorySystemRamReserveDeficitGb,
        systemRamAvailableKnown: inferenceGpu.systemRamAvailableKnown,
        loadedGpuIds,
        loadedGpuIndexKind,
      }),
    [
      gpuDevices,
      pinnedGpuIds,
      memoryEffectiveBudgetFraction,
      hasUnifiedMemory,
      isAppleUnifiedMemory,
      memoryUsableSystemRamGb,
      memorySystemRamReserveDeficitGb,
      inferenceGpu.systemRamAvailableKnown,
      loadedGpuIds,
      loadedGpuIndexKind,
    ],
  );
  const {
    gpuCapacityGb: memoryGpuCapacityGb,
    totalCapacityGb: memoryTotalCapacityGb,
    singleMemoryPool,
  } = resolveMemoryCapacityGb({
      gpuBudgetFraction: memoryEffectiveBudgetFraction,
      pinnedDevices:
        pinnedGpuIds && pinnedGpuIds.length > 0
          ? gpuDevices.filter((device) => pinnedGpuIds.includes(device.index))
          : [],
      hostDevices: gpuDevices,
      hostGpuTotalGb: inferenceGpu.memoryTotalGb,
      hostDedicatedGpuTotalGb: inferenceGpu.dedicatedMemoryTotalGb,
      hostSharesSystemRam: inferenceGpu.sharedMemory,
      systemRamTotalGb: inferenceGpu.systemRamTotalGb,
      // The GENERAL signal, not the Apple-only one: a ROCm APU reports unified_memory per device and
      // shares one pool exactly as Apple does, but reading appleSilicon here charged it as
      // discrete VRAM PLUS host RAM, the same bytes twice.
      unifiedMemory: hasUnifiedMemory,
      // "One pool" and "how big is the pool" are different questions: Apple's memory_total_gb IS the
      // machine's unified memory, while a ROCm APU's is a BIOS-carved window onto system RAM, so
      // taking it as the ceiling reported 46.56 GiB on a 96 GiB machine.
      unifiedPoolReportedAsGpuMemory: isAppleUnifiedMemory,
    });

  const rememberChanged = remember !== savedRemember;
  const persistenceOnly = isActiveModel && atBaseline && rememberChanged;
  const primaryActionLabel = persistenceOnly
    ? remember
      ? "Save settings"
      : "Forget settings"
    : isActiveModel
      ? "Reload model"
      : "Load model";

  const [engineReady, setEngineReady] = useState(true);
  const commitDraft = () => {
    // Same-click Load/Reload: a numeric draft the user just typed is flushed only by that input's
    // blur handler, which runs after this click closure captured the stale value, so commit
    // every numeric input imperatively.
    const committedContext = target.isGguf
      ? contextInputRef.current?.commit()
      : undefined;
    const committedMaxSeqLength = target.isGguf
      ? undefined
      : maxSeqLengthInputRef.current?.commit();
    const committedGpuLayers = target.isGguf
      ? gpuLayersInputRef.current?.commit()
      : undefined;
    const committedMoeLayers = target.isGguf
      ? moeLayersInputRef.current?.commit()
      : undefined;

    const pendingPatch: Partial<PerModelConfig> = {};
    if (committedContext != null) {
      pendingPatch.customContextLength = committedContext;
    }
    if (committedMaxSeqLength != null) {
      Object.assign(pendingPatch, contextPinPatch(committedMaxSeqLength, targetIsMlx));
    }
    if (committedGpuLayers != null) {
      pendingPatch.gpuLayers = committedGpuLayers;
    }
    if (committedMoeLayers != null) {
      pendingPatch.nCpuMoe = committedMoeLayers;
    }
    const hasPending =
      committedContext != null ||
      committedMaxSeqLength != null ||
      committedGpuLayers != null ||
      committedMoeLayers != null;

    // The peer's focused input commits on blur during this click, into the shared draft, and
    // the refs above reach only this editor's. So read the draft, not the render closure.
    const liveDraftConfig = readModelConfigDraft(draftKey)?.config;
    const baseConfig = liveDraftConfig
      ? reconcileConfigGpuSelection(liveDraftConfig, resolvedIsDiffusion, gpuDevices)
      : config;
    const peerChanged = !perModelConfigsEqual(baseConfig, config);
    const committedConfig =
      hasPending || peerChanged ? { ...baseConfig, ...pendingPatch } : baseConfig;
    const effectiveConfig = resolvedIsDiffusion
      ? withoutUnsupportedDiffusionSettings(committedConfig, gpuIndexKind)
      : target.isGguf
        ? committedConfig
        : {
            ...committedConfig,
            reasoningBudget: -1,
            reasoningBudgetMessage: "",
          };
    // pinFixedLayerContext above was computed from the render-time config, before the same-click
    // GPU Layers draft was committed, so recompute from effectiveConfig or a later fresh load
    // recreates the OOM.
    const effectivePinFixedLayerContext =
      target.isGguf &&
      effectiveConfig.gpuMemoryMode === "manual" &&
      effectiveConfig.gpuLayers != null &&
      effectiveConfig.gpuLayers >= 0 &&
      effectiveConfig.customContextLength == null &&
      activeLoadedContext != null;
    const effectiveRuntimeConfig = (hasPending || peerChanged)
      ? effectivePinFixedLayerContext
        ? { ...effectiveConfig, customContextLength: activeLoadedContext }
        : effectiveConfig
      : runtimeConfig;
    // Non-GGUF load substitutes the resolved max sequence length; recompute from the committed draft.
    const effectiveMaxSeqLengthValue =
      committedMaxSeqLength == null && !peerChanged
        ? maxSeqLengthValue
        : (normalizeMaxSeqLength(effectiveConfig.maxSeqLength) ??
          clampMaxSeqLength(DEFAULT_MAX_SEQ_LENGTH, nativeMaxSeqLength));
    return { effectiveConfig, effectiveRuntimeConfig, effectiveMaxSeqLengthValue };
  };

  const persistConfig = (next: PerModelConfig) => {
    // Normalizing drops a blank or oversized custom config, saving managed over a good one.
    if (
      remember &&
      next.llamaCppConfig !== undefined &&
      normalizeLlamaCppConfig(next.llamaCppConfig) === undefined
    ) {
      return { saved: false, defaultConfig: false };
    }
    // Judge what storage keeps: savePerModelConfig normalizes first, so the raw object over-reports.
    const normalized = normalizePerModelConfig(next);
    const evicted: { modelId: string; ggufVariant: string | null }[] = [];
    const saved = remember
      ? savePerModelConfig(configId, target.ggufVariant, normalized, evicted)
      : deletePerModelConfig(configId, target.ggufVariant);
    // Mirror to the server so an API load gets these settings, not app defaults. Best-effort, and
    // skipped when the localStorage write failed or the two would permanently disagree. Gated on
    // auto-switch reach, not GGUF-ness: the resolver skips a materialized Ollama link, and a
    // native-path lease is the same.
    // A forget also drops the local records for every other spelling the server reports clearing.
    if (saved && (target.apiLoadable ?? target.isGguf) && !nativePathToken) {
      syncModelOverride(
        configId,
        target.ggufVariant,
        remember ? normalized : null,
        remember
          ? {
              resetReasoningBudget:
                baseline.reasoningBudget !== -1 &&
                normalized.reasoningBudget === -1,
              resetReasoningBudgetMessage:
                baseline.reasoningBudgetMessage !== "" &&
                normalized.reasoningBudgetMessage === "",
            }
          : undefined,
      );
    }
    // Only once the write landed: a blocked or full localStorage leaves the values on screen,
    // and clearing anyway let the next read replace them with the older stored row.
    if (saved) {
      clearModelConfigDraftEdited(draftKey);
    }
    // Saving can push the local map over budget and drop other models, whose server entries would
    // keep applying with nothing able to forget them. Not a Forget: only mirrored fields go.
    for (const dropped of evicted) {
      syncModelOverride(dropped.modelId, dropped.ggufVariant, null, {
        keepLaunchFlags: true,
      });
    }
    return { saved, defaultConfig: isDefaultConfig(normalized) };
  };

  const finishPersist = (defaultConfig: boolean) => {
    const nextRemember = remember && !defaultConfig;
    setSavedRemember(nextRemember);
    setRemember(nextRemember);
    toast.success(
      nextRemember
        ? "Settings saved."
        : remember
          ? "Default settings kept."
          : "Settings forgotten.",
    );
  };

  const handleSave = () => {
    if (sharedVariantUnresolved) {
      return;
    }
    const { effectiveRuntimeConfig } = commitDraft();
    const { saved, defaultConfig } = persistConfig(effectiveRuntimeConfig);
    if (!saved) {
      toast.error("Couldn't save settings for this model.");
      return;
    }
    // The page stays mounted, so show a context pinFixedLayerContext stored (else it reads "Auto").
    // Not on a forget: that stored nothing, and pinning here would change the next load.
    // setConfig, not update: this mirrors what was just saved, so the draft must stay unedited.
    if (
      remember &&
      effectiveRuntimeConfig.customContextLength !== config.customContextLength
    ) {
      setConfig((current) => ({
        ...current,
        customContextLength: effectiveRuntimeConfig.customContextLength,
      }));
    }
    finishPersist(defaultConfig);
  };

  const handleRun = () => {
    if (sharedVariantUnresolved) {
      return;
    }
    if (budgetSettling) {
      return;
    }
    const { effectiveConfig, effectiveRuntimeConfig, effectiveMaxSeqLengthValue } =
      commitDraft();
    // Recheck the committed draft so Save/Forget reloads when needed.
    const effectivePersistenceOnly =
      isActiveModel &&
      perModelConfigsEqual(effectiveConfig, baseline, {
        followGlobal: true,
      }) &&
      rememberChanged;
    const { saved, defaultConfig } = persistConfig(effectiveRuntimeConfig);
    if (effectivePersistenceOnly) {
      if (!saved) {
        toast.error("Couldn't save settings for this model.");
        return;
      }
      finishPersist(defaultConfig);
      return;
    }
    if (!saved) {
      toast.error("Couldn't save these settings, loading with them anyway.");
    }
    const effectiveLoadConfig =
      target.isGguf || pinsContextLength
        ? effectiveRuntimeConfig
        : { ...effectiveRuntimeConfig, maxSeqLength: effectiveMaxSeqLengthValue };
    // Same reason as the numeric commits above: the budget row flushes on unmount,
    // which for this click lands after onRun has staged the load, so that load (the
    // very one the control promises) would use the old fraction. A failed save must
    // not swallow the load, hence finally; nothing staged stays synchronous.
    // Closed before the settle, not after: the control has to stop taking edits at
    // the moment this click owns the fraction, or a drag landing in between is the
    // very race the lock exists to remove.
    setVramBudgetLocked(true);
    const stagedBudget = settleVramBudgetSave();
    if (stagedBudget) {
      // The click is answered by a network round trip now, so the button stays live for as long as
      // that takes and a second click would run onRun twice.
      setBudgetSettling(true);
      // Caught, not voided: finally alone re-rejects into an unhandled rejection, and the load would
      // proceed on the old fraction with nothing said.
      void stagedBudget
        .catch((error: unknown) => {
            // Dropped rather than left for the next flush: the picker teardown that onRun triggers flushes
            // it, and that PUT would race the load request this click is about to send. Only the retry
            // goes, never a newer edit staged over it.
          dropVramBudgetRetry();
          toast.error(
            error instanceof Error ? error.message : "Failed to save VRAM budget",
          );
        })
        .finally(() => {
          setVramBudgetLocked(false);
          setBudgetSettling(false);
          onRun(effectiveLoadConfig, classifiedIsDiffusion);
        });
      return;
    }
    // Nothing to wait for, so the control never actually closes for the user.
    setVramBudgetLocked(false);
    onRun(effectiveLoadConfig, classifiedIsDiffusion);
  };

  return (
    <div
      className="hint-on-hover flex flex-col"
      onChange={(event) => {
        if (isRunConfigEditorChange(event)) {
          handleSharedConfigEdit();
        }
      }}
    >
      {variant === "page" && showHeader && (
        // -ml-1.5 cancels the icon's inset in its 28px circle, so the chevron starts on
        // the same left edge as the rows below.
        <div className="flex items-center gap-2.5 pb-5">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="nav-icon-btn -ml-1.5 shrink-0 text-nav-icon-idle hover:bg-panel-surface-hover hover:text-black dark:hover:text-white"
              aria-label="Back to model list"
            >
              <ChevronLeftIcon
                className="size-4"
                strokeWidth={1.75}
              />
            </button>
          )}
          <div className="min-w-0 flex-1">
            <div className="text-ui-10 font-semibold uppercase leading-none tracking-wider text-muted-foreground">
              Run settings
            </div>
            <div className="mt-1.5 truncate text-ui-14 font-semibold leading-tight text-foreground">
              {target.displayName}
            </div>
          </div>
        </div>
      )}

      <SharedRunConfigReview
        target={target}
        imported={importedConfig}
        draftConfig={configState}
        currentConfig={config}
        remember={remember}
        hasSavedSettings={savedRemember}
      />
      <fieldset
        disabled={customActive}
        inert={customActive ? true : undefined}
        className={`min-w-0 space-y-5 ${customActive ? "opacity-50" : ""}`}
      >
        {!target.isGguf && !targetIsMlx && !targetIsNpu && !classifiedIsDiffusion && !target.meta.isLora && !target.meta.audioType && (
          <InferenceEnginePicker parallelism={config.engineParallelism ?? "tensor"} onParallelismChange={engineParallelism => update({ engineParallelism })} precision={config.enginePrecision ?? "auto"} onPrecisionChange={enginePrecision => update({ enginePrecision })} value={config.engine ?? "auto"} onChange={engine => update({ engine })} onReadyChange={setEngineReady} onUse={handleRun} gpuIds={config.selectedGpuIds} onGpuChange={ids => update({ selectedGpuIds: ids, selectedGpuIndexKind: "physical" })} />
        )}
        {audioRuntimeGguf ? (
          <p className="text-ui-12 leading-snug text-muted-foreground">
            This model runs on the audio runtime, so llama.cpp settings do not
            apply. Its generation options are under Advanced on the Audio page
            once it is loaded.
          </p>
        ) : null}
        {memoryEstimateRequest != null && !audioRuntimeGguf && (
          <MemoryEstimateRow
            estimate={memoryEstimate.estimate}
            loading={memoryEstimate.loading}
            stale={memoryEstimate.stale}
            gpuCapacityGb={memoryGpuCapacityGb}
            totalCapacityGb={memoryTotalCapacityGb}
            systemRamCapacityGb={inferenceGpu.systemRamTotalGb}
            freeGpuCapacityGb={memoryFreeGpuCapacityGb}
            freeGpuCapacityKnown={memoryFreeGpuCapacityKnown}
            freeGpuReserveDeficitGb={memoryFreeGpuReserveDeficitGb}
            usableSystemRamGb={memoryUsableSystemRamGb}
            usableSystemRamKnown={inferenceGpu.systemRamAvailableKnown}
            systemRamReserveDeficitGb={memorySystemRamReserveDeficitGb}
            isUnifiedMemory={isAppleUnifiedMemory}
            singleMemoryPool={singleMemoryPool}
            reclaimableTotalBytes={reclaimableCredit.totalBytes}
            reclaimableGpuBytes={reclaimableCredit.gpuBytes}
            expanded={memoryBreakdownOpen}
            onExpandedChange={setMemoryBreakdownOpen}
          />
        )}
        {target.isGguf && !audioRuntimeGguf && (
          <>
            <div className="space-y-2">
              <div className={ROW_CLASS}>
                <div className="flex min-w-0 items-center gap-1.5">
                  <span className={LABEL_CLASS}>Context Length</span>
                  <InfoHint>
                    Drag all the way left for Auto, which picks a context that
                    fits while keeping GPU speed. Custom values request an exact
                    context; higher ones use more memory.
                    {contextIsAuto && activeLoadedContext != null
                      ? ` Auto currently selected ${activeLoadedContext.toLocaleString()} tokens.`
                      : ""}
                    {nativeContextLength != null
                      ? ` This model's native context is ${nativeContextLength.toLocaleString()} tokens.`
                      : ""}
                  </InfoHint>
                </div>
                <NumericValueInput
                  ref={contextInputRef}
                  value={contextInputValue}
                  min={minContext}
                  max={maxContext}
                  step={1}
                  onChange={setContextLength}
                  displayValue={contextIsAuto ? "Auto" : undefined}
                  ariaLabel="Context Length"
                  className={NUMBER_INPUT_CLASS}
                  fixedWidth={true}
                  size={8}
                />
              </div>
              {/* Grouped so the warning sits 4px under the slider, as advice does elsewhere. */}
              <div className="space-y-1">
                {nativeContextLength != null ? (
                  <div className="space-y-1">
                    <Slider
                      min={0}
                      max={maxContext}
                      step={128}
                      value={[contextSliderValue]}
                      onValueChange={([v]) => setContextSliderValue(v)}
                      className="panel-slider"
                      aria-label="Context Length"
                      // Position 0 is Auto, not a zero-token context, so aria-valuenow alone reads as a length no
                      // model has. The number is only spoken once one exists.
                      thumbValueText={(v) =>
                        v !== 0
                          ? `${v.toLocaleString()} tokens`
                          : activeLoadedContext != null
                            ? `Auto, currently ${contextInputValue.toLocaleString()} tokens`
                            : "Auto"
                      }
                    />
                    <div className="flex justify-between text-ui-10 text-muted-foreground">
                      <span>Auto</span>
                      <span>{maxContext.toLocaleString()}</span>
                    </div>
                  </div>
                ) : null}
                {!contextIsAuto &&
                  isActiveModel &&
                  loadedMaxContextLength != null &&
                  contextValue > loadedMaxContextLength && (
                    <p className="text-ui-11 text-amber-500">
                      {isAppleUnifiedMemory ? (
                        <>
                          Above Studio&apos;s free-memory estimate (
                          {loadedMaxContextLength.toLocaleString()} tokens). It
                          may still load, but macOS may have to compress or swap
                          other apps and generation may slow down.
                        </>
                      ) : (
                        <>
                          Exceeds estimated VRAM capacity (
                          {loadedMaxContextLength.toLocaleString()} tokens). The
                          model may use system RAM.
                        </>
                      )}
                    </p>
                  )}
              </div>
            </div>

            {/* Above the block it reveals, so expanding never moves the switch. */}
            <AdvancedSettingsToggle
              checked={showAdvanced}
              onCheckedChange={toggleAdvanced}
            />

            {showAdvanced && (
              <GgufAdvancedSettings
                config={config}
                update={update}
                showDraftTokens={showDraftTokens}
                showSpecDraftCacheDtype={showSpecDraftCacheDtype}
                speculativeFallback={speculativeFallback}
                onEditTemplate={() => setTemplateOpen(true)}
                layerCount={stagedDims?.layerCount ?? null}
                moeLayerCount={stagedDims?.moeLayerCount ?? null}
                isDiffusion={resolvedIsDiffusion}
                hideVision={customActive}
                gpuDevices={gpuDevices}
                gpuLayersInputRef={gpuLayersInputRef}
                moeLayersInputRef={moeLayersInputRef}
                draftKey={draftKey}
                onExtraArgsLoadableChange={setExtraArgsLoadable}
              />
            )}
          </>
        )}
        {!target.isGguf && (
          <>
            <MaxSeqLengthSetting
              value={maxSeqLengthValue}
              max={maxSeqLengthMax}
              inputMax={targetIsNpu ? maxSeqLengthMax : MAX_SEQ_LENGTH_MAX}
              inputRef={maxSeqLengthInputRef}
              isMlx={pinsContextLength}
              pinned={savedContextPin(config) != null}
              fittedToMemory={
                savedContextPin(config) == null && mlxFittedWindow != null
              }
              windowUnknown={
                savedContextPin(config) == null &&
                mlxServedWindow == null &&
                npuServedWindow == null
              }
              hint={
                targetIsNpu
                  ? `Tokens of context FastFlowLM loads the model with. Unset, it loads ${NPU_DEFAULT_CONTEXT_LENGTH.toLocaleString()}, or the model's limit if that is lower.`
                  : undefined
              }
              onChange={(value) =>
                update(contextPinPatch(value, pinsContextLength))
              }
            />
            {!targetIsNpu && (
              <>
                <AdvancedSettingsToggle
                  checked={showAdvanced}
                  onCheckedChange={toggleAdvanced}
                />
                {showAdvanced && (
                  <MlxAdvancedSettings
                    config={config}
                    update={update}
                    outcome={mlxKvQuantOutcome}
                    servedByMlx={servedByMlx}
                    onEditTemplate={() => setTemplateOpen(true)}
                    templateOutcome={chatTemplateOutcome}
                  />
                )}
              </>
            )}
          </>
        )}
      </fieldset>

      {target.isGguf &&
        !resolvedIsDiffusion &&
        !audioRuntimeGguf &&
        (showAdvanced || customActive) && (
          <div className="mt-5 space-y-5">
            {customActive && <VisionRow config={config} update={update} />}
            <CustomLlamaConfigEditor
              value={config.llamaCppConfig}
              onChange={(llamaCppConfig) => update({ llamaCppConfig })}
              sourceKey={draftKey}
              onLoadableChange={setCustomConfigLoadable}
            />
          </div>
        )}

      {/* Stacked in both variants: a row that wraps on demand reflows when the same click that
          commits a draft mounts Save settings, moving Load out from under the cursor. */}
      <div className="mt-5 flex flex-col gap-2 border-t border-border pt-5">
        <div className="flex min-w-0 items-center gap-2">
          <Checkbox
            id={rememberId}
            checked={remember}
            onCheckedChange={(checked) => {
              // Not in setRemember, which the save path calls again to settle the box. An
              // unticked Remember is a pending Forget the next read would otherwise re-tick.
              markModelConfigDraftEdited(draftKey);
              setRemember(checked === true);
            }}
          />
          <label
            htmlFor={rememberId}
            className="cursor-pointer select-none truncate text-ui-13 text-foreground"
          >
            Remember for this model
          </label>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {/* Primary action first, like the Preset row's Save/Delete. */}
          <Button
            type="button"
            size="sm"
            className={FOOTER_BUTTON_CLASS}
            disabled={
              sharedVariantUnresolved ||
              ((config.engine ?? "auto") !== "auto" && !engineReady) ||
              stagedMetadataPending ||
              budgetSettling ||
              (customActive && !customConfigLoadable) ||
              (!customActive &&
                ((!extraArgsLoadable && !sharedExtraArgsCleared) ||
                  sharedExtraArgsRefused)) ||
              extraArgsHydrating ||
              (isActiveModel &&
                atBaseline &&
                !rememberChanged &&
                !budgetReloadRequired)
            }
            onClick={handleRun}
          >
            {primaryActionLabel}
          </Button>
          {/* Hidden with nothing to save or forget, else never-remembered models show a dead Forget. */}
          {!persistenceOnly && (remember || savedRemember) && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              className={FOOTER_BUTTON_CLASS}
              // Same gates as Load: an unclassified model or an in-flight budget PUT would persist
              // settings the load path strips or has already captured. Forget stores nothing, so
              // broken saved arguments must not lock it.
              disabled={
                sharedVariantUnresolved ||
                stagedMetadataPending ||
                budgetSettling ||
                (remember &&
                  ((customActive && !customConfigLoadable) ||
                    (!extraArgsLoadable && !sharedExtraArgsCleared) ||
                    sharedExtraArgsRefused ||
                    extraArgsHydrating))
              }
              onClick={handleSave}
            >
              {remember ? "Save settings" : "Forget settings"}
            </Button>
          )}
          <Button
            type="button"
            variant="outline"
            size="sm"
            className={`${FOOTER_BUTTON_CLASS} text-muted-foreground`}
            disabled={atDefault}
            onClick={() => {
              handleSharedConfigEdit();
              // Reset writes through setConfig, not update, so it marks the draft itself.
              markModelConfigDraftEdited(draftKey);
              // And drops the raw edit: token equality alone would make the discarded text
              // current again the moment a later value formatted to the same tokens.
              clearExtraArgsEditForDraft(draftKey);
              setConfig({
                // null, not the default's absent: absent omits the field, and the load then INHERITS the
                // running process's arguments, so a reload after Reset kept the flags the box says are gone.
                ...DEFAULT_PER_MODEL_CONFIG,
                llamaExtraArgs: null,
                llamaCppConfig: MANAGED_LLAMA_CPP_CONFIG,
              });
            }}
          >
            Reset
          </Button>
          {target.isGguf && (
            <SharedRunConfigControls
              className={FOOTER_BUTTON_CLASS}
              target={target}
              config={config}
              ready={!extraArgsHydrating}
              canImport={variant !== "sidebar"}
              isDiffusion={resolvedIsDiffusion}
              disabled={
                sharedExtraArgsRefused ||
                (!extraArgsLoadable && !sharedExtraArgsCleared)
              }
              onImport={handleSharedConfigImport}
            />
          )}
        </div>
      </div>

      <ChatTemplateEditorDialog
        open={templateOpen}
        onOpenChange={setTemplateOpen}
        value={config.chatTemplateOverride}
        defaultTemplate={resolvedDefaultTemplate}
        defaultLoading={resolvedDefaultLoading}
        readOnly={!target.isGguf && !servedByMlx}
        onSave={(override) => update({ chatTemplateOverride: override })}
      />
    </div>
  );
}
