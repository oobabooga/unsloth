// SPDX-License-Identifier: AGPL-3.0-only
// Copyright 2026-present the Unsloth AI Inc. team. All rights reserved. See /studio/LICENSE.AGPL-3.0

// eslint-disable-next-line no-restricted-imports -- The picker barrel imports chat; this payload helper is import-free.
import { llamaCppConfigPayload } from "@/features/model-picker/model-config/llama-cpp-config";
import {
  CACHE_MISS_DOWNLOAD_DESCRIPTION,
  EMPTY_CACHE_MISS_WATCH,
  watchCacheMissDownload,
} from "../lib/cache-miss-download";
import { mlxRuntimeStateFrom } from "../lib/mlx-runtime-state";
import { shouldRestorePreviousModel } from "../lib/restore-previous-model";
import {
  type ServerTuningValues,
  clearedServerTuningState,
  committedServerTuningState,
  serverTuningLoadPayload,
} from "../lib/server-tuning-fields";
import { createElement, useCallback, useEffect, useRef, useState } from "react";
import { toast } from "@/lib/toast";
import {
  isBackendDownForDesktopUpdate,
  isSilencedDesktopUpdateFailure,
} from "@/lib/desktop-update-activity";
import { subscribeModelLifecycle } from "@/lib/model-lifecycle-events";
import {
  type TransferSample,
  appendSample,
  computeTransferStats,
} from "@/lib/transfer-stats";
import { confirmRemoteCodeIfNeeded } from "@/features/security";
import { defaultInferenceParams } from "../presets/preset-policy";
import {
  type ReloadHint,
  serverWideReloadRequired,
} from "../lib/server-wide-reload";
import {
  type OffloadCounts,
  offloadCountsFrom,
  offloadWarning,
} from "../lib/partial-offload";
import { isSettingsRouteAbsent } from "@/features/settings/api/settings-route-absent";
import {
  failureLogPath,
  loadFailureLogFamily,
  viewLogsAction,
} from "@/features/settings/lib/view-logs-action";
import { loadModelMemorySettings } from "@/features/settings/api/model-memory";
import { loadVramBudgetSettings } from "@/features/settings/api/vram-budget";
import { loadOpenAIAutoSwitchSettings } from "@/features/settings";
import {
  confirmTransformersUpgradeIfNeeded,
  useTransformersUpgradeDialogStore,
} from "@/features/transformers-upgrade";
import { consumeNativePathToken } from "@/features/native-intents/api";
// eslint-disable-next-line no-restricted-imports -- Avoid the hub barrel's React and download-manager exports.
import {
  isOllamaModelId,
  modelDisplayName,
} from "@/features/hub/lib/model-identity";
// eslint-disable-next-line no-restricted-imports -- Avoid the hub barrel's React and download-manager exports.
import { subscribeResidentStatusRefresh } from "@/features/hub/lib/resident-status-refresh";
import {
  beginServerModelWait,
  serverModelWaitOutstanding,
  statusPollSignal,
} from "../lib/server-model-wait";
// eslint-disable-next-line no-restricted-imports -- The hub barrel imports chat; this lifecycle leaf does not.
import { dismissStartToastsForModelSelection } from "@/features/hub/download-manager";
import { prepareHfTokenForUse } from "@/features/hf-auth";
import { ModelLoadDescription } from "../components/model-load-status";
import {
  getDownloadProgress,
  getGgufDownloadProgress,
  getInferenceStatus,
  getLoadProgress,
  fetchGgufStagedMetadata,
  listLoras,
  listModels,
  loadModel,
  unloadModel,
  validateModel,
} from "../api/chat-api";
import { formatEta, formatRate } from "../utils/format-transfer";
import {
  ownsModelLoadRun,
  releaseOwnedModelLoadRun,
} from "../utils/model-load-run";
import { confirmStopRunningChatsIfNeeded } from "../utils/confirm-stop-running-chats";
import {
  requestLocalPromptQueueStop,
  notifyLocalPromptQueueLoadFailed,
} from "../utils/prompt-queue-boundary";
import { cancelPreStreamRunReservations } from "../utils/pre-stream-run-reservation";
import {
  chatModelLifecycleGate,
  type ModelLifecycleLease,
} from "../utils/model-lifecycle-gate";
import {
  GPU_LAYERS_AUTO,
  isLocalModelPath,
  loadedLlamaCppConfigFields,
  managedGpuMemoryFields,
  managedKvCacheFields,
  managedSpeculativeSettings,
  noteLoadedModelReasoningMode,
  persistGpuMemoryModeOnLoad,
  pinHoldsLiveEffort,
  readPersistedGpuMemoryMode,
  readPersistedSpeculativeType,
  reconcilePersistedGpuIds,
  resolvePreserveThinkingOnLoad,
  resolveToolsEnabledOnLoad,
  saveSpeculativeType,
  takeEffortDisplacedByPin,
  useChatRuntimeStore,
  type LoadingModelPick,
  type ReasoningEffort,
} from "../stores/chat-runtime-store";
import { clampReasoningEffortToLevels } from "../provider-capabilities";
import {
  applyActiveModelStatusToStore,
  clampLocalReasoningEffort,
  normalizeSpeculativeType,
  resolveInferenceCheckpointId,
  tryAdoptServerActiveModel,
} from "../lib/apply-inference-status-to-store";
import {
  isIdleUnloadedStatus,
  isSpeechOnlyStatus,
} from "../lib/speech-only-status";
import {
  residentRuntimeMatchesConfig,
  residentSpeculativeNeedsRepair,
} from "../lib/resident-config-match";
import { residentModelMatchesPick } from "../lib/resident-model-match";
import {
  loadedContextForParams,
  mergeBackendRecommendedInference,
  resolveFitMaxSeqLength,
  isReplayedLoadContext,
  unpinnedDefaultRequest,
  unpinnedLoadContext,
  resolveLoadMaxSeqLength,
  resolveExplicitCtxPin,
  loadRequestContextPin,
  replayMaxTokensCap,
} from "../presets/preset-policy";
import { recordLastLocalModelLoad } from "../utils/last-local-model-load";
import { loadFallbackNotice } from "../utils/mmproj-fallback";
import { resolveQwenThinkingParams } from "../utils/qwen-sampling-table";
import { refreshContextUsage } from "../utils/refresh-context-usage";
import { defaultEngineGpuIds, ensureGpuDeviceCache } from "@/hooks/use-gpu-info";
import {
  type CpuFallbackReason,
  type MmprojFallbackReason,
  type InferenceStatusResponse,
  isMultimodalResponse,
} from "../types/api";
import { isExternalModelId } from "../external-providers";
import {
  DEFAULT_MAX_SEQ_LENGTH,
  DEFAULT_PER_MODEL_CONFIG,
  applyPerModelConfigToRuntime,
  currentRuntimePerModelConfig,
  isServedByMlx,
  normalizeMaxSeqLength,
  residentIsServedByMlx,
  resolveInitialConfig,
  savedContextPin,
  type PerModelConfig,
  loadedContextFields,
} from "@/features/model-picker";
import {
  invalidateLlamaFlagCatalog,
  loadManagedLlamaFlags,
} from "@/features/model-picker/api/llama-flags";
import { usePlatformStore } from "@/config/env";
import type {
  ChatLoraSummary,
  ChatModelRow,
} from "../types/runtime";

type LoadingModelState = {
  id: string;
  displayName: string;
  isDownloaded?: boolean;
  isCachedLora?: boolean;
  ggufVariant?: string | null;
  nativePathToken?: string | null;
};

/** One attempt at claiming the single shared load slot. Its token lets late async
 *  callbacks prove the slot is still theirs before they touch shared loading state. */
type ActiveModelLoadRun = {
  attemptId: number;
  intentId: number;
  abortController: AbortController;
  /** Stable ID sent as `load_request_id` on this run's /load and matched by
   *  `cancel_load_request_id` on /unload, so a cancel binds to this attempt and to
   *  no other surface's load. */
  requestId: string;
  /** The exact model_path this run POSTed to /load. /unload must name the same
   *  target or the scoped cancel cannot match the registered attempt. */
  loadAttemptPath: string | null;
  cancelPromise: Promise<boolean> | null;
  rollbackCheckpoint: string | null;
  /** The outgoing model's GGUF variant, captured with the checkpoint above. clearCheckpoint()
   *  drops activeGgufVariant from the store, so a replacement that has to reload the former
   *  resident must carry the variant itself or it would restore the wrong artifact. */
  rollbackVariant: string | null;
  rollbackConfig?: PerModelConfig;
  /** The outgoing model's load identity must survive clearCheckpoint() for compensation. */
  rollbackLoadId: string | null;
  rollbackNativePathToken: string | null;
  rollbackNativePathExpiresAtMs: number | null;
  /** Launch settings from the outgoing resident, retained through checkpoint clearing. */
  rollbackLoadedState: ReturnType<typeof useChatRuntimeStore.getState>;
  /** Set once the preliminary unload has removed the model that was resident before
   *  this load. A cancellation before this run POSTs its own /load leaves the backend
   *  with nothing, so the store's checkpoint must be reconciled, not preserved. */
  residentModelUnloaded: boolean;
  forceCancelActive: boolean;
  /** Resolves once the coroutine that owns this run has unwound. Cancellation
   *  holds the slot until then, so an aborted load cannot apply or restore
   *  configuration while the replacement that superseded it owns the slot. */
  settledPromise: Promise<void>;
  markSettled: () => void;
};

/** The selection the user last asked for, so an await can tell it was superseded. */
let modelSelectionIntentEpoch = 0;
let pendingExternalReplacement:
  | { intentId: number; config?: PerModelConfig }
  | null = null;
export type SelectedModelInput = {
  id: string;
  /** Sent as model_path in place of the id, which stays the identity the UI shows. */
  loadId?: string | null;
  isLora?: boolean;
  ggufVariant?: string;
  /** Where the pick came from ("hub", "local", "external"). Decides whether an uncached repo
   *  should download via the Hub manager. */
  source?: string;
  /** Uncached non-GGUF HF repo staged for a snapshot download (variant null). */
  isHubRepo?: boolean;
  loadingDescription?: string;
  isDownloaded?: boolean;
  expectedBytes?: number;
  downloadPresentation?: {
    label: string;
    filename: string;
    expectedBytes: number;
  };
  forceReload?: boolean;
  nativePathToken?: string;
  nativePathExpiresAtMs?: number | null;
  /** Direct local .gguf file (no HF variant / native token), still a GGUF source, so the staging
   *  flow treats it as one. */
  isGguf?: boolean;
  /** Known model vision capability. Undefined means unknown, not text-only. */
  isVision?: boolean;
  /** Staged metadata confirmed the separate DiffusionGemma runner. */
  isDiffusion?: boolean;
  throwOnError?: boolean;
  /** Keep the current speculative-decoding choice across the model switch instead of resetting it
   *  to the standing preference. */
  keepSpeculative?: boolean;
  config?: PerModelConfig;
  previousConfig?: PerModelConfig;
};

// Approved fingerprints by checkpoint, so a rollback after a failed switch can resend the pinned
// approval the worker requires.
/** An absent route is not a failed read: only the second one withholds an answer. */
async function readReloadHint(
  read: () => Promise<{ reloadRequired: boolean } | null>,
): Promise<ReloadHint> {
  try {
    return (await read()) ?? "unsupported";
  } catch (error) {
    return isSettingsRouteAbsent(error) ? "unsupported" : "unknown";
  }
}

/** The two settings reads `serverWideReloadRequired` judges, fetched together. */
async function readServerWideReloadHints(): Promise<boolean> {
  const [modelMemory, vramBudget] = await Promise.all([
    // Forced, like the budget below: a read that started before a save answers about the policy it
    // replaced, and a false from that would suppress the reload the save was made for.
    readReloadHint(() => loadModelMemorySettings({ force: true })),
    // Rethrow, or a failed read is indistinguishable from an absent route: this reader answers null for both.
    readReloadHint(() =>
      loadVramBudgetSettings({ force: true, rethrow: true }),
    ),
  ]);
  return serverWideReloadRequired({ modelMemory, vramBudget });
}

/** Placement is an ordered list: position decides which card the model is given
 *  first, so the same set in a different order is a different placement. */
function sameGpuSelection(
  left: readonly number[] | null | undefined,
  right: readonly number[] | null | undefined,
): boolean {
  const a = left ?? [];
  const b = right ?? [];
  return a.length === b.length && a.every((id, index) => id === b[index]);
}

/** Put the rollback snapshot back before a checkpoint is dropped. clearCheckpoint remembers
 *  whatever the store holds under the checkpoint's id, and a run cancelled after its preliminary
 *  unload has already applied its target's config: clearing first would persist the cancelled
 *  target's settings as the former resident's durable entry. */
function restoreRollbackConfigForClear(run: ActiveModelLoadRun): void {
  if (!run.rollbackConfig) return;
  applyPerModelConfigToRuntime(run.rollbackConfig, {
    isDiffusion: useChatRuntimeStore.getState().loadedIsDiffusion,
  });
}

const approvedRemoteCodeFingerprints = new Map<string, string>();
type PendingReplacementRollback = {
  checkpoint: string | null;
  config?: PerModelConfig;
  /** True when the cancelled run had already removed the resident model with a real /unload
   *  and stopped before POSTing its own /load: the cancellation reconciliation clears the store
   *  checkpoint for exactly that case, so the replacement has to carry the unloaded state or it
   *  would skip its compensating reload and leave nothing resident. */
  residentUnloaded?: boolean;
  /** The outgoing model's GGUF variant at the moment of cancellation, for the same reason as
   *  the unloaded flag: clearCheckpoint() has already dropped it from the store. */
  variant?: string | null;
  /** Access identity needed to reload the outgoing resident after clearCheckpoint drops it. */
  loadId?: string | null;
  nativePathToken?: string | null;
  nativePathExpiresAtMs?: number | null;
  loadedState?: ReturnType<typeof useChatRuntimeStore.getState>;
};

// Cancellation can finish after a newer selection intent has already started, so the
// rollback target the replacement inherits is retained until the winner reserves its run.
let pendingReplacementRollback: PendingReplacementRollback | null = null;

/** One bounded lease-wait step: a pick waiting for a preflight holder re-checks this often. */
const PREFLIGHT_LEASE_RETRY_MS = 250;
function rememberApprovedRemoteCode(
  checkpoint: string,
  fingerprint: string | null,
): void {
  if (fingerprint) approvedRemoteCodeFingerprints.set(checkpoint, fingerprint);
}

// Class carries the progress-bar spacing; layout is shared CSS now.
const MODEL_LOAD_TOAST_CLASSNAMES = {
  toast: "chat-model-load-toast",
  content: "gap-0.5 flex-1 min-w-0",
  title: "leading-5",
  description: "mt-0 w-full",
  cancelButton:
    "!h-auto !rounded-none !border-0 !bg-transparent !px-1 !text-ui-11 !font-normal !text-muted-foreground hover:!bg-transparent hover:!text-destructive focus-visible:!text-destructive",
} as const;

const LORA_SUFFIX_RE = /_(\d{9,})$/;

const CLI_LOAD_POLL_IDLE_MS = 60_000;
const CLI_LOAD_POLL_MAX_MS = 600_000;

async function waitForServerModel(signal?: AbortSignal): Promise<void> {
  const started = Date.now();
  let sawLoad = false;

  while (
    !signal?.aborted &&
    !useChatRuntimeStore.getState().params.checkpoint &&
    !useChatRuntimeStore.getState().modelLoading
  ) {
    let status: InferenceStatusResponse | null = null;
    // Capped, or a half-open read parks the loop past both caps below and past the
    // unmount that aborted it, with the settlement gate still up behind it.
    const poll = statusPollSignal(signal);
    try {
      status = await getInferenceStatus(poll.signal);
    } catch {
      // A later poll can recover from a transient status failure.
    } finally {
      poll.dispose();
    }
    if (
      signal?.aborted ||
      useChatRuntimeStore.getState().params.checkpoint ||
      useChatRuntimeStore.getState().modelLoading
    ) {
      return;
    }

    if (status) {
      const loading = (status.loading?.length ?? 0) > 0;
      sawLoad ||= loading;
      if (!loading && status.active_model) {
        await tryAdoptServerActiveModel({ status });
        return;
      }
      if (!loading && sawLoad) return;
    }
    const elapsed = Date.now() - started;
    if (!sawLoad && elapsed >= CLI_LOAD_POLL_IDLE_MS) return;
    if (elapsed >= CLI_LOAD_POLL_MAX_MS) return;
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
}

function parseTrailingEpoch(input: string): number | undefined {
  const match = input.match(LORA_SUFFIX_RE);
  if (!match) {
    return undefined;
  }
  const parsed = Number.parseInt(match[1], 10);
  return Number.isFinite(parsed) ? parsed : undefined;
}

function stripTrailingEpoch(input: string): string {
  const cleaned = input.replace(LORA_SUFFIX_RE, "").replace(/[_-]+$/, "").trim();
  return cleaned || input;
}

function shortModelLabel(idOrName: string): string {
  const slash = idOrName.lastIndexOf("/");
  const label = slash >= 0 ? idOrName.slice(slash + 1) : idOrName;
  return label || idOrName;
}

function describeModel(model: {
  is_lora?: boolean;
  is_vision?: boolean;
  is_gguf?: boolean;
  is_mlx?: boolean;
  is_audio?: boolean;
  has_audio_input?: boolean;
  has_video_input?: boolean;
}): string | undefined {
  const tags: string[] = [];
  if (model.is_gguf) tags.push("GGUF");
  if (model.is_mlx) tags.push("MLX");
  if (model.is_lora) tags.push("LoRA");
  if (model.is_vision) tags.push("Vision");
  if (model.is_audio) tags.push("Audio");
  if (model.has_audio_input) tags.push("Audio Input");
  if (
    !model.is_lora &&
    !model.is_vision &&
    !model.is_gguf &&
    !model.is_mlx &&
    !model.is_audio &&
    !model.has_audio_input
  )
    tags.push("Base");
  return tags.join(" · ");
}

function toChatModelRow(model: {
  id: string;
  name?: string | null;
  is_lora?: boolean;
  is_vision?: boolean;
  is_gguf?: boolean;
  is_mlx?: boolean;
  is_audio?: boolean;
  audio_type?: string | null;
  has_audio_input?: boolean;
  has_video_input?: boolean;
}): ChatModelRow {
  return {
    id: model.id,
    name: model.name || model.id,
    description: describeModel(model),
    isLora: Boolean(model.is_lora),
    isVision: Boolean(model.is_vision),
    isGguf: Boolean(model.is_gguf),
    isMlx: Boolean(model.is_mlx),
    isAudio: Boolean(model.is_audio),
    audioType: model.audio_type ?? null,
    hasAudioInput: Boolean(model.has_audio_input),
    hasVideoInput: Boolean(model.has_video_input),
  };
}

// Merge capability flags from a load/status response into the matching models[] entry:
// /api/models/list omits audio capability for default and active-GGUF entries, so the attach
// gates would stay false. Mirrors the compare composer's sync.
export function syncModelCapabilities(
  modelId: string,
  resp: {
    display_name?: string | null;
    is_vision?: boolean;
    is_lora?: boolean;
    is_gguf?: boolean;
    is_mlx?: boolean;
    is_audio?: boolean;
    audio_type?: string | null;
    has_audio_input?: boolean;
    has_video_input?: boolean;
  },
): void {
  const store = useChatRuntimeStore.getState();
  const models = store.models;
  const synced = {
    isVision: Boolean(resp.is_vision),
    isGguf: Boolean(resp.is_gguf),
    // A locally scanned model is in no /api/models/list row, so this is the only place its summary
    // learns it is served by MLX.
    isMlx: Boolean(resp.is_mlx),
    isAudio: Boolean(resp.is_audio),
    audioType: resp.audio_type ?? null,
    hasAudioInput: Boolean(resp.has_audio_input),
    // /api/models/list omits this for the active GGUF row, so without it the video adapter reads
    // false after every load and status hydration.
    hasVideoInput: Boolean(resp.has_video_input),
  };
  const idx = models.findIndex((m) => m.id === modelId);
  if (idx === -1) {
    store.setModels([
      ...models,
      {
        id: modelId,
        // Label like the catalog entry that replaces this on the next /api/models/list; the fallback
        // keeps a cached GGUF's snapshot path out of the bar.
        name: modelDisplayName(resp.display_name || modelId),
        isLora: Boolean(resp.is_lora),
        ...synced,
      },
    ]);
  } else {
    const next = [...models];
    next[idx] = { ...next[idx], ...synced };
    store.setModels(next);
  }
}

function toLoraSummary(lora: {
  display_name: string;
  adapter_path: string;
  base_model?: string | null;
  source?: "training" | "exported" | null;
  export_type?: "lora" | "merged" | "gguf" | null;
  size_bytes?: number | null;
  audio_type?: string | null;
}): ChatLoraSummary {
  const idTail = lora.adapter_path.split("/").filter(Boolean).at(-1) ?? "";
  const updatedAt =
    parseTrailingEpoch(lora.display_name) ?? parseTrailingEpoch(idTail);

  return {
    id: lora.adapter_path,
    name: stripTrailingEpoch(lora.display_name),
    baseModel: lora.base_model || "Unknown base model",
    updatedAt,
    source: lora.source ?? undefined,
    exportType: lora.export_type ?? undefined,
    sizeBytes: lora.size_bytes ?? null,
    audioType: lora.audio_type ?? null,
  };
}

function getTrustRemoteCodeRequiredMessage(modelName: string): string {
  return `${modelName} was not loaded because its custom code was not approved. Load it again to review the code and approve it.`;
}

function getTransformersUpgradeRequiredMessage(modelName: string): string {
  return `${modelName} was not loaded because it needs a newer transformers release that was not installed. Load it again to install it.`;
}

/**
 * Reconcile the chat runtime store against `/api/inference/status`: refresh the models/loras
 * catalogs and either re-pin the active checkpoint or clear the loaded-model flags when nothing is
 * loaded. Module-level so it can run outside a React render; `useChatModelRuntime.refresh` is a thin
 * wrapper. External selections are left untouched since they have no backend mirror.
 */
// Prevent older concurrent status reads from overwriting newer results.
let syncGeneration = 0;
let loraSyncGeneration = 0;
let lastIdleUnloadArmed = false;

async function readIdleUnloadArmed(): Promise<boolean> {
  try {
    const settings = await loadOpenAIAutoSwitchSettings();
    lastIdleUnloadArmed = settings.idleUnloadActive;
  } catch {
    // Preserve the last answer: treating a settings blip as disarmed would discard the pick.
  }
  return lastIdleUnloadArmed;
}

async function syncInferenceStatusToStore(options?: {
  signal?: AbortSignal;
  includeLoras?: boolean;
  preserveIdleUnloaded?: boolean;
  /** A TTS load owns the chat slot even though Chat did not start the load. */
  externalChatSlotLoad?: boolean;
}): Promise<void> {
  const signal = options?.signal;
  const downWhenIssued = isBackendDownForDesktopUpdate();
  const includeLoras = options?.includeLoras ?? true;
  const generation = ++syncGeneration;
  const loraGeneration = includeLoras ? ++loraSyncGeneration : null;
  const superseded = () => generation !== syncGeneration;
  const loraSuperseded = () =>
    loraGeneration !== null && loraGeneration !== loraSyncGeneration;
  const { setModels, setLoras, setCheckpoint, setModelsError } =
    useChatRuntimeStore.getState();
  setModelsError(null);
  try {
    const selectedAtStart = useChatRuntimeStore.getState().params.checkpoint;
    const [listRes, statusRes, , idleUnloadArmed] = await Promise.all([
      listModels(),
      getInferenceStatus(signal),
      // Settled from this request alone. Read out of the aggregate below, a sibling
      // rejection discarded a good list yet still marked the inventory settled, so a
      // resident LoRA classified as a base model and pinned a new pair generalized.
      includeLoras
        ? listLoras().then(
            (lorasRes) => {
              if (!signal?.aborted && !loraSuperseded()) {
                setLoras(lorasRes.loras.map(toLoraSummary));
              }
              return lorasRes;
            },
            (error) => {
              if (!signal?.aborted && !loraSuperseded()) {
                useChatRuntimeStore.setState({ loraInventorySettled: true });
              }
              throw error;
            },
          )
        : Promise.resolve(null),
      options?.preserveIdleUnloaded
        ? readIdleUnloadArmed()
        : Promise.resolve(false),
    ]);

    if (signal?.aborted || superseded()) return;

    setModels(listRes.models.map(toChatModelRow));

    const statusLoading = (statusRes.loading?.length ?? 0) > 0;
    // A replacement names the outgoing model active and the incoming one loading. Adopting
    // the outgoing one sets the checkpoint the observer needs empty, so it writes this alone.
    if (statusLoading && serverModelWaitOutstanding()) return;

    const selectedCheckpoint = useChatRuntimeStore.getState().params.checkpoint;
    const isExternalSelectionActive = isExternalModelId(selectedCheckpoint);
    const selectionChanged = selectedCheckpoint !== selectedAtStart;
    // The local selection is re-derived from this status on every mount, so adopting a TTS model made
    // it the chat model without the user picking it. Read the slot as empty and the eviction branch
    // below clears the stale pick, as it does for an image or video load.
    const chatActiveModel =
      statusRes.active_model &&
      !isSpeechOnlyStatus(statusRes) &&
      !(statusLoading && options?.externalChatSlotLoad);
    if (
      chatActiveModel &&
      !isExternalSelectionActive &&
      !selectionChanged
    ) {
      const checkpointId = resolveInferenceCheckpointId(statusRes);
      if (checkpointId) {
        const previousGgufVariant =
          useChatRuntimeStore.getState().activeGgufVariant;
        // A model loaded outside this tab replaces the resident one, and the pin belonged to the old
        // one: keeping it reloads that one from another's settings.
        if (
          checkpointId !== selectedCheckpoint ||
          (statusRes.gguf_variant ?? null) !== (previousGgufVariant ?? null)
        ) {
          useChatRuntimeStore.setState({ activeLoadId: null });
        }
        setCheckpoint(checkpointId, statusRes.gguf_variant);
        applyActiveModelStatusToStore(statusRes, {
          previousCheckpoint: selectedCheckpoint,
          previousGgufVariant,
          // With no prior selection this is Studio discovering the server's resident model, so its
          // global-only snapshot belongs to this checkpoint and is safe to migrate.
          adoptingExistingServerModel: selectedCheckpoint === "",
        });
        // setModels(listRes...) above used catalog data, which omits audio capability. Re-apply live
        // status so attach gates survive a refresh.
        syncModelCapabilities(checkpointId, statusRes);

        // Against an already-resident model, history can load before this first status
        // has a checkpoint, so its own recount never runs. The thread guard stops a null
        // thread publishing an empty count.
        const hydrated = useChatRuntimeStore.getState();
        if (
          !selectedCheckpoint &&
          hydrated.contextUsage == null &&
          hydrated.activeThreadId != null &&
          hydrated.loadedContextLength != null &&
          !isExternalModelId(checkpointId)
        ) {
          void refreshContextUsage({ threadId: hydrated.activeThreadId });
        }
      }
    } else if (
      !chatActiveModel &&
      !isExternalSelectionActive &&
      !selectionChanged
    ) {
      if (isIdleUnloadedStatus(statusRes, idleUnloadArmed)) return;
      // Loading an image, video or audio model evicts the chat one (one GPU owner), and nothing else
      // here would say so: the picker keeps the selection, so the header would claim it is loaded
      // and the next prompt would come back a bare 400.
      const { residentCheckpoint: wasResident, modelLoading } =
        useChatRuntimeStore.getState();
      // specFallbackReason survives here, so clearing activeModelIsLocal alone would flip a local
      // model's warning to "download failed".
      useChatRuntimeStore.setState({
        residentCheckpoint: null,
        modelRequiresTrustRemoteCode: false,
        loadedIsMultimodal: false,
        loadedVisionDisabledByUser: null,
        loadedIsDiffusion: false,
      });
      // A known prior resident or a definitive speech-only owner both prove the
      // persisted Chat pick is stale. Do not clear for a Chat load that this tab
      // started. TTS is different because it owns this same slot.
      if (
        (wasResident || isSpeechOnlyStatus(statusRes)) &&
        selectedCheckpoint &&
        (!modelLoading || options?.externalChatSlotLoad)
      ) {
        // Already the clean id the header shows: resolveInferenceCheckpointId put it there, not a load path.
        if (wasResident) {
          toast.info(`${wasResident} is no longer loaded`, {
            description:
              "The server released it, which loading an image, video or audio model does. Pick it again to keep chatting.",
          });
        }
        // Drop the pick too, as a server-side unload does: the name alone reads as "this is my model"
        // whatever the tick does, and sending to it returns a bare 400.
        useChatRuntimeStore.getState().clearCheckpoint();
      }
    }
  } catch (error) {
    // A superseded refresh reports nothing, or a stale failure would raise a toast about a read
    // whose answer would have been discarded. The LoRA inventory settles from its own request.
    if (signal?.aborted || superseded()) return;
    // The update screen already reports the backend it stopped.
    if (isSilencedDesktopUpdateFailure(error, downWhenIssued)) return;
    const message =
      error instanceof Error ? error.message : "Failed to load models";
    setModelsError(message);
    toast.error("Failed to refresh models", {
      description: message,
    });
  }
}

/**
 * The mount handoff: hydrate from status, then observe until the server settles. The gate is up
 * before the sync is issued, since a refresh issued later can answer first and adopt the outgoing
 * model.
 */
async function refreshAndWaitForServerModel(options?: {
  signal?: AbortSignal;
  includeLoras?: boolean;
  preserveIdleUnloaded?: boolean;
  externalChatSlotLoad?: boolean;
}): Promise<void> {
  const signal = options?.signal;
  const release = beginServerModelWait(signal);
  try {
    await syncInferenceStatusToStore(options);
    await waitForServerModel(signal);
  } finally {
    release();
  }
}

/**
 * Reconcile the UI after the SERVER unloaded the active model out from under it (e.g. a llama.cpp
 * update unloads the running model to swap the binary): the model selector drops to "select model"
 * instead of pointing at a model that now 400s on send. Imperative so the global llama-update
 * banner, which has no chat-runtime handle, can call it. Only a LOCAL selection points at the
 * unloaded model: an external-provider selection has no llama.cpp mirror and still works, so
 * clearing it would drop a valid, unrelated model.
 */
export async function resyncInferenceStatusAfterServerModelChange(): Promise<void> {
  // Both llama.cpp update paths land here, and an update replaces the binary whose --help the flag catalogue describes.
  invalidateLlamaFlagCatalog();
  if (!isExternalModelId(useChatRuntimeStore.getState().params.checkpoint)) {
    useChatRuntimeStore.getState().clearCheckpoint();
  }
  await syncInferenceStatusToStore();
}

function pickOf(info: {
  id: string;
  ggufVariant?: string | null;
  nativePathToken?: string | null;
}): LoadingModelPick {
  return {
    id: info.id,
    ggufVariant: info.ggufVariant ?? null,
    nativePathToken: info.nativePathToken ?? null,
  };
}

export function useChatModelRuntime() {
  const params = useChatRuntimeStore((state) => state.params);
  const models = useChatRuntimeStore((state) => state.models);
  const loras = useChatRuntimeStore((state) => state.loras);
  const setParams = useChatRuntimeStore((state) => state.setParams);
  const setModelsError = useChatRuntimeStore((state) => state.setModelsError);
  const setLastModelLoadError = useChatRuntimeStore(
    (state) => state.setLastModelLoadError,
  );
  const clearCheckpoint = useChatRuntimeStore((state) => state.clearCheckpoint);

  const [loadingModel, setLoadingModel] = useState<{
    id: string;
    displayName: string;
    isDownloaded?: boolean;
    isCachedLora?: boolean;
    ggufVariant?: string | null;
    nativePathToken?: string | null;
  } | null>(null);
  const [loadToastDismissed, setLoadToastDismissed] = useState(false);
  const [loadProgress, setLoadProgress] = useState<{
    percent: number | null;
    label: string | null;
    phase: "downloading" | "starting";
  } | null>(null);
  const loadAbortRef = useRef<AbortController | null>(null);
  const loadingModelRef = useRef<typeof loadingModel>(null);
  const loadToastIdRef = useRef<string | number | null>(null);
  const loadToastDismissedRef = useRef(false);
  const cancelUnloadPendingRef = useRef(false);
  const loadLifecycleLeaseRef = useRef<ModelLifecycleLease | null>(null);
  // The run that owns the single shared load slot. Async callbacks compare their own
  // token against it, so a superseded run cannot release a newer run's slot.
  const activeLoadRunRef = useRef<ActiveModelLoadRun | null>(null);

  const setLoadToastDismissedState = useCallback((dismissed: boolean) => {
    loadToastDismissedRef.current = dismissed;
    setLoadToastDismissed(dismissed);
  }, []);

  const resetLoadingUi = useCallback(() => {
    const inFlight = loadingModelRef.current;
    setLoadingModel(null);
    setLoadProgress(null);
    loadingModelRef.current = null;
    loadAbortRef.current = null;
    loadToastIdRef.current = null;
    setLoadToastDismissedState(false);
    if (inFlight) {
      useChatRuntimeStore.getState().clearLoadingModelPick(pickOf(inFlight));
    }
    if (!cancelUnloadPendingRef.current) {
      const lease = loadLifecycleLeaseRef.current;
      loadLifecycleLeaseRef.current = null;
      if (lease !== null) {
        useChatRuntimeStore.getState().endModelLoading(lease);
      }
    }
  }, [setLoadToastDismissedState]);

  const resetLoadingUiForRun = useCallback(
    (run: ActiveModelLoadRun) => {
      if (!ownsModelLoadRun(activeLoadRunRef.current, run)) return;
      // Cancellation owns the slot until /unload settles. The aborted load's
      // finally block may arrive first, but must not release that slot.
      if (run.cancelPromise) return;
      activeLoadRunRef.current = releaseOwnedModelLoadRun(
        activeLoadRunRef.current,
        run,
      );
      resetLoadingUi();
    },
    [resetLoadingUi],
  );

  const renderLoadDescription = useCallback(
    (
      title: string,
      message: string,
      progressPercent?: number | null,
      progressLabel?: string | null,
    ) =>
      createElement(ModelLoadDescription, {
        title,
        message,
        progressPercent,
        progressLabel,
      }),
    [],
  );

  const refresh = useCallback(
    async (options?: {
      waitForServerModel?: boolean;
      signal?: AbortSignal;
      includeLoras?: boolean;
      preserveIdleUnloaded?: boolean;
      externalChatSlotLoad?: boolean;
    }) => {
      if (options?.waitForServerModel) {
        await refreshAndWaitForServerModel(options);
        return;
      }
      await syncInferenceStatusToStore(options);
    },
    [],
  );

  // Nothing here polls /status: refresh runs on mount and when the model lists change. So an image
  // or video load evicting the chat model went unseen and the header showed it as loaded.
  // Re-read whenever another runtime finishes a load.
  useEffect(
    () =>
      subscribeModelLifecycle(({ runtime }) => {
        // Dictation is a sidecar and evicts nothing; chat's own loads reconcile themselves. A "tts" load
        // does neither: it is the Audio page taking this very slot.
        if (runtime === "chat" || runtime === "stt") return;
        // Both edges, not only the settle. The arbiter evicts chat inside the image or video load POST,
        // before the download starts, so waiting for the load to finish left the picker and the header
        // naming a model that had already gone and that 400s on send, for the whole download.
        void refresh({
          includeLoras: false,
          externalChatSlotLoad: runtime === "tts",
        });
      }),
    [refresh],
  );

  useEffect(
    () =>
      subscribeResidentStatusRefresh(() => {
        void refresh({ includeLoras: false, preserveIdleUnloaded: true });
      }),
    [refresh],
  );

  /**
   * Stop the run that owns the slot and wait for the backend to acknowledge it.
   *
   * The abort signal alone cannot stop a load that is already POSTing, so /unload
   * is what actually interrupts it. Awaiting that answer is what lets a replacement
   * claim the slot without racing the load it replaces.
   */
  const cancelLoadRun = useCallback(
    async (
      expectedRun?: ActiveModelLoadRun,
      preserveCheckpoint = false,
    ): Promise<boolean> => {
      const run = activeLoadRunRef.current;
      if (!run || (expectedRun && !ownsModelLoadRun(run, expectedRun))) {
        return false;
      }
      if (run.cancelPromise) return run.cancelPromise;

      const model = loadingModelRef.current;
      run.abortController.abort();
      loadAbortRef.current = null;
      loadingModelRef.current = null;
      const tid = loadToastIdRef.current;
      loadToastIdRef.current = null;
      setLoadingModel(null);
      setLoadProgress(null);
      setLoadToastDismissedState(false);
      if (tid != null) toast.dismiss(tid);
      if (model) {
        useChatRuntimeStore.getState().clearLoadingModelPick(pickOf(model));
      }
      const isCachedOrLocal = model?.isDownloaded || model?.isCachedLora;
      toast.info("Stopping model load", {
        description: isCachedOrLocal
          ? undefined
          : "The current download may still finish in the background.",
      });
      const cancelPromise = (async (): Promise<boolean> => {
        try {
          // Unforced on purpose: a chat may stream on the PREVIOUS model and must not
          // be killed by cancelling this load. The route cancels a still-loading
          // model ahead of its active-generation refusal.
          //
          // Scoped to this run, and only once it has actually POSTed /load: the
          // matching cancel_load_request_id binds the unload to this attempt alone,
          // and a load whose registration has not landed yet is replayed from the
          // backend's cancel tombstone. The old second, unscoped /unload is exactly
          // what let cancellation race the load it was meant to stop.
          if (run.loadAttemptPath) {
            await unloadModel({
              model_path: run.loadAttemptPath,
              cancel_load_request_id: run.requestId,
            });
          }
          // A standalone cancellation can race before the target reaches the backend.
          // /unload then leaves the resident model untouched, so derive the UI
          // checkpoint from the backend rather than clearing it optimistically.
          if (!preserveCheckpoint) {
            clearCheckpoint();
            await refresh();
          }
          return true;
        } catch (error) {
          const detail =
            error instanceof Error ? error.message : "Unknown unload error";
          const message = `Failed to stop ${model?.displayName ?? "the model"}`;
          setModelsError(`${message}: ${detail}`);
          toast.error(message, { description: detail });
          // The request failed, so reconcile against the backend before releasing the
          // slot. The caller still receives false and must not start a replacement
          // from an uncertain backend state.
          try {
            // The unabortable /load can still land after this unload failed and make this run's
            // own target resident. Read status only once the run has stopped, or the store keeps
            // naming the old checkpoint while prompts are served by the newly loaded model.
            await run.settledPromise;
            await refresh();
            setModelsError(`${message}: ${detail}`);
          } catch (refreshError) {
            const refreshDetail =
              refreshError instanceof Error
                ? refreshError.message
                : "Unknown status refresh error";
            setModelsError(
              `${message}: ${detail}. Failed to refresh model status: ${refreshDetail}`,
            );
          }
          return false;
        } finally {
          if (ownsModelLoadRun(activeLoadRunRef.current, run)) {
            // The aborted coroutine may still be parked inside an unabortable preflight
            // await (status, a consent dialog, staged metadata). Its own abort checks stop
            // it from touching shared state, but hold the slot until it has actually
            // unwound, or a replacement could overlap the run it just replaced.
            await run.settledPromise;
            if (run.loadAttemptPath && run.forceCancelActive && !run.residentModelUnloaded) {
              try {
                const status = await getInferenceStatus();
                if ((status.loading?.length ?? 0) === 0) {
                  run.residentModelUnloaded = !residentModelMatchesPick(status, {
                    id: run.rollbackCheckpoint ?? "",
                    loadPath: run.rollbackLoadId ?? run.rollbackCheckpoint,
                    ggufVariant: run.rollbackVariant,
                  });
                }
              } catch {
                // An unavailable status is inconclusive; do not clear a checkpoint blindly.
              }
            }
            // The backend may serve nothing while the store still advertises that checkpoint.
            // Reconcile before releasing the slot. The run's rollback target lives on the run,
            // not in the store, so this cannot lose the replacement's target.
            if (
              (!run.loadAttemptPath && run.residentModelUnloaded) ||
              (run.loadAttemptPath && run.forceCancelActive && run.residentModelUnloaded)
            ) {
              try {
                // The run applied its target's config before the preliminary unload, so the store
                // still names the former resident while holding the cancelled target's settings.
                restoreRollbackConfigForClear(run);
                clearCheckpoint();
                await refresh();
              } catch {
                // The cancel's own error reporting stands; the slot is still released.
              }
            }
            activeLoadRunRef.current = releaseOwnedModelLoadRun(
              activeLoadRunRef.current,
              run,
            );
            const lease = loadLifecycleLeaseRef.current;
            loadLifecycleLeaseRef.current = null;
            if (lease !== null) {
              useChatRuntimeStore.getState().endModelLoading(lease);
            }
          }
        }
      })();
      run.cancelPromise = cancelPromise;
      return cancelPromise;
    },
    [clearCheckpoint, refresh, setLoadToastDismissedState, setModelsError],
  );

  const cancelLoadingWithCheckpointPolicy = useCallback(
    (preserveCheckpoint = false): Promise<boolean> => {
      const run = activeLoadRunRef.current;
      return run
        ? cancelLoadRun(run, preserveCheckpoint)
        : Promise.resolve(false);
    },
    [cancelLoadRun],
  );

  const cancelLoading = useCallback(
    (): Promise<boolean> => cancelLoadingWithCheckpointPolicy(false),
    [cancelLoadingWithCheckpointPolicy],
  );
  /**
   * Stop the pending load so a different pick can take the slot. Preserves the
   * working checkpoint, which the replacement needs as its rollback target.
   */
  const cancelLoadingForReplacement = useCallback(
    async (intentId: number): Promise<boolean> => {
      const run = activeLoadRunRef.current;
      pendingExternalReplacement = { intentId, config: run?.rollbackConfig };
      const stopped = await cancelLoadingWithCheckpointPolicy(true);
      // The load can finish after the caller observed its store flags but before
      // cancellation captured the run. With no owner left there is nothing uncertain
      // to stop, so the replacement may proceed.
      if (!stopped && !activeLoadRunRef.current) {
        return true;
      }
      if (!stopped && pendingExternalReplacement?.intentId === intentId) {
        pendingExternalReplacement = null;
      }
      return stopped;
    },
    [cancelLoadingWithCheckpointPolicy],
  );

  const invalidatePendingModelSelection = useCallback((): number => {
    modelSelectionIntentEpoch += 1;
    return modelSelectionIntentEpoch;
  }, []);

  const discardExternalReplacement = useCallback((intentId: number): void => {
    if (pendingExternalReplacement?.intentId === intentId) {
      pendingExternalReplacement = null;
      pendingReplacementRollback = null;
    }
  }, []);

  const restoreConfigForExternalReplacement = useCallback(
    (intentId: number): void => {
      const config =
        (pendingExternalReplacement?.intentId === intentId
          ? pendingExternalReplacement.config
          : undefined) ?? pendingReplacementRollback?.config;
      if (config) {
        applyPerModelConfigToRuntime(config, {
          isDiffusion: useChatRuntimeStore.getState().loadedIsDiffusion,
        });
      }
      discardExternalReplacement(intentId);
      pendingReplacementRollback = null;
    },
    [discardExternalReplacement],
  );

  const isModelSelectionIntentCurrent = useCallback(
    (intentId: number) => modelSelectionIntentEpoch === intentId,
    [],
  );

  const selectModel = useCallback(
    async (selection: string | SelectedModelInput) => {
      const modelId = typeof selection === "string" ? selection : selection.id;
      const loadPath =
        (typeof selection === "string" ? null : selection.loadId) || modelId;
      const ggufVariant =
        typeof selection === "string" ? undefined : selection.ggufVariant;
      const forceReload =
        typeof selection === "string" ? false : selection.forceReload ?? false;
      const nativePathToken =
        typeof selection === "string" ? undefined : selection.nativePathToken;
      const nativePathExpiresAtMs =
        typeof selection === "string"
          ? null
          : selection.nativePathExpiresAtMs ?? null;
      const explicitIsGguf =
        typeof selection === "string" ? undefined : selection.isGguf;
      let isDiffusion =
        typeof selection === "string" ? undefined : selection.isDiffusion;
      let previousConfigForReplacement =
        typeof selection === "string" ? undefined : selection.previousConfig;
      const restorePreviousConfig = () => {
        if (previousConfigForReplacement) {
          applyPerModelConfigToRuntime(previousConfigForReplacement, {
            isDiffusion:
              useChatRuntimeStore.getState().loadedIsDiffusion,
          });
        }
      };
      const throwOnError =
        typeof selection === "string" ? false : selection.throwOnError ?? false;
      const keepSpeculative =
        typeof selection === "string" ? false : selection.keepSpeculative ?? false;
      const currentVariant = useChatRuntimeStore.getState().activeGgufVariant;
      const initiallyLoadingSamePick =
        loadingModelRef.current?.id === modelId &&
        (loadingModelRef.current?.ggufVariant ?? null) === (ggufVariant ?? null) &&
        (loadingModelRef.current?.nativePathToken ?? null) ===
          (nativePathToken ?? null);
      if (
        !forceReload &&
        (!modelId ||
          (params.checkpoint === modelId &&
            (ggufVariant ?? null) === (currentVariant ?? null) &&
            !loadingModelRef.current &&
            !useChatRuntimeStore.getState().loadingModelPick &&
            !pendingReplacementRollback))
      ) {
        // A resident-model re-selection is still a user intent. Invalidate a local pick
        // that may be awaiting status or a confirmation before it owns a run.
        if (modelId) modelSelectionIntentEpoch += 1;
        restorePreviousConfig();
        return;
      }
      if (
        initiallyLoadingSamePick &&
        !activeLoadRunRef.current?.cancelPromise
      ) {
        restorePreviousConfig();
        return;
      }
      dismissStartToastsForModelSelection();

      // Register the user's intent before awaiting cancellation. A superseded run's
      // error cleanup must not restore its previous config over settings the new
      // caller has already applied.
      const loadIntentId = ++modelSelectionIntentEpoch;
      const activeRunBeforeCredentials = activeLoadRunRef.current;

      const isLocal = isLocalModelPath(modelId);
      let hfToken = useChatRuntimeStore.getState().hfToken || null;
      // Credential prompts must complete before cancelling a pending run: a decline must not
      // strand the resident that run already unloaded while preparing its own Hub load.
      const mayReachHub =
        !isLocal && !isOllamaModelId(modelId) && nativePathToken == null;
      if (mayReachHub) {
        const preparedToken = await prepareHfTokenForUse(hfToken);
        if (!preparedToken.proceed) {
          if (modelSelectionIntentEpoch === loadIntentId) {
            toast.error("Model load cancelled.");
            // This pick invalidated the previous run before opening credentials. If that run
            // fails while the dialog is open, its stale-intent catch cannot restore the config
            // it staged over the still-resident model. Wait until the run settles, then reconcile
            // status if it had already unloaded its resident.
            if (activeRunBeforeCredentials) {
              void activeRunBeforeCredentials.settledPromise.then(async () => {
                if (modelSelectionIntentEpoch !== loadIntentId) return;
                if (!activeRunBeforeCredentials.residentModelUnloaded) {
                  const current = useChatRuntimeStore.getState();
                  if (
                    current.params.checkpoint ===
                    activeRunBeforeCredentials.rollbackCheckpoint
                  ) {
                    restoreRollbackConfigForClear(activeRunBeforeCredentials);
                  }
                  return;
                }
                if (activeRunBeforeCredentials.residentModelUnloaded) {
                  try {
                    const status = await getInferenceStatus();
                    if (modelSelectionIntentEpoch !== loadIntentId) return;
                    if (
                      (status.loading?.length ?? 0) === 0 &&
                      useChatRuntimeStore.getState().params.checkpoint ===
                        activeRunBeforeCredentials.rollbackCheckpoint
                    ) {
                      if (!status.active_model) {
                        restoreRollbackConfigForClear(activeRunBeforeCredentials);
                        useChatRuntimeStore.getState().clearCheckpoint();
                      } else if (
                        residentModelMatchesPick(status, {
                          id: activeRunBeforeCredentials.rollbackCheckpoint ?? "",
                          loadPath:
                            activeRunBeforeCredentials.rollbackLoadId ??
                            activeRunBeforeCredentials.rollbackCheckpoint,
                          ggufVariant: activeRunBeforeCredentials.rollbackVariant,
                        })
                      ) {
                        restoreRollbackConfigForClear(activeRunBeforeCredentials);
                      }
                      await refresh();
                    }
                  } catch {
                    // Preserve state when backend status is unavailable; a later refresh can reconcile it.
                  }
                  return;
                }
              });
            }
          }
          return;
        }
        hfToken = preparedToken.token;
      }
      if (modelSelectionIntentEpoch !== loadIntentId) return;
      // A prior run may have failed while this pick was waiting for Hub credentials. If it
      // never unloaded the resident, it could not restore its staged config after losing intent.
      if (activeRunBeforeCredentials && activeLoadRunRef.current !== activeRunBeforeCredentials) {
        const current = useChatRuntimeStore.getState();
        if (
          !activeRunBeforeCredentials.residentModelUnloaded &&
          !activeRunBeforeCredentials.loadAttemptPath &&
          current.params.checkpoint === activeRunBeforeCredentials.rollbackCheckpoint
        ) {
          if (activeRunBeforeCredentials.rollbackConfig) {
            previousConfigForReplacement = activeRunBeforeCredentials.rollbackConfig;
            restoreRollbackConfigForClear(activeRunBeforeCredentials);
          }
        } else if (
          activeRunBeforeCredentials.loadAttemptPath &&
          current.params.checkpoint != null
        ) {
          if (
            current.params.checkpoint !== activeRunBeforeCredentials.rollbackCheckpoint
          ) {
            // The prior run successfully made its target resident while credentials were open.
            previousConfigForReplacement = currentRuntimePerModelConfig({
              includeMaxSeqLength: true,
            });
          } else if (activeRunBeforeCredentials.residentModelUnloaded) {
            // A failed target load can still settle with a successful compensation reload of the
            // rollback checkpoint. Confirm that resident before snapshotting its effective config;
            // a failed compensation leaves the same checkpoint in the store but no resident.
            try {
              const status = await getInferenceStatus();
              if (
                (status.loading?.length ?? 0) === 0 &&
                residentModelMatchesPick(status, {
                  id: activeRunBeforeCredentials.rollbackCheckpoint ?? "",
                  loadPath:
                    activeRunBeforeCredentials.rollbackLoadId ??
                    activeRunBeforeCredentials.rollbackCheckpoint,
                  ggufVariant: activeRunBeforeCredentials.rollbackVariant,
                })
              ) {
                previousConfigForReplacement = currentRuntimePerModelConfig({
                  includeMaxSeqLength: true,
                });
              }
            } catch {
              // Keep the existing snapshot if backend status is unavailable.
            }
          }
        }
      }




      if (pendingReplacementRollback?.config) {
        previousConfigForReplacement = pendingReplacementRollback.config;
      }
      // The cancelled run's own rollback target is the model that was working before
      // it, not the transient state it may already have applied. Adopt that target,
      // or a failed replacement restores the wrong model's runtime settings.
      const inheritCancelledRunRollback = (cancelledRun: ActiveModelLoadRun) => {
        if (cancelledRun.rollbackConfig) {
          previousConfigForReplacement = cancelledRun.rollbackConfig;
        }
        pendingReplacementRollback = {
          checkpoint: cancelledRun.rollbackCheckpoint,
          config: previousConfigForReplacement,
          // The run really removed the resident with its own /unload, so the replacement must be
          // prepared to restore it. A POSTed /load does not undo that: the resident this rolls back
          // to is gone either way, and the cancellation reconciliation only clears the store
          // checkpoint for the pre-POST case. The variant and access identity travel with it because
          // clearCheckpoint() drops them from the store before the replacement reads them.
          residentUnloaded: cancelledRun.residentModelUnloaded,
          variant: cancelledRun.rollbackVariant ?? null,
          loadId: cancelledRun.rollbackLoadId,
          nativePathToken: cancelledRun.rollbackNativePathToken,
          nativePathExpiresAtMs: cancelledRun.rollbackNativePathExpiresAtMs,
          loadedState: cancelledRun.rollbackLoadedState,
        };
      };

      // A different pick supersedes the load in flight. Await its cancellation and the
      // backend unload before claiming the slot, then re-check: the load can settle
      // between the two, and another selection may be waiting on the same run.
      while (true) {
        const activeRun = activeLoadRunRef.current;
        const inFlightLoad =
          loadingModelRef.current ??
          useChatRuntimeStore.getState().loadingModelPick;
        // Cancellation clears the picker before its unload settles, yet the run keeps
        // the slot and the lifecycle lease until then. Break only when neither is left:
        // a pick arriving mid-cancel would otherwise find the lease held and be dropped.
        if (!inFlightLoad && !activeRun) break;
        if (inFlightLoad) {
          const loadingSamePick =
            inFlightLoad.id === modelId &&
            (inFlightLoad.ggufVariant ?? null) === (ggufVariant ?? null) &&
            (inFlightLoad.nativePathToken ?? null) === (nativePathToken ?? null);
          if (loadingSamePick && !activeRun?.cancelPromise) {
            restorePreviousConfig();
            return;
          }
          if (!activeRun) {
            // Published to the store but no run owns it yet: the other caller is still
            // in preflight, so this pick cannot safely take the slot from it.
            restorePreviousConfig();
            return;
          }
        }
        // Only a run that still owns the slot can be superseded; the picker-only case
        // returned above. This also narrows the run for the cancellation below.
        if (!activeRun) break;
        // Keep the working checkpoint as the rollback target for the replacement.
        // A standalone Stop still clears the selection.
        inheritCancelledRunRollback(activeRun);
        const stopped = await cancelLoadRun(activeRun, true);
        // Cancellation can settle after the slot is released, so adopt the target
        // again from the run the cancel was asked about.
        inheritCancelledRunRollback(activeRun);
        if (modelSelectionIntentEpoch !== loadIntentId) {
          if (throwOnError) {
            throw new Error("Model selection was superseded by a newer choice.");
          }
          return;
        }
        if (!stopped) {
          restorePreviousConfig();
          // The unload failed, so the backend state is uncertain and this run's rollback target
          // no longer describes what is resident. A later selection must derive its rollback from
          // the refreshed store instead of inheriting the failed run's checkpoint and config.
          pendingReplacementRollback = null;
          const message =
            "The current model could not be stopped, so the new model was not loaded.";
          setModelsError(message);
          if (throwOnError) throw new Error(message);
          return;
        }
      }

      // A local pick that is superseded by a later selection must not keep the slot.
      // The replacement loop only judges the load present when it ran. A rival pick can
      // still claim the slot during the awaits below, and it owns the resident model
      // now, so the adopt and confirm paths must yield to it rather than adopt over it.
      const rivalLoadStarted = (): boolean => {
        const rival = useChatRuntimeStore.getState().loadingModelPick;
        if (!rival) return false;
        return !(
          rival.id === modelId &&
          (rival.ggufVariant ?? null) === (ggufVariant ?? null) &&
          (rival.nativePathToken ?? null) === (nativePathToken ?? null)
        );
      };
      if (modelSelectionIntentEpoch !== loadIntentId) {
        if (throwOnError) {
          throw new Error("Model selection was superseded by a newer choice.");
        }
        return;
      }
      // Ask the backend, not params.checkpoint: an external pick leaves the local model resident, and
      // a pinned cached row loads under a name its picker row never shows.
      // A staged config always carries forceReload, so Apply still reloads and prompts.
      const selectedCheckpoint =
        useChatRuntimeStore.getState().params.checkpoint;
      const pendingConfig =
        typeof selection !== "string" ? selection.config : undefined;
      if (!forceReload && !nativePathToken) {
        const residentStatus = await getInferenceStatus().catch(() => null);
        // Warm before reconciling the remembered GPU pick below: load-on-selection can run before any
        // GPU hook mounted, and a cold cache passes the pick through unvalidated.
        if (residentStatus && pendingConfig?.selectedGpuIds !== undefined) {
          await ensureGpuDeviceCache().catch(() => {});
        }
        // What /load would carry for a pick with no saved config, which is not always the live runtime:
        // performLoad treats a different checkpoint or variant as a switch and clears the per-model fields
        // first, so comparing the outgoing model's settings would both prompt for a load that dedupes and
        // adopt one that does not. gpuMemoryMode is standing, and kvCacheDtype and tensorParallel are not
        // reset, so those three still come from the store.
        const live = useChatRuntimeStore.getState();
        const resetsPerModelSettings = Boolean(
          live.params.checkpoint &&
            (live.params.checkpoint !== modelId ||
              (live.activeGgufVariant ?? null) !== (ggufVariant ?? null)) &&
            !keepSpeculative,
        );
        const comparedConfig =
          pendingConfig ??
          (resetsPerModelSettings
            ? {
                ...DEFAULT_PER_MODEL_CONFIG,
                kvCacheDtype: live.kvCacheDtype ?? null,
                tensorParallel: live.tensorParallel ?? false,
                gpuMemoryMode: live.gpuMemoryMode,
              }
            : currentRuntimePerModelConfig());
        // The slot count an unset --parallel resolves to. Session-cached, and 0 is the catalogue's own
        // "unknown", which the comparison reads as a reload.
        const managedFlags = residentStatus
          ? await loadManagedLlamaFlags().catch(() => null)
          : null;
        // Hoisted so it can run twice: everything above was awaited, and in that window another tab can
        // swap the resident model, which this one is never told about.
        const adoptable = (status: InferenceStatusResponse) =>
          (status.loading?.length ?? 0) === 0 &&
          (status.engine ?? "auto") === (comparedConfig.engine ?? "auto") &&
          residentModelMatchesPick(status, {
            id: modelId,
            loadPath,
            ggufVariant,
          }) &&
          // _reuse_loaded_gguf refuses its own already-loaded answer while the audio probe is outstanding,
          // so load_model reaches its fast path and re-probes there. Skipping /load would leave audio
          // capabilities undetected for as long as the server runs.
          status.audio_probe_pending !== true &&
          // A repairable speculative fallback is the one case where an identical request is not a no-op:
          // _runtime_matches_intent answers False so the next load retries the drafter, and
          // short-circuiting would strand the user with speculation off.
          !residentSpeculativeNeedsRepair(
            status,
            normalizeSpeculativeType(pendingConfig?.speculativeType) ??
              readPersistedSpeculativeType(),
            // The route derives gguf_path from the identifier alone, and the drafter_not_found retry is
            // guarded on its absence.
            (loadPath ?? modelId).toLowerCase().endsWith(".gguf"),
          ) &&
          // The id names the weights, not how the server was invoked: a remembered context length, drafter,
          // placement or extra arg the resident load does not run is a real reload. Not `pendingConfig`: with
          // no saved record the caller has already run applyModelLoadConfigToRuntime(null), which resets the
          // store to DEFAULT_PER_MODEL_CONFIG, and performLoad reads the store for the rest.
          residentRuntimeMatchesConfig(status, comparedConfig, {
            speculativeType: readPersistedSpeculativeType(),
            gpuMemoryMode: readPersistedGpuMemoryMode(),
            gpuLayers: GPU_LAYERS_AUTO,
            nCpuMoe: 0,
            // The n_ctx /load would send, from performLoad's own inputs, so an unset
            // length resolves the same way on both sides.
            resolveContextLength: (customContextLength) => {
              const live = useChatRuntimeStore.getState();
              const platform = usePlatformStore.getState();
              // Identity matched above, so the resident model is this pick.
              const residentIsGguf = status.is_gguf ?? false;
              return resolveLoadMaxSeqLength({
                modelId,
                ggufVariant,
                isGguf: residentIsGguf,
                customContextLength,
                loadedContextLength: live.loadedContextLength,
                currentCheckpoint: live.params.checkpoint,
                activeGgufVariant: live.activeGgufVariant,
                isMlx: isServedByMlx(
                  residentIsGguf,
                  platform.deviceType,
                  platform.chatOnlyReason,
                ),
                pinnedMaxSeqLength: normalizeMaxSeqLength(
                  pendingConfig
                    ? pendingConfig.maxSeqLength
                    : resolveInitialConfig(modelId, ggufVariant).config
                        .maxSeqLength,
                ),
                defaultMaxSeqLength: live.params.maxSeqLength || DEFAULT_MAX_SEQ_LENGTH,
                presetSource: live.activePresetSource,
              });
            },
            parallelSlots: managedFlags?.defaultParallelSlots || null,
            // Only a config page pick carries one; else the store (cleared on reset)
            splitRatio:
              pendingConfig?.tensorSplit !== undefined
                ? pendingConfig.tensorSplit
                : resetsPerModelSettings
                  ? null
                  : useChatRuntimeStore.getState().splitRatio,
            // What /load sends: a pick saved in another index namespace, or naming GPUs that are gone, is
            // reconciled to Automatic before it leaves.
            reconcileGpuIds: (ids, savedIndexKind) =>
              reconcilePersistedGpuIds(
                ids,
                savedIndexKind,
                status.is_diffusion ?? false,
              ),
            defaultEngineGpuIds: defaultEngineGpuIds(),
            normalizeSpeculative: normalizeSpeculativeType,
          });
        if (
          residentStatus &&
          adoptable(residentStatus) &&
          // Both are server-wide, so a save leaves the pick and its config identical while
          // adopt_load_intent_if_matched forces a reload anyway; without them a policy or budget
          // change between two picks would never reach the child.
          !(await readServerWideReloadHints())
        ) {
          // Read again, and judge again: a status fetched before those awaits describes the model that was
          // resident then, and adopting it would leave the picker naming this model while prompts went
          // to another. A failed read falls through to /load.
          const confirmedStatus = await getInferenceStatus().catch(() => null);
          if (confirmedStatus && adoptable(confirmedStatus)) {
            // Same window as the confirm below: a rival load may have started during that GET, and it owns
            // the resident model now.
            if (rivalLoadStarted()) return;
            // Same window as the confirmation below: a newer pick that could not take the
            // lease still supersedes the status this preflight was about to adopt.
            if (modelSelectionIntentEpoch !== loadIntentId) return;
            // Roll back the config pre-applied for the load that is not happening, before hydrating, so the
            // resident status wins over the staged snapshot. The helper carries the diffusion flag.
            restorePreviousConfig();
            // ...except for maxSeqLength, which the rollback has the last word on: it is a client-side cap no
            // status field echoes, so leaving it rolled back would hand this model the OUTGOING one's cap and
            // applyActiveModelStatus cannot correct it. An absent cap is not silence either:
            // applyPerModelConfigToRuntime resolves it to defaultInferenceParams.maxSeqLength.
            const pickedMaxSeqLength =
              normalizeMaxSeqLength(pendingConfig?.maxSeqLength) ??
              defaultInferenceParams.maxSeqLength;
            const restored = useChatRuntimeStore.getState();
            if (restored.params.maxSeqLength !== pickedMaxSeqLength) {
              restored.setParams({
                ...restored.params,
                maxSeqLength: pickedMaxSeqLength,
              });
            }
            const previousGgufVariant =
              useChatRuntimeStore.getState().activeGgufVariant;
            // Adopt this pick's own pin, by the rule a completed load writes it: the poll skips its clearing
            // while an external pick is active, so a pin taken for an earlier resident would survive and
            // Apply would reload that old model.
            useChatRuntimeStore.setState({
              activeLoadId: loadPath === modelId ? null : loadPath,
            });
            useChatRuntimeStore
              .getState()
              .setCheckpoint(modelId, confirmedStatus.gguf_variant);
            applyActiveModelStatusToStore(confirmedStatus, {
              previousCheckpoint: selectedCheckpoint,
              previousGgufVariant,
            });
            syncModelCapabilities(modelId, confirmedStatus);
            // The pick's own GPU selection, which the hydration above would widen back:
            // adopt_load_intent_if_matched records the incoming pool when it adopts on the fitted
            // subset, and skipping /load skips that.
            if (pendingConfig?.selectedGpuIds !== undefined) {
              const picked = reconcilePersistedGpuIds(
                pendingConfig.selectedGpuIds,
                pendingConfig.selectedGpuIndexKind,
                confirmedStatus.is_diffusion ?? false,
              );
              const hydrated = useChatRuntimeStore.getState();
              if (!sameGpuSelection(hydrated.selectedGpuIds, picked)) {
                useChatRuntimeStore.setState({
                  selectedGpuIds: picked,
                  loadedGpuIds: picked,
                });
              }
            }
            // setCheckpoint above blanked the bar, this path returns before the post-load recount, and a
            // mounted thread does not rerun its history loader, so the bar would stay empty.
            // Adopting the already-resident model completes this replacement without creating a load run.
            // Consume the inherited rollback so a later selection snapshots this model's current state.
            pendingReplacementRollback = null;

            void refreshContextUsage({ afterModelLoad: true });
            return;
          }
        }
      }

      // Hold the lifecycle lease through confirmation and loading. A PREFLIGHT holder (parked on
      // the stop-running-chats confirmation) owns the lease without having published a run or a
      // picker entry, so a pick arriving now reads null from the gate while the holder later
      // yields the slot as stale -- and both picks are lost. Wait, bounded, for the holder to
      // release the lease, then claim it: the user's latest pick must not be dropped by a lease
      // whose owner is still deciding.
      let lifecycleLease: ModelLifecycleLease | null = null;
      while (lifecycleLease === null) {
        lifecycleLease = useChatRuntimeStore
          .getState()
          .beginModelLoading("preparing");
        if (lifecycleLease !== null) break;
        // This pick was itself superseded while waiting; it must not load.
        if (modelSelectionIntentEpoch !== loadIntentId) return;
        await new Promise<void>((resolve) => {
          let settled = false;
          const unsubscribe = useChatRuntimeStore.subscribe((state) => {
            if (settled || state.modelLoading) return;
            settled = true;
            unsubscribe();
            resolve();
          });
          setTimeout(() => {
            if (settled) return;
            settled = true;
            unsubscribe();
            resolve();
          }, PREFLIGHT_LEASE_RETRY_MS);
        });
        // The holder released the lease; re-claim it, or yield if this pick went stale.
        if (modelSelectionIntentEpoch !== loadIntentId) return;
      }
      if (lifecycleLease === null) {
        restorePreviousConfig();
        toast.info("A model is loading", {
          description: "Wait for it to finish or cancel it first.",
        });
        return;
      }
      loadLifecycleLeaseRef.current = lifecycleLease;
      const releasePreflightLifecycleLease = () => {
        if (loadLifecycleLeaseRef.current !== lifecycleLease) {
          return;
        }
        loadLifecycleLeaseRef.current = null;
        useChatRuntimeStore.getState().endModelLoading(lifecycleLease);
      };

      // Every chat decodes on the llama-server this load replaces, so ask first, then allow the
      // cancel; the 409 gate stays armed for callers that never confirmed.
      let stopDecision: Awaited<
        ReturnType<typeof confirmStopRunningChatsIfNeeded>
      >;
      try {
        stopDecision = await confirmStopRunningChatsIfNeeded(
          forceReload ? "Applying these settings" : "Loading a different model",
        );
      } catch (error) {
        releasePreflightLifecycleLease();
        throw error;
      }
      if (!stopDecision.proceed) {
        releasePreflightLifecycleLease();
        // The inherited target, not this pick's own previousConfig: when this pick superseded a
        // load that had already pre-applied its settings, that field holds the superseded target's
        // transient config, and declining here would leave the resident model wearing it.
        restorePreviousConfig();
        // No load will consume this rollback after a declined confirmation. If X
        // is still resident, a later pick must snapshot its current settings instead
        // of inheriting the config captured before this cancelled replacement.
        // Keep the target when A already unloaded X, or when a newer pick owns it.
        if (
          modelSelectionIntentEpoch === loadIntentId &&
          pendingReplacementRollback?.residentUnloaded === false
        ) {
          pendingReplacementRollback = null;
        }
        return;
      }
      // Re-check the tracked picker for a load that was already starting when this lifecycle lease was acquired.
      try {
        // A newer pick supersedes this preflight even though it could not claim the lease:
        // without this the stale load would start anyway and discard the user's newer choice.
        if (rivalLoadStarted() || modelSelectionIntentEpoch !== loadIntentId) {
          releasePreflightLifecycleLease();
          return;
        }
      } catch (error) {
        releasePreflightLifecycleLease();
        throw error;
      }
      const forceCancelActive = stopDecision.forceCancelActive;

      const explicitIsLora =
        typeof selection === "string" ? undefined : selection.isLora;
      const extraLoadingDescription =
        typeof selection === "string" ? undefined : selection.loadingDescription;
      const isDownloaded =
        typeof selection === "string" ? false : selection.isDownloaded ?? false;
      const model = models.find((entry) => entry.id === modelId);
      const lora = loras.find((entry) => entry.id === modelId);
      // A native path-token selection is a local GGUF by construction, but its id is a display label
      // that need not end in ".gguf": without this, Manual + Auto layers would pin the UI context
      // instead of letting --fit size it.
      const isGguf =
        explicitIsGguf ??
        (ggufVariant != null ||
          nativePathToken != null ||
          model?.isGguf === true);
      const loraIsAdapter = lora?.exportType === "lora";
      let isLora =
        explicitIsLora ?? model?.isLora ?? loraIsAdapter ?? false;
      const displayName = model?.name || lora?.name || modelId;
      const toastDisplayName = shortModelLabel(displayName);
      const currentRollbackState = useChatRuntimeStore.getState();
      const inheritedPendingRollback = pendingReplacementRollback;
      if (inheritedPendingRollback?.config) {
        previousConfigForReplacement = inheritedPendingRollback.config;
      }
      const currentCheckpoint = currentRollbackState.params.checkpoint;
      // A replacement rolls back to the model the cancelled load was replacing, not
      // to whatever the store holds mid-switch.
      const previousCheckpoint = inheritedPendingRollback
        ? inheritedPendingRollback.checkpoint
        : currentCheckpoint;
      // The cancelled run captured the variant before clearCheckpoint() dropped it from the store.
      const previousVariant = inheritedPendingRollback
        ? (inheritedPendingRollback.variant ?? null)
        : (currentRollbackState.activeGgufVariant ?? null);
      const reloadingSameModel =
        previousCheckpoint === modelId &&
        (ggufVariant ?? null) === (previousVariant ?? null);
      const previousModel = previousCheckpoint
        ? models.find((entry) => entry.id === previousCheckpoint)
        : undefined;
      const previousLora = previousCheckpoint
        ? loras.find((entry) => entry.id === previousCheckpoint)
        : undefined;
      const previousIsLora =
        previousModel?.isLora ?? (previousLora?.exportType === "lora");
      const isCachedLora = isLora && isLocal;
      let loadingDescription = [
        currentCheckpoint ? "Switching models." : null,
        extraLoadingDescription ?? null,
        isDownloaded ? "Loading cached model into memory." : null,
        !isDownloaded && isCachedLora ? "Loading trained model into memory." : null,
      ]
        .filter(Boolean)
        .join(" ");
      setModelsError(null);
      setLastModelLoadError(null); // clear prior failed-load marker
      setLoadToastDismissedState(false);
      const loadInfo = {
        id: modelId,
        displayName,
        isDownloaded,
        isCachedLora,
        ggufVariant: ggufVariant ?? null,
        nativePathToken: nativePathToken ?? null,
      };
      setLoadingModel(loadInfo);
      useChatRuntimeStore.getState().setLoadingModelPick(pickOf(loadInfo));
      setLoadProgress(
        isDownloaded || isCachedLora
          ? { percent: null, label: null, phase: "starting" }
          : { percent: 0, label: "Preparing download", phase: "downloading" },
      );
      loadingModelRef.current = loadInfo;
      const abortCtrl = new AbortController();
      loadAbortRef.current = abortCtrl;
      // Settlement is the last act of this run's coroutine: the resolver is assigned
      // synchronously here, so a cancel can await it even while the run is parked in an
      // unabortable preflight await.
      let markLoadRunSettled = () => {};
      const loadRunSettled = new Promise<void>((resolve) => {
        markLoadRunSettled = resolve;
      });
      // Claim the slot for this attempt. Every late callback below proves it still
      // owns the run before it touches shared loading state.
      const loadRun: ActiveModelLoadRun = {
        attemptId: loadIntentId,
        intentId: loadIntentId,
        abortController: abortCtrl,
        cancelPromise: null,
        rollbackCheckpoint: previousCheckpoint,
        rollbackConfig: previousConfigForReplacement,
        // Carried on the run, not read from the store later: clearCheckpoint() drops the store's
        // activeGgufVariant before a replacement can derive the prior model's variant.
        rollbackVariant: previousVariant,
        // Captured before clearCheckpoint can erase the working model's access identity.
        rollbackLoadId: inheritedPendingRollback
          ? inheritedPendingRollback.loadId ?? null
          : currentRollbackState.activeLoadId ?? null,
        rollbackNativePathToken: inheritedPendingRollback
          ? inheritedPendingRollback.nativePathToken ?? null
          : currentRollbackState.activeNativePathToken ?? null,
        rollbackNativePathExpiresAtMs: inheritedPendingRollback
          ? inheritedPendingRollback.nativePathExpiresAtMs ?? null
          : currentRollbackState.activeNativePathExpiresAtMs ?? null,
        rollbackLoadedState: inheritedPendingRollback?.loadedState ?? currentRollbackState,
        // An inherited rollback target whose model the cancelled run already unloaded: the backend
        // has nothing resident, so a failure below must restore it rather than find it still there.
        residentModelUnloaded: inheritedPendingRollback?.residentUnloaded === true,
        forceCancelActive,
        settledPromise: loadRunSettled,
        markSettled: markLoadRunSettled,

        requestId: crypto.randomUUID(),
        loadAttemptPath: null,
      };
      activeLoadRunRef.current = loadRun;
      // The winning intent reserved the slot, so the inherited rollback target is
      // no longer pending.
      pendingReplacementRollback = null;
      const postLoadRefresh = { needed: false };
      let progressModelIds = [modelId];
      let mlxLoadProgress = false;
      const liveBeforeLoad = useChatRuntimeStore.getState();
      // A switch without a saved config starts on the default engine, as the dedupe above assumes.
      if (
        (typeof selection === "string" || !selection.config) &&
        !keepSpeculative &&
        liveBeforeLoad.params.checkpoint &&
        (liveBeforeLoad.params.checkpoint !== modelId ||
          (liveBeforeLoad.activeGgufVariant ?? null) !== (ggufVariant ?? null)) &&
        (liveBeforeLoad.params.engine ?? "auto") !== "auto"
      ) {
        liveBeforeLoad.setParams({
          ...liveBeforeLoad.params,
          engine: "auto",
          enginePrecision: "auto",
          engineParallelism: "tensor",
        });
      }
      const requestedEngine =
        (typeof selection !== "string" ? selection.config?.engine : undefined) ??
        useChatRuntimeStore.getState().params.engine ?? "auto";
      const managedLoad = !isGguf && requestedEngine !== "auto";
      let downloadComplete = isDownloaded || isCachedLora || managedLoad;
      let cpuFallbackReason: CpuFallbackReason | null = null;
      let mmprojFallbackReason: MmprojFallbackReason | null = null;
      let offloadCounts: OffloadCounts = {};
      try {
        async function performLoad(): Promise<void> {
          if (abortCtrl.signal.aborted) throw new Error("Cancelled");
          // The cancelled run may already have unloaded the model this load rolls back to, and its
          // cancellation reconciled the store checkpoint to empty for exactly that case. Without
          // this the compensating reload below would be skipped and no model left resident.
          let previousWasUnloaded =
            inheritedPendingRollback?.residentUnloaded === true;
          const pendingLoadConfig =
            typeof selection !== "string" ? selection.config : undefined;
          // The outgoing model's slot INTENT (blank = follow the server default), which the resolved baseline
          // cannot express. previousConfig is the snapshot taken before pre-applying the target's config,
          // read before the staged-metadata await so a change cannot perturb it. Unlike tensorParallel,
          // vision does NOT survive a model switch: it is per-model config defaulting to vision on, so a
          // target that saved none gets that default. The dedupe above builds its own view of an
          // Every rollback read below uses the INHERITED target, never this pick's own
          // `selection.previousConfig`: when this pick superseded a load that had already
          // pre-applied its settings, that field holds the superseded target's transient config,
          // and a rollback would restore the resident model wearing the wrong model's settings.
          // `previousConfigForReplacement` already carries the resident model's own config.
          const rollbackConfig = previousConfigForReplacement;
          const previousNParallel =
            rollbackConfig
              ? (rollbackConfig.nParallel ?? null)
              : useChatRuntimeStore.getState().nParallel;
          const previousReasoningBudget =
            rollbackConfig
              ? rollbackConfig.reasoningBudget
              : useChatRuntimeStore.getState().reasoningBudget;
          const previousReasoningBudgetMessage =
            rollbackConfig
              ? rollbackConfig.reasoningBudgetMessage
              : useChatRuntimeStore.getState().reasoningBudgetMessage;
          const previousNBatch =
            rollbackConfig
              ? (rollbackConfig.nBatch ?? null)
              : useChatRuntimeStore.getState().nBatch;
          const previousNUbatch =
            rollbackConfig
              ? (rollbackConfig.nUbatch ?? null)
              : useChatRuntimeStore.getState().nUbatch;
          // The outgoing tuning intent, read the same way and for the same reason: a rollback restores the
          // control, not the echo.
          const previousServerTuning: ServerTuningValues =
            rollbackConfig ?? useChatRuntimeStore.getState();
          // Same reason: the rollback echo would overwrite an edit staged against it.
          const previousMlxKvQuant = rollbackConfig
            ? (rollbackConfig.mlxKvQuant ?? null)
            : useChatRuntimeStore.getState().mlxKvQuant;
          if (isGguf && isDiffusion === undefined) {
            // Prepare the token exactly as validateModel/loadModel do: the Hub rejects an invalid
            // Authorization header with 401 even for a public repo, so sending the raw stored token here would
            // abort the load before the "continue anonymously / replace token" recovery flow could run.
            isDiffusion = (
              await fetchGgufStagedMetadata({
                model_path: loadPath,
                gguf_variant: ggufVariant ?? null,
                hf_token: hfToken,
                nativePathToken: nativePathToken ?? null,
              })
            ).isDiffusion;
          }
          // The staged-metadata read cannot be aborted, so a replacement picked while it
          // was outstanding would otherwise have this load's config applied over it.
          if (abortCtrl.signal.aborted) throw new Error("Cancelled");
          const targetIsDiffusion = isDiffusion === true;
          if (pendingLoadConfig) {
            applyPerModelConfigToRuntime(pendingLoadConfig, {
              isDiffusion: targetIsDiffusion,
            });
          }
          const currentCheckpoint =
            useChatRuntimeStore.getState().params.checkpoint;
          const stateBeforeUnload = useChatRuntimeStore.getState();
          const rollbackState = inheritedPendingRollback?.loadedState ?? stateBeforeUnload;
          const platform = usePlatformStore.getState();
          let trustRemoteCode = stateBeforeUnload.params.trustRemoteCode ?? false;
          let approvedRemoteCodeFingerprint: string | null = null;
          // A staged config carries its pin; one that applied the saved record and then
          // selected carries none, so the pre-move field is where it survives.
          const pinnedMaxSeqLength = normalizeMaxSeqLength(
            pendingLoadConfig
              ? pendingLoadConfig.maxSeqLength
              : resolveInitialConfig(modelId, ggufVariant).config.maxSeqLength,
          );
          const maxSeqLength =
            pinnedMaxSeqLength ?? stateBeforeUnload.params.maxSeqLength;
          const previousActiveNativePathToken = inheritedPendingRollback
            ? inheritedPendingRollback.nativePathToken ?? null
            : stateBeforeUnload.activeNativePathToken;
          const previousActiveLoadId = inheritedPendingRollback
            ? inheritedPendingRollback.loadId ?? null
            : stateBeforeUnload.activeLoadId;
          const previousActiveNativePathExpiresAtMs = inheritedPendingRollback
            ? inheritedPendingRollback.nativePathExpiresAtMs ?? null
            : stateBeforeUnload.activeNativePathExpiresAtMs;
          const previousIsGguf =
            previousModel?.isGguf === true
            || previousVariant != null
            || previousActiveNativePathToken != null
            || (previousCheckpoint?.toLowerCase().endsWith(".gguf") ?? false);
          // Roll back to the previous model's own context: previousConfig was snapshotted before this load
          // pre-applied the next model's config, so params.maxSeqLength may already be the next model's.
          const previousMaxSeqLength =
            previousConfigForReplacement?.maxSeqLength ?? maxSeqLength;
          // The intent the model had, not the length it ended up at: sending the resolved length would pin a
          // model nobody pinned. The resident backend's own answer, so a native-audio checkpoint the worker
          // served off the MLX path does not roll back at the sentinel.
          const previousIsMlx = residentIsServedByMlx(
            previousIsGguf,
            platform.deviceType,
            platform.chatOnlyReason,
            rollbackState.loadedIsMlx,
          );
          // What the outgoing model loaded with, not the control's value: a pin typed
          // and never applied would change a window the failed switch never touched.
          const previousPin = rollbackState.loadedCustomContextLength;
          // It reloads at the pin it loaded with, whichever backend served it; only
          // llama.cpp's placement rules override that, where they own sizing.
          const rollbackMaxSeqLength = previousIsGguf
            ? resolveFitMaxSeqLength(
                previousIsGguf,
                rollbackState.loadedGpuMemoryMode ?? "auto",
                rollbackState.loadedGpuLayers ?? GPU_LAYERS_AUTO,
                rollbackState.loadedCustomContextLength,
                rollbackState.loadedContextLength ?? 0,
              )
            : (previousPin ??
              unpinnedLoadContext(false, previousIsMlx, previousMaxSeqLength));
          // main's `const hfToken = stateBeforeUnload.hfToken` is deliberately not carried over: this branch
          // prepares the credential once in the enclosing scope, and re-reading the raw stored token here
          // would shadow it and undo the preparation for every load below.
          const previousModelRequiresTrustRemoteCode =
            stateBeforeUnload.modelRequiresTrustRemoteCode;
          // Snapshot the load settings at click time, before the awaits below. When the picker staged a
          // config payload, prefer it over the store: React may not have flushed NumericValueInput's
          // blur commit yet. Per-model, since a template is written against one model's tokens.
          let loadChatTemplateOverride =
            pendingLoadConfig?.chatTemplateOverride?.trim()
              ? pendingLoadConfig.chatTemplateOverride
              : stateBeforeUnload.chatTemplateOverride;
          const loadKvCacheDtype =
            pendingLoadConfig?.kvCacheDtype ?? stateBeforeUnload.kvCacheDtype;
          // Per-model, not a standing preference: eligibility is decided per model.
          let loadMlxKvQuant =
            pendingLoadConfig
              ? pendingLoadConfig.mlxKvQuant ?? null
              : stateBeforeUnload.mlxKvQuant;
          // gpuMemoryMode is a standing preference; the rest are per-model knobs the reset below clears, so
          // they are re-baselined there in lock-step with the store. A GGUF native context can exceed
          // maxSeqLength, so sizing on raw maxSeqLength could pass, unload, then have /load refuse it. A
          // same-repo quant switch is a different model for per-model knobs, so re-baseline them.
          let loadCustomContextLength =
            pendingLoadConfig?.customContextLength ??
            stateBeforeUnload.customContextLength;
          const loadContextLength = stateBeforeUnload.loadedContextLength;
          const loadTensorParallel = targetIsDiffusion
            ? false
            : (pendingLoadConfig?.tensorParallel ??
              stateBeforeUnload.tensorParallel);
          // The diffusion runner has no projector to skip, so the toggle is inert there. Unlike
          // tensorParallel this does NOT survive a model switch: it is per-model config defaulting to vision
          // on, and carrying it over loaded the new model text-only and silently, because the dedupe
          // comparison builds its own view of an unconfigured switch.
          const loadSwitchesModelOrVariant = Boolean(
            currentCheckpoint &&
              (currentCheckpoint !== modelId ||
                (stateBeforeUnload.activeGgufVariant ?? null) !==
                  (ggufVariant ?? null)) &&
              !keepSpeculative,
          );
          const loadDisableVision = targetIsDiffusion
            ? false
            : (pendingLoadConfig?.disableVision ??
              (loadSwitchesModelOrVariant
                ? DEFAULT_PER_MODEL_CONFIG.disableVision
                : stateBeforeUnload.disableVision));
          const loadActivePresetSource = stateBeforeUnload.activePresetSource;
          const loadActiveGgufVariant = stateBeforeUnload.activeGgufVariant;
          const loadGpuMemoryMode =
            pendingLoadConfig?.gpuMemoryMode ?? stateBeforeUnload.gpuMemoryMode;
          let loadGpuLayers =
            pendingLoadConfig?.gpuLayers ?? stateBeforeUnload.gpuLayers;
          let loadNCpuMoe =
            pendingLoadConfig?.nCpuMoe ?? stateBeforeUnload.nCpuMoe;
          let loadSplitRatio =
            pendingLoadConfig?.tensorSplit !== undefined
              ? pendingLoadConfig.tensorSplit
              : stateBeforeUnload.splitRatio;
          // Reconcile the persisted pick against the GPUs present now, so a stale cross-host pick is
          // dropped before /load rather than rejected there. Warm the device cache first: a cold cache
          // would pass the pick through unvalidated.
          if (
            pendingLoadConfig?.selectedGpuIds !== undefined ||
            stateBeforeUnload.selectedGpuIds != null
          ) {
            await ensureGpuDeviceCache();
          }
          const stagedGpuIds =
            pendingLoadConfig?.selectedGpuIds !== undefined
              ? reconcilePersistedGpuIds(
                  pendingLoadConfig.selectedGpuIds,
                  pendingLoadConfig.selectedGpuIndexKind,
                  targetIsDiffusion,
                )
              : null;
          let loadSelectedGpuIds =
            pendingLoadConfig?.selectedGpuIds !== undefined
              ? stagedGpuIds
              : reconcilePersistedGpuIds(
                  stateBeforeUnload.selectedGpuIds,
                  stateBeforeUnload.selectedGpuIndexKind,
                  targetIsDiffusion,
                );
          let loadSpeculativeType =
            pendingLoadConfig?.speculativeType != null
              ? normalizeSpeculativeType(pendingLoadConfig.speculativeType)
              : stateBeforeUnload.speculativeType;
          let loadSpecDraftNMax =
            pendingLoadConfig?.specDraftNMax ?? stateBeforeUnload.specDraftNMax;
          let loadNParallel =
            pendingLoadConfig?.nParallel ?? stateBeforeUnload.nParallel;
          let loadReasoningBudget =
            pendingLoadConfig?.reasoningBudget ??
            stateBeforeUnload.reasoningBudget;
          let loadReasoningBudgetMessage =
            pendingLoadConfig?.reasoningBudgetMessage ??
            stateBeforeUnload.reasoningBudgetMessage;
          // No store fallback and no reset with the rest below: undefined means "this config never read
          // them", and the route preserves the stored flags when the field is omitted, so a fallback
          // would clear flags the user set elsewhere.
          const loadLlamaExtraArgs = pendingLoadConfig?.llamaExtraArgs;
          const loadLlamaCppConfig =
            pendingLoadConfig?.llamaCppConfig ??
            (currentCheckpoint === modelId &&
            previousVariant === (ggufVariant ?? null)
              ? stateBeforeUnload.llamaCppConfig
              : undefined);
          let loadNBatch =
            pendingLoadConfig?.nBatch ?? stateBeforeUnload.nBatch;
          let loadNUbatch =
            pendingLoadConfig?.nUbatch ?? stateBeforeUnload.nUbatch;
          let loadServerTuning: ServerTuningValues = {
            loadMode: pendingLoadConfig?.loadMode ?? stateBeforeUnload.loadMode,
            specDraftCacheDtype:
              pendingLoadConfig?.specDraftCacheDtype ??
              stateBeforeUnload.specDraftCacheDtype,
            ctxCheckpoints:
              pendingLoadConfig?.ctxCheckpoints ??
              stateBeforeUnload.ctxCheckpoints,
            cacheRam: pendingLoadConfig?.cacheRam ?? stateBeforeUnload.cacheRam,
          };
          try {
            // Lightweight pre-flight validation: avoid unloading a working model if the new identifier is
            // clearly invalid.
            const validateNativePathLease = nativePathToken
              ? (await consumeNativePathToken(nativePathToken, "validate-model")).nativePathLease
              : undefined;
            // Validate with the same effective context /load uses: a GGUF native context can exceed
            // maxSeqLength, so sizing on raw maxSeqLength could pass, unload, then have /load refuse it. Mirror
            // /load on a cross-model switch, treating a same-repo quant switch as a different model.
            const switchingModelOrVariant =
              currentCheckpoint !== modelId ||
              (loadActiveGgufVariant ?? null) !== (ggufVariant ?? null);
            const resetsPerModelSettings = Boolean(
              currentCheckpoint && switchingModelOrVariant && !keepSpeculative,
            );
            const validateCustomContextLength = resetsPerModelSettings
              ? null
              : loadCustomContextLength;
            const validateGpuIds = resetsPerModelSettings
              ? stagedGpuIds
              : loadSelectedGpuIds;
            // The reset below re-baselines gpuLayers to Auto; mirror it here.
            const validateGpuLayers = resetsPerModelSettings
              ? GPU_LAYERS_AUTO
              : loadGpuLayers;
            // Per-model: the reset re-baselines to the staged config, like the load.
            const validateNParallel = resetsPerModelSettings
              ? (pendingLoadConfig?.nParallel ?? null)
              : loadNParallel;
            const validateReasoningBudget = resetsPerModelSettings
              ? (pendingLoadConfig?.reasoningBudget ?? -1)
              : loadReasoningBudget;
            const validateReasoningBudgetMessage = resetsPerModelSettings
              ? (pendingLoadConfig?.reasoningBudgetMessage ?? "")
              : loadReasoningBudgetMessage;
            const validateNBatch = resetsPerModelSettings
              ? (pendingLoadConfig?.nBatch ?? null)
              : loadNBatch;
            const validateNUbatch = resetsPerModelSettings
              ? (pendingLoadConfig?.nUbatch ?? null)
              : loadNUbatch;
            const validateServerTuning: ServerTuningValues =
              resetsPerModelSettings
                ? {
                    loadMode: pendingLoadConfig?.loadMode ?? null,
                    specDraftCacheDtype:
                      pendingLoadConfig?.specDraftCacheDtype ?? null,
                    ctxCheckpoints: pendingLoadConfig?.ctxCheckpoints ?? null,
                    cacheRam: pendingLoadConfig?.cacheRam ?? null,
                  }
                : loadServerTuning;
            const validateMaxSeqLength = resolveFitMaxSeqLength(
              isGguf,
              loadGpuMemoryMode,
              validateGpuLayers,
              validateCustomContextLength,
              resolveLoadMaxSeqLength({
                modelId,
                ggufVariant,
                isGguf,
                customContextLength: validateCustomContextLength,
                loadedContextLength: loadContextLength,
                currentCheckpoint,
                activeGgufVariant: loadActiveGgufVariant,
                isMlx: isServedByMlx(isGguf, platform.deviceType, platform.chatOnlyReason),
                pinnedMaxSeqLength,
                defaultMaxSeqLength: unpinnedDefaultRequest(
                  previousIsMlx,
                  stateBeforeUnload.params.maxSeqLength,
                  DEFAULT_MAX_SEQ_LENGTH,
                ),
                presetSource: loadActivePresetSource,
              }),
            );
            const validation = await validateModel({
              model_path: loadPath,
              engine_precision: stateBeforeUnload.params.enginePrecision ?? "auto",
              engine_parallelism: stateBeforeUnload.params.engineParallelism ?? "tensor",
              engine: isGguf ? "auto" : (stateBeforeUnload.params.engine ?? "auto"),
              nativePathLease: validateNativePathLease,
              hf_token: hfToken,
              max_seq_length: validateMaxSeqLength,
              load_in_4bit: (stateBeforeUnload.params.engine ?? "auto") === "auto",
              is_lora: isLora,
              gguf_variant: ggufVariant ?? null,
              cache_type_kv: loadKvCacheDtype,
              tensor_parallel: loadTensorParallel,
              disable_vision: loadDisableVision,
              gpu_ids: validateGpuIds ?? undefined,
              ...(isGguf
                ? {
                    gpu_memory_mode: loadGpuMemoryMode,
                    // Sized like the follow-up /load: else a manual DiffusionGemma split 409s during training even
                    // when it fits.
                    gpu_layers: validateGpuLayers,
                    n_parallel: validateNParallel,
                    reasoning_budget: targetIsDiffusion
                      ? -1
                      : validateReasoningBudget,
                    reasoning_budget_message: targetIsDiffusion
                      ? ""
                      : validateReasoningBudgetMessage,
                    // omitted when blank, like the load payload below
                    ...(validateNBatch != null
                      ? { n_batch: validateNBatch }
                      : {}),
                    ...(validateNUbatch != null
                      ? { n_ubatch: validateNUbatch }
                      : {}),
                    // Same omit-when-blank rule, and the same values: the preflight has to approve the command the
                    // follow-up /load sends.
                    ...serverTuningLoadPayload(validateServerTuning),
                    // The same list the load below sends: a --ctx-size or cache override changes the memory this
                    // preflight estimates, so omitting it approves a different command and /load then refuses
                    // the target with the real arguments.
                    ...llamaCppConfigPayload(loadLlamaCppConfig, {
                      isDiffusion: targetIsDiffusion,
                    }),
                    ...(!targetIsDiffusion && loadLlamaExtraArgs !== undefined
                      ? { llama_extra_args: loadLlamaExtraArgs ?? [] }
                      : {}),
                  }
                : {}),
            });
            isLora = validation.is_lora ?? isLora;
            // validateModel cannot be aborted either, and everything below writes shared
            // state, so stop here if a replacement superseded this load meanwhile.
            if (abortCtrl.signal.aborted) throw new Error("Cancelled");
            if (validation.mlx_loads_base_model) {
              mlxLoadProgress = true;
              const mlxBaseDescription = isLora
                ? `Loading the adapter with ${validation.mlx_loads_base_model} in place of its bitsandbytes base, downloading it first if needed.`
                : `Loading ${validation.mlx_loads_base_model} instead, downloading it first if needed.`;
              progressModelIds = isLora && !isLocal
                ? [modelId, validation.mlx_loads_base_model]
                : [validation.mlx_loads_base_model];
              downloadComplete = false;
              loadingDescription = [
                currentCheckpoint ? "Switching models." : null,
                extraLoadingDescription ?? null,
                mlxBaseDescription,
              ]
                .filter(Boolean)
                .join(" ");
              setLoadProgress({
                percent: 0,
                label: "Preparing download",
                phase: "downloading",
              });
              toast.info("MLX cannot use 4-bit bitsandbytes weights", {
                description: mlxBaseDescription,
              });
            }
            // Upgrade consent runs before the security dialogs; Accept installs and the load continues.
            if (validation.requires_transformers_upgrade) {
              const upgraded = await confirmTransformersUpgradeIfNeeded({
                modelName: modelId,
                upgrade: validation.transformers_upgrade,
                // No installable release: custom-code models may fall back to the trust_remote_code gate below.
                trustRemoteCodeFallback: validation.requires_trust_remote_code,
                // The install refuses while chats generate and takes no force flag of its own, so without this
                // the "Stop and reload" the user just confirmed dies here and Retry hits the same 409.
                forceCancelActive,
              });
              // The install unloads the previous model before the swap even when the swap fails, so any exit
              // after this point must roll back. False for the custom-code fallback, which installs nothing.
              if (
                useTransformersUpgradeDialogStore
                  .getState()
                  .consumeServerUnloadedChat()
                && currentCheckpoint
              ) {
                // The installer may unload the prior resident independently of the ordinary
                // preliminary unload. Cancellation uses the run-level marker to clear its stale
                // checkpoint and transfer the unloaded state to the replacement.
                loadRun.residentModelUnloaded = true;
                previousWasUnloaded = true;
              }
              if (!upgraded) {
                throw new Error(getTransformersUpgradeRequiredMessage(displayName));
              }
            }
            if (abortCtrl.signal.aborted) throw new Error("Cancelled");
            // Open the consent dialog when the model needs custom-code consent or has a flagged unsafe file.
            // Fires even when trustRemoteCode is preset on, since the worker requires a matching
            // fingerprint only the dialog produces.
            if (
              validation.requires_trust_remote_code
              || validation.requires_security_review
            ) {
              const approved = await confirmRemoteCodeIfNeeded({
                modelName: modelId,
                hfToken,
                requiresTrustRemoteCode: true,
                onApprove: (fp) => {
                  trustRemoteCode = true;
                  approvedRemoteCodeFingerprint = fp;
                },
              });
              if (!approved) {
                throw new Error(getTrustRemoteCodeRequiredMessage(displayName));
              }
            }
            if (abortCtrl.signal.aborted) throw new Error("Cancelled");
            const loadNativePathLease = nativePathToken
              ? (await consumeNativePathToken(nativePathToken, "load-model")).nativePathLease
              : undefined;

            cancelPreStreamRunReservations(stopDecision.preStreamRunTokens);
            requestLocalPromptQueueStop(stopDecision.promptQueueThreadIds);
            if (currentCheckpoint) {
              // With chats generating, skip this preliminary unload: it cancels them ahead of /load's
              // preflight, so a rejected target truncates replies for a model that never loads. Idle,
              // unload first and free VRAM early.
              if (!forceCancelActive) {
                if (loadLlamaCppConfig?.mode !== "custom") {
                  await unloadModel({ model_path: currentCheckpoint });
                  // Custom mode leaves replacement to /load, which preflights before evicting.
                  loadRun.residentModelUnloaded = true;
                }
              }
              // Set either way: /load can still leave no model resident, and an unneeded rollback hits
              // already_loaded before the gate.
              previousWasUnloaded = true;
            }
            if (abortCtrl.signal.aborted) throw new Error("Cancelled");

            // On a model switch, fall back to the persisted standing preference rather than null so a
            // per-session forced MTP mode cannot follow the user onto a model without an MTP head.
            // spec_draft_n_max is MTP-only and always resets, and the loaded shadow is seeded to prevent a
            // transient dirty Apply. keepSpeculative skips this for a staged Load.
            if (resetsPerModelSettings) {
              const persistedSpeculativeType = readPersistedSpeculativeType();
              useChatRuntimeStore.setState({
                speculativeType: persistedSpeculativeType,
                loadedSpeculativeType: persistedSpeculativeType,
                specDraftNMax: null,
                loadedSpecDraftNMax: null,
                // Per-model too: a different model follows the server default unless its staged config overrides it.
                nParallel: null,
                loadedNParallel: null,
                reasoningBudget: -1,
                loadedReasoningBudget: null,
                loadedReasoningBudgetRequested: null,
                reasoningBudgetMessage: "",
                loadedReasoningBudgetMessage: null,
                loadedReasoningBudgetMessageRequested: null,
                nBatch: null,
                loadedNBatch: null,
                nUbatch: null,
                loadedNUbatch: null,
                // Per-model too, and cleared in both halves: a baseline left from the model that just went would
                // be re-sent by a later rollback.
                ...clearedServerTuningState(),
                // Per-model GPU knobs must not follow onto a different model (gpuMemoryMode is standing and is kept).
                selectedGpuIds: null,
                selectedGpuIndexKind: null,
                gpuLayers: GPU_LAYERS_AUTO,
                nCpuMoe: 0,
                splitRatio: null,
                // A Manual+Auto context pin is per-model; clear it so a different model loads at Auto/native.
                customContextLength: null,
              });
              loadSpeculativeType =
                pendingLoadConfig?.speculativeType != null
                  ? normalizeSpeculativeType(pendingLoadConfig.speculativeType)
                  : persistedSpeculativeType;
              loadSpecDraftNMax = pendingLoadConfig?.specDraftNMax ?? null;
              loadNParallel = pendingLoadConfig?.nParallel ?? null;
              loadReasoningBudget = pendingLoadConfig?.reasoningBudget ?? -1;
              loadReasoningBudgetMessage =
                pendingLoadConfig?.reasoningBudgetMessage ?? "";
              loadNBatch = pendingLoadConfig?.nBatch ?? null;
              loadNUbatch = pendingLoadConfig?.nUbatch ?? null;
              loadServerTuning = {
                loadMode: pendingLoadConfig?.loadMode ?? null,
                specDraftCacheDtype:
                  pendingLoadConfig?.specDraftCacheDtype ?? null,
                ctxCheckpoints: pendingLoadConfig?.ctxCheckpoints ?? null,
                cacheRam: pendingLoadConfig?.cacheRam ?? null,
              };
              loadMlxKvQuant = pendingLoadConfig?.mlxKvQuant ?? null;
              loadChatTemplateOverride =
                pendingLoadConfig?.chatTemplateOverride?.trim()
                  ? pendingLoadConfig.chatTemplateOverride
                  : null;
              // Keep the click-time snapshot in lock-step with the store reset so the load sizes against the
              // cleared per-model knobs. An explicit staged config from run-settings still wins.
              loadCustomContextLength =
                pendingLoadConfig?.customContextLength ?? null;
              loadSelectedGpuIds = stagedGpuIds;
              loadGpuLayers = pendingLoadConfig?.gpuLayers ?? GPU_LAYERS_AUTO;
              loadNCpuMoe = pendingLoadConfig?.nCpuMoe ?? 0;
              loadSplitRatio = pendingLoadConfig?.tensorSplit ?? null;
            }

            // The Context Length the USER set for this load, captured before the clamp below can stand in for
            // it. This, not the n_ctx that goes on the wire, is what the completed load pins: several send
            // rules put a positive n_ctx on the wire with the control on Auto.
            const targetIsMlx = isServedByMlx(
              isGguf,
              platform.deviceType,
              platform.chatOnlyReason,
            );
            const explicitCtxPin = loadRequestContextPin(
              loadCustomContextLength,
              targetIsMlx,
              pinnedMaxSeqLength,
            );
            // Pinning layers on the SAME model keeps the currently resolved context: with no explicit pin, a
            // manual+pinned reload would send 0, which the backend's --fit off branch treats as the NATIVE
            // context, far larger than the sheet shows when the load was fit-sized, a likely OOM.
            // loadedContextLength is that resolved value; a model already at native reloads unchanged.
            if (
              isGguf &&
              !switchingModelOrVariant &&
              loadGpuMemoryMode === "manual" &&
              loadGpuLayers >= 0 &&
              loadCustomContextLength == null &&
              (loadContextLength ?? 0) > 0
            ) {
              loadCustomContextLength = loadContextLength;
            }
            const effectiveMaxSeqLength = resolveLoadMaxSeqLength({
              modelId,
              ggufVariant,
              isGguf,
              customContextLength: loadCustomContextLength,
              loadedContextLength: loadContextLength,
              currentCheckpoint,
              activeGgufVariant: loadActiveGgufVariant,
              isMlx: targetIsMlx,
              pinnedMaxSeqLength,
              defaultMaxSeqLength: unpinnedDefaultRequest(
                  previousIsMlx,
                  stateBeforeUnload.params.maxSeqLength,
                  DEFAULT_MAX_SEQ_LENGTH,
                ),
              presetSource: loadActivePresetSource,
            });
            const loadMaxSeqLength = resolveFitMaxSeqLength(
              isGguf,
              loadGpuMemoryMode,
              loadGpuLayers,
              loadCustomContextLength,
              effectiveMaxSeqLength,
            );
            const effectiveChatTemplateOverride =
              loadChatTemplateOverride?.trim() ? loadChatTemplateOverride : null;
            // Invalidate factories started before the final loading boundary.
            requestLocalPromptQueueStop();
            if (lifecycleLease !== null) {
              chatModelLifecycleGate.markLoading(lifecycleLease);
            }
            // Bind this attempt to its request ID before the POST, so a cancel that
            // arrives first lands as a backend tombstone the load replays against.
            loadRun.loadAttemptPath = loadPath;

            const loadResponse = await loadModel({
              model_path: loadPath,
              engine_precision: stateBeforeUnload.params.enginePrecision ?? "auto",
              engine_parallelism: stateBeforeUnload.params.engineParallelism ?? "tensor",
              engine: isGguf ? "auto" : (stateBeforeUnload.params.engine ?? "auto"),
              load_request_id: loadRun.requestId,
              nativePathLease: loadNativePathLease,
              hf_token: hfToken,
              max_seq_length: loadMaxSeqLength,
              max_seq_length_auto_derived: isReplayedLoadContext(
                isGguf,
                loadCustomContextLength,
                loadMaxSeqLength,
              ),
              load_in_4bit: (stateBeforeUnload.params.engine ?? "auto") === "auto",
              is_lora: isLora,
              gguf_variant: ggufVariant ?? null,
              trust_remote_code: trustRemoteCode,
              approved_remote_code_fingerprint: approvedRemoteCodeFingerprint,
              chat_template_override: effectiveChatTemplateOverride,
              cache_type_kv: loadKvCacheDtype,
              mlx_kv_quant: loadMlxKvQuant ?? null,
              speculative_type: loadSpeculativeType,
              spec_draft_n_max: loadSpecDraftNMax,
              n_parallel: loadNParallel,
              reasoning_budget:
                isGguf && !targetIsDiffusion ? loadReasoningBudget : -1,
              reasoning_budget_message:
                isGguf && !targetIsDiffusion ? loadReasoningBudgetMessage : "",
              // Sent only once known, and [] is the explicit "launch with none": the flags are llama-server's,
              // so neither a transformers load nor a diffusion GGUF carries them.
              ...(isGguf
                ? llamaCppConfigPayload(loadLlamaCppConfig, {
                    isDiffusion: targetIsDiffusion,
                  })
                : {}),
              ...(isGguf && !targetIsDiffusion && loadLlamaExtraArgs !== undefined
                ? { llama_extra_args: loadLlamaExtraArgs ?? [] }
                : {}),
              // omitted when blank: a null counts as set and strips inherited -b / -ub
              ...(isGguf && loadNBatch != null ? { n_batch: loadNBatch } : {}),
              ...(isGguf && loadNUbatch != null
                ? { n_ubatch: loadNUbatch }
                : {}),
              // llama-server's own, so gated like the extras above: GGUF, and not the diffusion runner.
              ...(isGguf && !targetIsDiffusion
                ? serverTuningLoadPayload(loadServerTuning)
                : {}),
              tensor_parallel: loadTensorParallel,
              disable_vision: loadDisableVision,
              gpu_memory_mode: loadGpuMemoryMode,
              gpu_layers: loadGpuLayers,
              n_cpu_moe: loadNCpuMoe,
              tensor_split: loadSplitRatio ?? undefined,
              gpu_ids: loadSelectedGpuIds ?? undefined,
              force_cancel_active: forceCancelActive,

              force_reload: forceReload,
            });
            cpuFallbackReason = loadResponse.cpu_fallback_reason ?? null;
            mmprojFallbackReason = loadResponse.mmproj_fallback_reason ?? null;
            offloadCounts = offloadCountsFrom(loadResponse);

            // If cancelled while loading, do not show the model as active: it is being unloaded.
            if (abortCtrl.signal.aborted) throw new Error("Cancelled");

            // The load applied this spec mode, so persist the user's standing preference now: the requested
            // intent, not the resolved echo, since saveSpeculativeType keeps only the universal auto/ngram/off.
            // Skipped for a per-model config (keepSpeculative), whose choice must not overwrite the global.
            if (!keepSpeculative) {
              saveSpeculativeType(loadSpeculativeType);
            }
            // Persist the GPU Memory mode only on a successful load, so an abandoned selection does not stick.
            persistGpuMemoryModeOnLoad(loadResponse, loadGpuMemoryMode);

            const currentParams = useChatRuntimeStore.getState().params;
            const loadedFields = loadedContextFields(loadResponse);
            // The reported window, or where nothing sized one the requested length: the request answers only
            // for a backend that sizes nothing, a self-sizing one having been sent the sentinel.
            const loadedContextCap = replayMaxTokensCap(
              loadedFields.loadedContextLength ??
                (!loadResponse.is_gguf && effectiveMaxSeqLength > 0
                  ? effectiveMaxSeqLength
                  : null),
            );
            setParams(
              {
                ...mergeBackendRecommendedInference({
                  current: currentParams,
                  response: loadResponse,
                  modelId,
                  presetSource: useChatRuntimeStore.getState().activePresetSource,
                  loadedContextLength: loadedFields.loadedContextLength,
                }),
                // The served window, as background and compare loads already record,
                // or the active model reports a context it is not running at.
                ...(isGguf
                  ? {}
                  : {
                      maxSeqLength: loadedContextForParams(
                        loadedFields.loadedContextLength,
                        loadMaxSeqLength,
                        currentParams.maxSeqLength,
                      ),
                    }),
              },
              // Lay this model's remembered settings back over its defaults,
              // but not a budget larger than the context it just loaded with.
              {
                fromModelDefaults: true,
                maxTokensCap: loadedContextCap,
              },
            );
            // Qwen3.5/3.6 small models (0.8B, 2B, 4B, 9B) disable thinking by default. Anchored regex:
            // first "Xb" / "X.Xb" after start-of-string or [-_/.] so the version literal in "qwen3.5" /
            // "qwen3.6" does not match first, and "Qwen3.5-35B-A3B" yields 35 (total), not 3 (MoE active).
            let reasoningDefault = loadResponse.supports_reasoning ?? false;
            if (reasoningDefault) {
              const mid = modelId.toLowerCase();
              if (mid.includes("qwen3.5") || mid.includes("qwen3.6")) {
                // Scan path segments right to left so the size nearest the leaf wins; the trailing boundary
                // stops "8bit".
                const sizeRe = /(?:^|[-_.])(\d+\.?\d*)\s*([bm])(?:$|[-_.])/;
                const sizeMatch = mid
                  .replace(/\\/g, "/")
                  .split("/")
                  .reduceRight<RegExpMatchArray | null>(
                    (found, seg) => found ?? seg.match(sizeRe),
                    null,
                  );
                if (sizeMatch) {
                  const size = parseFloat(sizeMatch[1]);
                  const sizeB = sizeMatch[2] === "m" ? size / 1000 : size;
                  if (sizeB <= 9) reasoningDefault = false;
                }
              }
            }
            const loadedTp = loadResponse.tensor_parallel ?? false;
            const committedSlots =
              ((loadResponse.is_gguf ?? false) && !(loadResponse.is_diffusion ?? false)) ||
              (loadResponse.is_mlx ?? false)
                ? (loadNParallel ?? null)
                : null;
            // same rule for the batch sizes: gguf-only llama-server flags
            const committedNBatch =
              (loadResponse.is_gguf ?? false) &&
              !(loadResponse.is_diffusion ?? false)
                ? (loadNBatch ?? null)
                : null;
            const committedNUbatch =
              (loadResponse.is_gguf ?? false) &&
              !(loadResponse.is_diffusion ?? false)
                ? (loadNUbatch ?? null)
                : null;
            const committedServerTuning =
              (loadResponse.is_gguf ?? false) &&
              !(loadResponse.is_diffusion ?? false)
                ? committedServerTuningState(loadServerTuning)
                : clearedServerTuningState();
            // The user's own Context Length (see explicitCtxPin), so an Auto load
            // stays Auto whatever n_ctx the send rules resolved for it. MLX pins the
            // same way, so it is admitted here rather than cleared as a non-GGUF.
            const keepCustomCtx = resolveExplicitCtxPin(
              loadResponse.is_gguf || targetIsMlx ? explicitCtxPin : null,
            );
            const reasoningAlwaysOn = loadResponse.reasoning_always_on ?? false;
            const reasoningStyle = loadResponse.reasoning_style ?? "enable_thinking";
            const supportsReasoning = loadResponse.supports_reasoning ?? false;
            const supportsPreserveThinking =
              loadResponse.supports_preserve_thinking ?? false;
            const supportsTools = loadResponse.supports_tools ?? false;
            // GLM-5.2-style models report their own effort levels (high|max); everything else keeps the
            // default low/medium/high.
            const reasoningEffortLevels =
              loadResponse.reasoning_effort_levels &&
              loadResponse.reasoning_effort_levels.length > 0
                ? (loadResponse.reasoning_effort_levels as ReasoningEffort[])
                : (["low", "medium", "high"] as const);
            // The chat's own level when the model this replaces was running a pin's, for the
            // reason applyActiveModelStatusToStore gives at its own clamp: a pin is one model's,
            // and everything between the pick and this response can abort without loading.
            const existingReasoningEffort =
              (pinHoldsLiveEffort() ? takeEffortDisplacedByPin() : null) ??
              useChatRuntimeStore.getState().reasoningEffort;
            const clampedReasoningEffort =
              reasoningStyle === "enable_thinking_effort" ||
              reasoningStyle === "reasoning_effort"
                ? clampReasoningEffortToLevels(
                    existingReasoningEffort,
                    reasoningEffortLevels,
                  )
                : clampLocalReasoningEffort(existingReasoningEffort);
            const nextReasoningEnabled = reasoningAlwaysOn
              ? true
              : reloadingSameModel && supportsReasoning
                ? stateBeforeUnload.reasoningEnabled
                : reasoningDefault;
            rememberApprovedRemoteCode(modelId, approvedRemoteCodeFingerprint);
            // A later rollback reads the snapshot path, not the id this was stored under.
            rememberApprovedRemoteCode(loadPath, approvedRemoteCodeFingerprint);
            useChatRuntimeStore.setState({
              ...loadedContextFields(loadResponse),
              modelRequiresTrustRemoteCode:
                loadResponse.requires_trust_remote_code ?? false,
              supportsReasoning,
              reasoningAlwaysOn,
              reasoningEnabled: nextReasoningEnabled,
              reasoningStyle,
              supportsReasoningOff: reasoningStyle !== "reasoning_effort",
              reasoningEffortLevels,
              reasoningEffort: clampedReasoningEffort,
              supportsPreserveThinking,
              preserveThinking:
                reloadingSameModel && supportsPreserveThinking
                  ? stateBeforeUnload.preserveThinking
                  : resolvePreserveThinkingOnLoad(loadResponse),
              supportsTools,
              ...(reloadingSameModel && supportsTools
                ? {
                    toolsEnabled: stateBeforeUnload.toolsEnabled,
                    codeToolsEnabled: stateBeforeUnload.codeToolsEnabled,
                  }
                : resolveToolsEnabledOnLoad(supportsTools)),
              ...managedKvCacheFields(loadResponse),
              ...mlxRuntimeStateFrom(loadResponse),
              tensorParallel: loadedTp,
              loadedTensorParallel: loadedTp,
              loadedDisableVision: loadResponse.disable_vision ?? false,
              // Repaired from the echo like the knob above: loadDisableVision forces the flag off for a
              // diffusion target without writing the store, so a Vision-off GGUF followed by a diffusion
              // load would leave the switch off over a load that never sent it.
              disableVision: loadResponse.disable_vision ?? false,
              // Set alongside loadedIsMultimodal so the composer can say WHY images are unavailable.
              loadedVisionDisabledByUser:
                loadResponse.vision_disabled_by_user ?? false,
              ...managedGpuMemoryFields(loadResponse),
              ...managedSpeculativeSettings(loadResponse),
              // Keep the click-time value: the echo is the resolved count, and adopting it would pin a blank
              // "server default" control.
              nParallel: committedSlots,
              loadedNParallel: committedSlots,
              reasoningBudget:
                (loadResponse.is_gguf ?? false) &&
                !(loadResponse.is_diffusion ?? false)
                  ? (loadResponse.reasoning_budget ?? loadReasoningBudget)
                  : -1,
              loadedReasoningBudget:
                (loadResponse.is_gguf ?? false) &&
                !(loadResponse.is_diffusion ?? false)
                  ? (loadResponse.reasoning_budget ?? loadReasoningBudget)
                  : -1,
              reasoningBudgetMessage:
                (loadResponse.is_gguf ?? false) &&
                !(loadResponse.is_diffusion ?? false)
                  ? (loadResponse.reasoning_budget_message ??
                    loadReasoningBudgetMessage)
                  : "",
              loadedReasoningBudgetMessage:
                (loadResponse.is_gguf ?? false) &&
                !(loadResponse.is_diffusion ?? false)
                  ? (loadResponse.reasoning_budget_message ??
                    loadReasoningBudgetMessage)
                  : "",
              loadedReasoningBudgetRequested:
                loadResponse.is_gguf && !loadResponse.is_diffusion
                  ? (loadResponse.requested_reasoning_budget ?? loadReasoningBudget)
                  : -1,
              loadedReasoningBudgetMessageRequested:
                loadResponse.is_gguf && !loadResponse.is_diffusion
                  ? (loadResponse.requested_reasoning_budget_message ?? loadReasoningBudgetMessage)
                  : "",
              nBatch: committedNBatch,
              loadedNBatch: committedNBatch,
              ...committedServerTuning,
              // What this model is running, for the rollback below: an omitted field inherited the resident
              // process's list, so the last thing we knew still holds unless this was a different model. An
              // explicit empty list is recorded as empty, not null, since omitting the field is what makes /load
              // inherit. The server's echo comes first, as the only account of what the launch carried.
              ...loadedLlamaCppConfigFields(loadResponse, loadLlamaCppConfig),
              loadedLlamaExtraArgs:
                loadResponse.requested_llama_extra_args !== undefined
                  ? (loadResponse.requested_llama_extra_args ?? [])
                  : loadLlamaExtraArgs !== undefined
                    ? (loadLlamaExtraArgs ?? [])
                    : resetsPerModelSettings
                      ? null
                      : (stateBeforeUnload.loadedLlamaExtraArgs ?? null),
              nUbatch: committedNUbatch,
              loadedNUbatch: committedNUbatch,
              customContextLength: keepCustomCtx,
              loadedCustomContextLength: keepCustomCtx,
              defaultChatTemplate: loadResponse.chat_template ?? null,
              chatTemplateOverride: effectiveChatTemplateOverride,
              loadedChatTemplateOverride: effectiveChatTemplateOverride,
              loadedIsMultimodal: isMultimodalResponse(loadResponse),
              mmprojFallbackReason: loadResponse.mmproj_fallback_reason ?? null,
              loadedIsDiffusion: loadResponse.is_diffusion ?? false,
              activeModelIsLocal: loadResponse.is_local_model ?? false,
              activeLoadId: loadPath === modelId ? null : loadPath,
              activeNativePathToken: nativePathToken ?? null,
              activeNativePathExpiresAtMs: nativePathToken
                ? nativePathExpiresAtMs
                : null,
            });
            // fromLoad: this browser performed the load, so the mode it chose
            // outranks a persisted toggle describing the previous model.
            noteLoadedModelReasoningMode(modelId, nextReasoningEnabled, true);
            // Unlock attach menus for capabilities the catalog entry lacked.
            syncModelCapabilities(modelId, loadResponse);
            // Qwen3-family: apply thinking-mode-specific params after load.
            const p = resolveQwenThinkingParams(
              modelId,
              nextReasoningEnabled,
            );
            if (
              p !== null &&
              (loadResponse.supports_reasoning ?? false)
            ) {
              const store = useChatRuntimeStore.getState();
              if (store.activePresetSource === "builtin-default") {
                // Same rule as the load response: defaults first, this model's remembered settings over them.
                store.setParams({ ...store.params, ...p }, {
                  fromModelDefaults: true,
                  maxTokensCap: loadedContextCap,
                });
              }
            }
            await refresh({ signal: abortCtrl.signal });
            postLoadRefresh.needed = Boolean(
              (loadResponse.is_gguf || isGguf || ggufVariant) &&
                !isExternalModelId(modelId),
            );
            useChatRuntimeStore.setState({
              loadedEngine: loadResponse.engine ?? "auto",
              loadedEnginePrecision: loadResponse.engine_precision ?? "auto",
              loadedEngineParallelism: loadResponse.engine_parallelism ?? "tensor",
            });
            // Remembered so auto-load re-picks what the user ran, not the smallest. Native file-picker paths
            // need a signed, expiring lease, so they stay out.
            const indexedLocalPick =
              typeof selection !== "string" && selection.source === "local";
            if (
              !isLora &&
              !(loadResponse.is_lora ?? false) &&
              !nativePathToken &&
              !isExternalModelId(modelId) &&
              (indexedLocalPick || !isLocalModelPath(modelId))
            ) {
              recordLastLocalModelLoad({
                id: modelId,
                kind:
                  loadResponse.is_gguf || isGguf || ggufVariant
                    ? "gguf"
                    : "model",
                ggufVariant: ggufVariant ?? null,
              });
            }
          } catch (error) {
            notifyLocalPromptQueueLoadFailed(lifecycleLease);
            // Cancellation already handles unloading.
            if (abortCtrl.signal.aborted) throw error;
            // A load that got no answer may still be running (a page reload mid-load, for one): putting the
            // previous model back would replace it. Only an answered failure is safe to roll back.
            if (
              previousWasUnloaded &&
              previousCheckpoint &&
              shouldRestorePreviousModel(error)
            ) {
              let rollbackNativePathLease: string | undefined;
              if (previousActiveNativePathToken) {
                try {
                  rollbackNativePathLease = (
                    await consumeNativePathToken(previousActiveNativePathToken, "load-model")
                  ).nativePathLease;
                } catch {
                  throw new Error(
                    "Could not reload the previous local model: please re-select the file.",
                  );
                }
              }
              try {
                const rollbackResponse = await loadModel({
                  // The pin it loaded from: without it this retries the ref that needed pinning.
                  model_path: previousActiveLoadId || previousCheckpoint,
                  engine: stateBeforeUnload.loadedEngine,
                  engine_precision: stateBeforeUnload.loadedEnginePrecision,
                  engine_parallelism: stateBeforeUnload.loadedEngineParallelism,
                  nativePathLease: rollbackNativePathLease,
                  hf_token: hfToken,
                  max_seq_length: rollbackMaxSeqLength,
                  load_in_4bit: stateBeforeUnload.loadedEngine === "auto",
                  is_lora: previousIsLora,
                  gguf_variant: previousVariant,
                  trust_remote_code:
                    previousModelRequiresTrustRemoteCode || trustRemoteCode,
                  // Resend the previous model's pinned approval so restoring it is not re-blocked.
                  approved_remote_code_fingerprint:
                    approvedRemoteCodeFingerprints.get(previousCheckpoint) ?? null,
                  chat_template_override:
                    rollbackState.loadedChatTemplateOverride,
                  cache_type_kv: rollbackState.loadedKvCacheDtype,
                  mlx_kv_quant: rollbackState.loadedMlxKvQuantRequested,
                  speculative_type:
                    rollbackState.loadedSpeculativeType,
                  spec_draft_n_max:
                    rollbackState.loadedSpecDraftNMax,
                  n_parallel: rollbackState.loadedNParallel,
                  reasoning_budget:
                    rollbackState.loadedReasoningBudgetRequested ?? -1,
                  reasoning_budget_message:
                    rollbackState.loadedReasoningBudgetMessageRequested ?? "",
                  // omit unset fields: a null counts as set and would strip the previous server's extras
                  ...(rollbackState.loadedNBatch != null
                    ? { n_batch: rollbackState.loadedNBatch }
                    : {}),
                  ...(rollbackState.loadedNUbatch != null
                    ? { n_ubatch: rollbackState.loadedNUbatch }
                    : {}),
                  ...serverTuningLoadPayload({
                    loadMode: rollbackState.loadedLoadMode,
                    specDraftCacheDtype:
                      rollbackState.loadedSpecDraftCacheDtype,
                    ctxCheckpoints: rollbackState.loadedCtxCheckpoints,
                    cacheRam: rollbackState.loadedCacheRam,
                  }),
                  // Explicit, unlike the batch pair above: the failed switch left the TARGET resident, so an
                  // omitted field here inherits across models, which the route refuses.
                  ...llamaCppConfigPayload(
                    rollbackState.loadedLlamaCppConfig ?? undefined,
                  ),
                  ...(rollbackState.loadedLlamaExtraArgs != null
                    ? { llama_extra_args: rollbackState.loadedLlamaExtraArgs }
                    : {}),
                  // Restore the previous model in the split mode it was running, not the default layer split.
                  tensor_parallel: rollbackState.loadedTensorParallel ?? false,
                  // What the PREVIOUS server was loaded with. Not the control field, which
                  // applyPerModelConfigToRuntime has already overwritten with the TARGET's setting, and not
                  // loadedVisionDisabledByUser, which is narrowed to models that can do images.
                  disable_vision: rollbackState.loadedDisableVision ?? false,
                  // Restore the previous model's GPU Memory placement, not backend defaults.
                  gpu_memory_mode: rollbackState.loadedGpuMemoryMode ?? "auto",
                  gpu_layers: rollbackState.loadedGpuLayers ?? GPU_LAYERS_AUTO,
                  // A recovered Vulkan model needs its staged CPU-only runtime back after the failed target load
                  // unloaded the live server.
                  cpu_fallback: rollbackState.loadedCpuFallback,
                  n_cpu_moe: rollbackState.loadedNCpuMoe ?? 0,
                  tensor_split: rollbackState.loadedSplitRatio ?? undefined,
                  gpu_ids: rollbackState.loadedGpuIds ?? undefined,
                  // The failed swap already unloaded the server those runs used.
                  force_cancel_active: true,
                });
                const rollbackSpeculativeType = normalizeSpeculativeType(
                  rollbackResponse.speculative_type,
                );
                useChatRuntimeStore.setState({
                  llamaCppConfig:
                    rollbackState.loadedLlamaCppConfig ?? undefined,
                  loadedLlamaCppConfig: rollbackState.loadedLlamaCppConfig,
                  llamaCppConfigSummary:
                    rollbackResponse.llama_cpp_config_summary ??
                    rollbackState.llamaCppConfigSummary,
                  activeModelIsLocal: rollbackResponse.is_local_model ?? false,
                  activeLoadId: previousActiveLoadId ?? null,
                  activeNativePathToken: previousActiveNativePathToken ?? null,
                  // Restore the previous token's lease together with the token so a rollback never pairs restored
                  // token A with failed load B's expiry.
                  activeNativePathExpiresAtMs: previousActiveNativePathToken
                    ? (previousActiveNativePathExpiresAtMs ?? null)
                    : null,
                  // Restore the editable speculative knobs to the rolled-back model's; the loaded baselines come
                  // from its reload echo.
                  speculativeType: rollbackState.loadedSpeculativeType ?? null,
                  specDraftNMax: rollbackState.loadedSpecDraftNMax ?? null,
                  // Control keeps its intent; only the baseline takes the echo.
                  nParallel: previousNParallel,
                  loadedNParallel: rollbackState.loadedNParallel ?? null,
                  reasoningBudget: previousReasoningBudget,
                  loadedReasoningBudget:
                    rollbackResponse.reasoning_budget ?? -1,
                  reasoningBudgetMessage: previousReasoningBudgetMessage,
                  loadedReasoningBudgetMessage:
                    rollbackResponse.reasoning_budget_message ?? "",
                  loadedReasoningBudgetRequested:
                    rollbackResponse.requested_reasoning_budget ??
                    rollbackState.loadedReasoningBudgetRequested ??
                    -1,
                  loadedReasoningBudgetMessageRequested:
                    rollbackResponse.requested_reasoning_budget_message ??
                    rollbackState.loadedReasoningBudgetMessageRequested ??
                    "",
                  nBatch: previousNBatch,
                  loadedNBatch: rollbackState.loadedNBatch ?? null,
                  nUbatch: previousNUbatch,
                  loadedNUbatch: rollbackState.loadedNUbatch ?? null,
                  // Same split: the controls keep the outgoing model's intent and the baselines come from what
                  // that model was launched with.
                  loadMode: previousServerTuning.loadMode ?? null,
                  loadedLoadMode: rollbackState.loadedLoadMode ?? null,
                  specDraftCacheDtype:
                    previousServerTuning.specDraftCacheDtype ?? null,
                  loadedSpecDraftCacheDtype:
                    rollbackState.loadedSpecDraftCacheDtype ?? null,
                  ctxCheckpoints: previousServerTuning.ctxCheckpoints ?? null,
                  loadedCtxCheckpoints:
                    rollbackState.loadedCtxCheckpoints ?? null,
                  cacheRam: previousServerTuning.cacheRam ?? null,
                  loadedCacheRam: rollbackState.loadedCacheRam ?? null,
                  // A custom echo carries the INI's tuning, not the managed baselines (as managedKvCacheFields).
                  ...(rollbackResponse.requested_llama_cpp_config?.mode ===
                  "custom"
                    ? {
                        loadedSpeculativeType:
                          rollbackState.loadedSpeculativeType,
                        loadedSpecDraftNMax: rollbackState.loadedSpecDraftNMax,
                        loadedKvCacheDtype: rollbackState.loadedKvCacheDtype,
                      }
                    : {
                        loadedSpeculativeType: rollbackSpeculativeType,
                        loadedSpecDraftNMax:
                          rollbackResponse.spec_draft_n_max ?? null,
                        loadedKvCacheDtype:
                          rollbackResponse.cache_type_kv ?? null,
                      }),
                  ...mlxRuntimeStateFrom(rollbackResponse),
                  // After the spread, which seeds the control from the echo; the control keeps its intent, like
                  // nParallel above.
                  mlxKvQuant: previousMlxKvQuant,
                  loadedChatTemplateOverride:
                    rollbackState.loadedChatTemplateOverride,
                  ...managedGpuMemoryFields(rollbackResponse),
                  tensorParallel: rollbackResponse.tensor_parallel ?? false,
                  loadedTensorParallel:
                    rollbackResponse.tensor_parallel ?? false,
                  loadedDisableVision:
                    rollbackResponse.disable_vision ?? false,
                  // The rolled-back model's own loaded value, matching the request above field for field. Not
                  // stateBeforeUnload.disableVision, which holds the TARGET's value by now, and not the echo either.
                  disableVision: rollbackState.loadedDisableVision ?? false,
                  loadedVisionDisabledByUser:
                    rollbackResponse.vision_disabled_by_user ?? false,
                  customContextLength:
                    rollbackState.loadedCustomContextLength,
                  loadedCustomContextLength:
                    rollbackState.loadedCustomContextLength,
                });
                await refresh();
              } catch {
                // Rollback also failed; surface the original load error below.
              }
            }
            throw error;
          }
        }

        const isCachedLoad = downloadComplete;
        const toastTitle = isCachedLoad ? "Starting model…" : "Downloading model…";
        const modelLoadToastOptions = (description: ReturnType<typeof renderLoadDescription>) => ({
          description,
          duration: Infinity,
          closeButton: true,
          cancel: {
            label: "Cancel",
            onClick: cancelLoading,
          },
          classNames: MODEL_LOAD_TOAST_CLASSNAMES,
          onDismiss: (dismissedToast: { id: string | number }) => {
            if (loadToastIdRef.current !== dismissedToast.id) {
              return;
            }
            setLoadToastDismissedState(true);
          },
        });
        const toastId = toast(
          null,
          modelLoadToastOptions(
            renderLoadDescription(
              toastTitle,
              loadingDescription,
              isCachedLoad ? null : 0,
              isCachedLoad ? null : "Preparing download",
            ),
          ),
        );
        loadToastIdRef.current = toastId;

        // Poll download progress for non-cached models, then poll the llama-server mmap phase so
        // "Starting model..." does not look frozen on large MoE models.
        let progressInterval: ReturnType<typeof setInterval> | null = null;
        const expectedBytes =
          typeof selection !== "string" ? selection.expectedBytes ?? 0 : 0;

        // One buffer per phase, so a flip cannot price the new phase against the old one's clock. Was a
        // private copy of the shared estimator, so fixes never reached this toast. Takes SECONDS.
        const dlSamples: TransferSample[] = [];
        const mmapSamples: TransferSample[] = [];

        function estimate(
          samples: TransferSample[],
          bytes: number,
          total: number,
        ): { rate: number; eta: number; stable: boolean } {
          if (typeof document !== "undefined" && document.hidden) {
            // This 2s interval is clamped to about once a minute while hidden, and the estimator reads gaps
            // as the burst cadence.
            samples.length = 0;
            return { rate: 0, eta: 0, stable: false };
          }
          appendSample(samples, Date.now() / 1000, bytes);
          const stats = computeTransferStats(samples, total);
          return {
            rate: stats.stable ? stats.rateBytesPerSecond : 0,
            eta: stats.stable ? stats.etaSeconds : 0,
            stable: stats.stable,
          };
        }

        function composeProgressLabel(
          dlGb: number,
          totalGb: number,
          bytes: number,
          total: number,
          samples: TransferSample[],
        ): string {
          const base =
            totalGb > 0
              ? `${dlGb.toFixed(1)} of ${totalGb.toFixed(1)} GB`
              : `${dlGb.toFixed(1)} GB downloaded`;
          const est = estimate(samples, bytes, total);
          if (!est.stable) return base;
          const rateStr = formatRate(est.rate);
          const etaStr = total > 0 ? formatEta(est.eta) : "";
          return etaStr && etaStr !== "--"
            ? `${base} • ${rateStr} • ${etaStr} left`
            : `${base} • ${rateStr}`;
        }

  // A load that believes the weights are cached can still turn into a download (#9094): the
  // backend re-fetches a blob it judged unsafe to resume. MOVEMENT is the only proof accepted,
  // since bytes below the expected total is the ordinary state of a partial revision.
        const watchForCacheMiss =
          !managedLoad && isDownloaded && !isLocal && nativePathToken == null && !isOllamaModelId(modelId);
        const cacheMissDescription = [
          currentCheckpoint ? "Switching models." : null,
          extraLoadingDescription ?? null,
          CACHE_MISS_DOWNLOAD_DESCRIPTION,
        ]
          .filter(Boolean)
          .join(" ");
        let activeLoadingDescription = loadingDescription;
        let cacheMissWatch = EMPTY_CACHE_MISS_WATCH;
        let cacheMissDownload = false;

        const pollDownload = async () => {
          if (abortCtrl.signal.aborted || !loadingModelRef.current) {
            if (progressInterval) clearInterval(progressInterval);
            return;
          }
          try {
            const progressModelIdsAtRequest = [...progressModelIds];
            const progressResponses =
              ggufVariant && expectedBytes > 0
                ? [
                    await getGgufDownloadProgress(
                      modelId,
                      ggufVariant,
                      expectedBytes,
                      hfToken,
                    ),
                  ]
                : await Promise.all(
                    progressModelIdsAtRequest.map((progressModelId) =>
                      getDownloadProgress(progressModelId, hfToken, mlxLoadProgress),
                    ),
                  );
            if (!loadingModelRef.current) return;
            if (
              progressModelIdsAtRequest.length !== progressModelIds.length ||
              progressModelIdsAtRequest.some(
                (progressModelId, index) =>
                  progressModelId !== progressModelIds[index],
              )
            ) {
              return;
            }
            const allDownloadsComplete = progressResponses.every(
              ({ progress }) => progress >= 1,
            );
            const firstProgress = progressResponses[0];
            if (!firstProgress) return;
            const prog =
              progressResponses.find(
                ({ progress }) => progress > 0 && progress < 1,
              ) ??
              progressResponses.find(
                ({ downloaded_bytes, expected_bytes, progress }) =>
                  downloaded_bytes > 0 &&
                  expected_bytes === 0 &&
                  progress === 0,
              ) ??
              progressResponses.find(({ progress }) => progress < 1) ??
              firstProgress;

            if (prog.progress > 0 && prog.progress < 1) {
              hasShownProgress = true;
              const dlGb = prog.downloaded_bytes / 1e9;
              const totalGb = prog.expected_bytes / 1e9;
              const pct = Math.round(prog.progress * 100);
              const progressLabel = composeProgressLabel(
                dlGb,
                totalGb,
                prog.downloaded_bytes,
                prog.expected_bytes,
                dlSamples,
              );
              // loadProgress state is only read by the dismissed-toast inline status, and writing it while the
              // toast is visible re-renders the whole chat page every poll. Feed the toast directly instead.
              if (loadToastDismissedRef.current) {
                setLoadProgress({
                  percent: pct,
                  label: progressLabel,
                  phase: "downloading",
                });
                return;
              }
              toast(null, {
                id: toastId,
                ...modelLoadToastOptions(
                  renderLoadDescription(
                    "Downloading model…",
                    activeLoadingDescription,
                    pct,
                    progressLabel,
                  ),
                ),
              });
            } else if (
              prog.downloaded_bytes > 0 &&
              prog.expected_bytes === 0 &&
              prog.progress === 0
            ) {
              hasShownProgress = true;
              const dlGb = prog.downloaded_bytes / 1e9;
              const est = estimate(dlSamples, prog.downloaded_bytes, 0);
              const rateSuffix =
                est.stable ? ` • ${formatRate(est.rate)}` : "";
              const unknownTotalLabel = `${dlGb.toFixed(1)} GB downloaded${rateSuffix}`;
              // Inline-status-only state; skip the chat-page re-render unless it is shown.
              if (loadToastDismissedRef.current) {
                setLoadProgress({
                  percent: null,
                  label: unknownTotalLabel,
                  phase: "downloading",
                });
              } else {
                // The toast is UP and would otherwise say "Loading cached model into
                // memory" for the whole download. A missing total is supported, not an error.
                toast(null, {
                  id: toastId,
                  ...modelLoadToastOptions(
                    renderLoadDescription(
                      "Downloading model…",
                      activeLoadingDescription,
                      null,
                      unknownTotalLabel,
                    ),
                  ),
                });
              }
            } else if (
              allDownloadsComplete &&
              (hasShownProgress ||
                progressModelIds.some(
                  (progressModelId) => progressModelId !== modelId,
                ))
            ) {
              downloadComplete = true;
              if (loadToastDismissedRef.current) {
                setLoadProgress({
                  percent: 100,
                  label: "Download complete",
                  phase: "starting",
                });
              } else {
                toast(null, {
                  id: toastId,
                  ...modelLoadToastOptions(
                    renderLoadDescription(
                      "Starting model…",
                      hasShownProgress
                        ? "Download complete. Loading the model into memory."
                        : loadingDescription,
                      hasShownProgress ? 100 : null,
                      hasShownProgress ? "Download complete" : null,
                    ),
                  ),
                });
              }
              // Keep polling: the mmap branch below takes over from here.
            }
          } catch {
            // Ignore polling errors; keep polling.
          }
        };

        const pollLoad = async () => {
          if (abortCtrl.signal.aborted || !loadingModelRef.current) {
            if (progressInterval) clearInterval(progressInterval);
            return;
          }
          try {
            const prog = await getLoadProgress();
            if (!loadingModelRef.current) return;
            if (!prog || prog.phase == null) return;
            if (prog.phase === "ready") {
              // Loaded. The chat flow will flip loadingModelRef shortly; just stop polling.
              if (progressInterval) clearInterval(progressInterval);
              return;
            }
            if (managedLoad && prog.bytes_total <= 0) {
              const label = prog.phase === "warming_up"
                ? "Warming up inference kernels. The first load can take several minutes."
                : prog.phase === "loading_weights"
                  ? "Loading model weights into GPU memory."
                  : "Starting the inference engine and preparing model files.";
              if (loadToastDismissedRef.current) {
                setLoadProgress({ percent: 0, label, phase: "starting" });
              } else {
                toast(null, { id: toastId, ...modelLoadToastOptions(renderLoadDescription("Starting model...", label)) });
              }
              return;
            }
            if (prog.bytes_total <= 0) return; // nothing useful to render
            // Decimal GB (1e9) so the total matches the file size Hugging Face reports, not the smaller base-1024 GiB.
            const loadedGb = prog.bytes_loaded / 1e9;
            const totalGb = prog.bytes_total / 1e9;
            const pct = Math.min(99, Math.round(prog.fraction * 100));
            const est = estimate(mmapSamples, prog.bytes_loaded, prog.bytes_total);
            const base = `${loadedGb.toFixed(1)} of ${totalGb.toFixed(1)} GB in memory`;
            const label = est.stable
              ? `${base} • ${formatRate(est.rate)}${
                  formatEta(est.eta) !== "--" ? ` • ${formatEta(est.eta)} left` : ""
                }`
              : base;
            // Inline-status-only state (see pollDownload): while the toast is up, skip the state write so
            // the chat page does not re-render every poll.
            if (loadToastDismissedRef.current) {
              setLoadProgress({
                percent: pct,
                label,
                phase: "starting",
              });
              return;
            }
            toast(null, {
              id: toastId,
              ...modelLoadToastOptions(
                renderLoadDescription(
                  "Starting model…",
                  "Paging weights into memory.",
                  pct,
                  label,
                ),
              ),
            });
          } catch {
            // Ignore polling errors.
          }
        };

        /** Whether this "cached" load has quietly become a download. */
        const cacheMissDownloadStarted = async (): Promise<boolean> => {
          try {
            const reading = await getDownloadProgress(modelId, hfToken);
              // Re-read AFTER the await, as pollDownload does: the load can finish or be
              // cancelled in flight, and `finally` then calls resetLoadingUiForRun().
            if (abortCtrl.signal.aborted || !loadingModelRef.current) return false;
            const verdict = watchCacheMissDownload(cacheMissWatch, reading);
            cacheMissWatch = verdict.watch;
            if (!verdict.started) return false;
            cacheMissDownload = true;
              // pollDownload's completion branch is gated on it; leaving it false leaves
              // `downloadComplete` false forever and suppresses later progress.
            hasShownProgress = true;
            downloadComplete = false;
            activeLoadingDescription = cacheMissDescription;
            setLoadProgress({
              percent: verdict.percent,
              label: "Downloading the rest of the model",
              phase: "downloading",
            });
            return true;
          } catch {
            // Ignore polling errors; the next poll asks again.
            return false;
          }
        };

        const pollProgress = async () => {
          if (!downloadComplete) {
            await pollDownload();
            return;
          }
          if (watchForCacheMiss && !cacheMissDownload && (await cacheMissDownloadStarted())) {
            await pollDownload();
            return;
          }
          await pollLoad();
        };

        let hasShownProgress = false;
        setTimeout(pollProgress, 500);
        progressInterval = setInterval(pollProgress, 2000);

        try {
          await performLoad();
          // User cancelled mid-refresh; cancelLoading handles teardown.
          if (abortCtrl.signal.aborted) return;
          // Same composition as the auto-load path, through the same helper, so the two cannot describe an
          // identical failure differently.
          const notice = loadFallbackNotice(
            `${toastDisplayName} loaded`,
            cpuFallbackReason,
            mmprojFallbackReason,
            offloadWarning(offloadCounts),
          );
          const loadedTitle = notice.title;
          const loadedDescription = notice.description;
          const showLoadedToast = notice.degraded ? toast.warning : toast.success;
          if (loadToastDismissedRef.current) {
            showLoadedToast(loadedTitle, {
              description: loadedDescription,
              closeButton: true,
              duration: 8000,
            });
          } else {
            showLoadedToast(loadedTitle, {
              id: toastId,
              description: loadedDescription,
              cancel: undefined,
              closeButton: true,
              duration: 8000,
              onDismiss: undefined,
            });
          }
        } catch (err) {
          if (!abortCtrl.signal.aborted) {
            const message =
              err instanceof Error ? err.message : "Failed to load model";
            const [summary, ...rest] = message.split("\n");
            const detail = rest.join("\n").trim();
            const runnerLogPath = failureLogPath(message);
            const logsAction = runnerLogPath
              ? viewLogsAction(
                  loadFailureLogFamily(isGguf, isDiffusion, runnerLogPath),
                  runnerLogPath,
                )
              : undefined;
            if (loadToastDismissedRef.current) {
              toast.error(summary, {
                description: detail || undefined,
                action: logsAction,
              });
            } else {
              toast.error(summary, {
                id: toastId,
                description: detail || undefined,
                action: logsAction,
                cancel: undefined,
                classNames: undefined,
                closeButton: true,
                duration: 8000,
                onDismiss: undefined,
              });
            }
          }
          throw err;
        } finally {
          if (progressInterval) clearInterval(progressInterval);
          resetLoadingUiForRun(loadRun);
          if (postLoadRefresh.needed && !abortCtrl.signal.aborted) {
            void refreshContextUsage({ afterModelLoad: true });
          }
        }
      } catch (error) {
        // A superseded run must not restore its config over the replacement's: the newer
        // selection inherited this run's rollback target and owns restoration from here.
        // Standalone cancellations keep restoring.
        if (modelSelectionIntentEpoch === loadIntentId) restorePreviousConfig();
        if (abortCtrl.signal.aborted) return; // User cancelled, nothing to report
        resetLoadingUiForRun(loadRun);
        const message =
          error instanceof Error ? error.message : "Failed to load model";
        setModelsError(message);
        setLastModelLoadError(message); // load-specific failure for the attach gates
        if (throwOnError) {
          throw error instanceof Error ? error : new Error(message);
        }
      } finally {
        // Last act of this run's coroutine: unblocks a cancellation holding the slot.
        markLoadRunSettled();
      }
    },
    [
      cancelLoading,
      loras,
      models,
      params.checkpoint,
      refresh,
      renderLoadDescription,
      resetLoadingUiForRun,
      setLoadToastDismissedState,
      setModelsError,
      setLastModelLoadError,
      setParams,
    ],
  );

  const loadNpuModel = useCallback(
    async (
      modelPath: string,
      reload?: { forceReload?: boolean; config?: PerModelConfig },
    ) => {
      const store = useChatRuntimeStore.getState();
      if (
        !reload?.forceReload &&
        store.params.checkpoint === modelPath &&
        store.residentCheckpoint === modelPath
      ) {
        return;
      }
      // Context length is the one setting FastFlowLM takes; null (Auto) sends 0 for its default.
      // Either field: a record saved as a non-GGUF Max Seq Length pins it too.
      const contextLength = savedContextPin(
        reload?.config ?? resolveInitialConfig(modelPath).config,
      );
      if (loadingModelRef.current ?? store.loadingModelPick) {
        toast.info("Another model is already loading", {
          description: "Wait for it to finish or cancel it first.",
        });
        return;
      }
      const lease = store.beginModelLoading("preparing");
      if (lease === null) {
        toast.info("A model is loading", {
          description: "Wait for it to finish or cancel it first.",
        });
        return;
      }
      loadLifecycleLeaseRef.current = lease;
      const loadIntentId = ++modelSelectionIntentEpoch;
      const displayName = modelDisplayName(
        modelPath.slice(modelPath.indexOf(":") + 1),
      );
      const previous = useChatRuntimeStore.getState();
      const previousCheckpoint = previous.params.checkpoint;
      const previousGgufVariant = previous.activeGgufVariant;
      const abortCtrl = new AbortController();
      const signal = abortCtrl.signal;
      let markLoadRunSettled = () => {};
      const settledPromise = new Promise<void>((resolve) => {
        markLoadRunSettled = resolve;
      });
      // Registered like any local load so Stop loading and a replacing pick can cancel it.
      const loadRun: ActiveModelLoadRun = {
        attemptId: loadIntentId,
        intentId: loadIntentId,
        abortController: abortCtrl,
        requestId: crypto.randomUUID(),
        loadAttemptPath: null,
        cancelPromise: null,
        rollbackCheckpoint: previousCheckpoint,
        rollbackVariant: previousGgufVariant ?? null,
        rollbackLoadId: previous.activeLoadId ?? null,
        rollbackNativePathToken: previous.activeNativePathToken ?? null,
        rollbackNativePathExpiresAtMs:
          previous.activeNativePathExpiresAtMs ?? null,
        rollbackLoadedState: previous,
        residentModelUnloaded: false,
        forceCancelActive: false,
        settledPromise,
        markSettled: markLoadRunSettled,
      };
      activeLoadRunRef.current = loadRun;
      let toastId: string | number | undefined;
      try {
        const stopDecision = await confirmStopRunningChatsIfNeeded(
          "Loading a different model",
        );
        if (!stopDecision.proceed || signal.aborted) return;
        loadAbortRef.current = abortCtrl;
        const loadInfo = {
          id: modelPath,
          displayName,
          isDownloaded: true,
          isCachedLora: false,
          ggufVariant: null,
          nativePathToken: null,
        };
        setModelsError(null);
        setLastModelLoadError(null);
        setLoadingModel(loadInfo);
        loadingModelRef.current = loadInfo;
        useChatRuntimeStore.getState().setLoadingModelPick(pickOf(loadInfo));
        setLoadProgress({ percent: null, label: null, phase: "starting" });
        toastId = toast.loading(`Loading ${displayName} on the NPU`);
        loadToastIdRef.current = toastId;
        loadRun.forceCancelActive = stopDecision.forceCancelActive;
        loadRun.loadAttemptPath = modelPath;
        cancelPreStreamRunReservations(stopDecision.preStreamRunTokens);
        requestLocalPromptQueueStop(stopDecision.promptQueueThreadIds);
        await loadModel({
          model_path: modelPath,
          hf_token: null,
          max_seq_length: contextLength ?? 0,
          load_in_4bit: false,
          is_lora: false,
          force_reload: reload?.forceReload === true,
          force_cancel_active: stopDecision.forceCancelActive,
          load_request_id: loadRun.requestId,
        });
        if (signal.aborted) return;
        const status = await getInferenceStatus();
        if (signal.aborted) return;
        useChatRuntimeStore.getState().setCheckpoint(modelPath, null);
        applyActiveModelStatusToStore(status, {
          previousCheckpoint,
          previousGgufVariant,
          seedLoadParams: true,
        });
        syncModelCapabilities(modelPath, status);
        void refreshContextUsage({ afterModelLoad: true });
        toast.success(`${displayName} loaded on the NPU`, {
          id: toastId,
          closeButton: true,
          duration: 4000,
        });
      } catch (error) {
        if (signal.aborted) return;
        const message =
          error instanceof Error ? error.message : "Failed to load model";
        setModelsError(message);
        setLastModelLoadError(message);
        toast.error(message, {
          id: toastId,
          closeButton: true,
          duration: 8000,
        });
        await syncInferenceStatusToStore().catch(() => {});
      } finally {
        resetLoadingUiForRun(loadRun);
        markLoadRunSettled();
      }
    },
    [resetLoadingUiForRun, setLastModelLoadError, setModelsError],
  );

  const ejectModel = useCallback(async (): Promise<boolean> => {
    if (!params.checkpoint) {
      return false;
    }
    const bailIfLoading = (): boolean => {
      const runtime = useChatRuntimeStore.getState();
      if (!runtime.modelLoading && !runtime.loadingModelPick) return false;
      toast.info("A model is loading", {
        description: "Wait for it to finish or cancel it first.",
      });
      return true;
    };
    if (bailIfLoading()) return false;
    setModelsError(null);
    if (isExternalModelId(params.checkpoint)) {
      clearCheckpoint();
      await refresh();
      return true;
    }
    let lifecycleLease: ModelLifecycleLease | null = null;
    try {
      // Hold the lifecycle lease through confirmation and unloading.
      lifecycleLease = useChatRuntimeStore
        .getState()
        .beginModelLoading("unloading");
      if (lifecycleLease === null) {
        return false;
      }
      // Ejecting tears down llama-server, so every chat stops. Same prompt, but it leaves no model
      // loaded, so it must not be worded as a reload.
      const stopDecision = await confirmStopRunningChatsIfNeeded(
        "Unloading the model",
        "unload",
      );
      if (!stopDecision.proceed) return false;

      async function performUnload(): Promise<void> {
        cancelPreStreamRunReservations(stopDecision.preStreamRunTokens);
        requestLocalPromptQueueStop(stopDecision.promptQueueThreadIds);
        await unloadModel({
          model_path: params.checkpoint,
          force_cancel_active: stopDecision.forceCancelActive,
        });
        requestLocalPromptQueueStop();
        clearCheckpoint();
        await refresh();
      }

      const unloadPromise = performUnload();
      toast.promise(unloadPromise, {
        loading: "Unloading model",
        success: { message: "Model unloaded", duration: 1200 },
        error: (err) =>
          err instanceof Error ? err.message : "Failed to unload model",
        description: "Releases VRAM and resets inference state.",
      });
      await unloadPromise;
      return true;
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to unload model";
      setModelsError(message);
      return false;
    } finally {
      if (lifecycleLease !== null) {
        useChatRuntimeStore.getState().endModelLoading(lifecycleLease);
      }
    }
  }, [clearCheckpoint, params.checkpoint, refresh, setModelsError]);

  return {
    refresh,
    selectModel,
    loadNpuModel,
    ejectModel,
    cancelLoading,
    cancelLoadingForReplacement,
    invalidatePendingModelSelection,
    discardExternalReplacement,
    restoreConfigForExternalReplacement,
    isModelSelectionIntentCurrent,
    loadingModel,
    loadProgress,
    loadToastDismissed,
  };
}
