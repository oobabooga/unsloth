# SPDX-License-Identifier: AGPL-3.0-only
# Copyright 2026-present the Unsloth AI Inc. team. All rights reserved.

"""vLLM on AMD GPUs: the ROCm profile, its host checks, and the launch environment."""

import json
import sys
import threading
from pathlib import Path
from types import SimpleNamespace

import pytest

from core.inference import engine_adapters
from core.inference import engine_install as install
from core.inference import managed_engine
from core.inference.managed_engine import ManagedEngine

_LINUX = pytest.mark.skipif(sys.platform != "linux", reason = "ROCm engines are Linux only")
ROCM_TORCH = {"torch": "2.11.0+rocm7.13.0"}


@pytest.fixture
def rocm(monkeypatch, tmp_path):
    """A Linux host whose Studio runs a ROCm torch, with a complete ROCm 7.2 in a fake /opt/rocm."""
    monkeypatch.setattr(install.platform, "system", lambda: "Linux")
    monkeypatch.setattr(install.platform, "machine", lambda: "x86_64")
    monkeypatch.setattr(install.platform, "libc_ver", lambda: ("glibc", "2.39"))
    monkeypatch.setattr(install, "_studio_packages", lambda: dict(ROCM_TORCH))
    home = tmp_path / "rocm"
    (home / ".info").mkdir(parents = True)
    (home / ".info" / "version").write_text("7.2.1-81\n")
    (home / "lib").mkdir()
    for library in install._ROCM_LIBRARIES:
        (home / "lib" / library).touch()
    monkeypatch.setattr(install, "ROCM_HOME", home)
    monkeypatch.setattr(install, "_system_library_present", lambda soname: True)
    monkeypatch.setattr(install, "_rocm_gpu_arches", lambda: {0: "gfx1151"})
    monkeypatch.setattr(install.shutil, "which", lambda name: f"/usr/bin/{name}")
    return home


def test_a_rocm_studio_gets_the_rocm_profile(rocm):
    assert install.rocm_host()
    chosen = install.profile("vllm")
    assert chosen["accelerator"] == "rocm"
    assert chosen["python"] == (3, 12)
    assert install.requirements("vllm").name == "vllm-linux-rocm723.txt"
    # The lock is the release vLLM publishes for ROCm, on its own torch build.
    assert install._pins("vllm")["vllm"][0] == f"{chosen['version']}+rocm723"
    assert install._pins("vllm")["torch"][0].split("+")[0] == chosen["torch"]
    assert not any(name.startswith("nvidia-") for name in install._pins("vllm"))


def test_a_cuda_or_cpu_studio_keeps_the_cuda_profile(monkeypatch):
    for torch in ("2.13.0+cu130", "2.13.0", None):
        monkeypatch.setattr(install, "_studio_packages", lambda t = torch: {"torch": t} if t else {})
        assert install.profile("vllm")["accelerator"] == "cuda"
        assert install.requirements("vllm").name.startswith("vllm-linux-cu130")


def test_rocm_install_is_isolated_and_reads_the_rocm_index(rocm):
    plan = install.install_plan("vllm")
    assert not plan["shared"] and plan["provided"] == {}
    assert "vllm==0.30.0+rocm723" in plan["requirements"]
    assert install._extra_index_args("vllm") == [
        "--extra-index-url",
        "https://wheels.vllm.ai/rocm/0.30.0/rocm723",
        "--index-strategy",
        "unsafe-best-match",
    ]
    # Every locked wheel is sized, including flash-attn, which PyPI has only as an sdist.
    sizes = install._compat_file("vllm")["sizes"]
    assert sizes and all(sizes.values())
    assert install.download_bytes("vllm") == sum(sizes.values())


def test_rocm_smoke_check_asserts_a_hip_torch(rocm):
    source = install._smoke_source("vllm")
    assert "torch.version.hip" in source and "cuda" not in source
    assert "== '2.12.0'" in source


def test_a_complete_rocm_host_is_supported(rocm):
    assert install.support_reason("vllm") is None
    assert install.support_reason("vllm", 0) is None


def test_sglang_is_refused_on_amd(rocm):
    assert "only on NVIDIA GPUs" in install.support_reason("sglang")
    assert install.profile("sglang")["accelerator"] == "cuda"


@pytest.mark.parametrize(
    ("change", "expected"),
    [
        (
            lambda home, mp: mp.setattr(install.platform, "libc_ver", lambda: ("glibc", "2.35")),
            "glibc 2.39",
        ),
        (lambda home, mp: (home / ".info" / "version").unlink(), "ROCm 7.2 or newer"),
        (lambda home, mp: (home / ".info" / "version").write_text("7.1.1\n"), "found 7.1.1"),
        (lambda home, mp: (home / "lib" / "libMIOpen.so.1").unlink(), "missing libMIOpen.so.1"),
        (
            lambda home, mp: mp.setattr(
                install, "_system_library_present", lambda soname: "mpi" not in soname
            ),
            "libopenmpi3t64",
        ),
        (
            lambda home, mp: mp.setattr(install, "_rocm_gpu_arches", lambda: {0: "gfx1030"}),
            "This GPU is gfx1030",
        ),
        (
            lambda home, mp: mp.setattr(install, "_rocm_gpu_arches", lambda: {}),
            "cannot see an AMD GPU",
        ),
        (
            lambda home, mp: (
                mp.delenv("CC", raising = False),
                mp.setattr(install.shutil, "which", lambda name: None),
            ),
            "needs a C compiler",
        ),
    ],
)
def test_rocm_host_problems_are_named(rocm, monkeypatch, change, expected):
    change(rocm, monkeypatch)
    assert expected in install.support_reason("vllm")


def test_rocm_support_is_judged_per_selected_gpu(rocm, monkeypatch):
    monkeypatch.setattr(install, "_rocm_gpu_arches", lambda: {0: "gfx1030", 1: "gfx1100"})
    # The engine is offered while any GPU can run it; the pick is checked on its own.
    assert install.support_reason("vllm") is None
    assert "gfx1030" in install.support_reason("vllm", 0)
    assert install.support_reason("vllm", 1) is None


def test_rocm_support_never_runs_nvidia_smi(rocm, monkeypatch):
    def fail(*args, **kwargs):
        raise AssertionError("nvidia-smi probed on an AMD host")

    monkeypatch.setattr(install, "_probe_rows", fail)
    assert install.support_reason("vllm", wait = False) is None


def test_torch_memory_rows_budget_the_engine(monkeypatch):
    calls = []

    def run(argv, **kwargs):
        calls.append((argv, kwargs["env"]))
        return SimpleNamespace(stdout = "a warning\n" + json.dumps([[65536.0, 60000.0]]) + "\n")

    monkeypatch.setattr(engine_adapters.subprocess, "run", run)
    monkeypatch.setattr("utils.vram_budget_settings.get_vram_budget_fraction", lambda: 1.0)
    env = {"HIP_VISIBLE_DEVICES": "0", "CUDA_VISIBLE_DEVICES": "0"}
    fraction = engine_adapters.gpu_memory_fraction(
        [0],
        3072,
        engine_adapters.RESERVE_SHARE,
        lambda _: engine_adapters.torch_memory_rows("/env/bin/python", env),
    )
    assert calls[0][0][0] == "/env/bin/python" and calls[0][1] is env
    assert fraction == int((60000 - 0.06 * 65536) / 65536 * 1000) / 1000
    # A probe that answers for fewer devices than were selected is refused, not stretched.
    with pytest.raises(RuntimeError, match = "Could not reserve memory"):
        engine_adapters.gpu_memory_fraction([0, 1], 3072, 0.06, lambda ids: [(65536.0, 60000.0)])


def test_memory_probe_output_is_read_past_warnings_on_either_side():
    # wsl.exe returns stderr after stdout, and torch warns there under WSL (amdsmi cannot start).
    output = (
        "Failed to load torchao/_C_cutlass_90a.abi3.so\n"
        "[[104495.0, 104422.0]]\n"
        "torch/cuda/__init__.py:1048: UserWarning: Can't initialize amdsmi - Error code: 34\n"
        "  warnings.warn(\n"
    )
    assert engine_adapters.memory_rows(output) == [(104495.0, 104422.0)]
    with pytest.raises(ValueError):
        engine_adapters.memory_rows("UserWarning only\n")


def test_a_silent_torch_memory_probe_is_an_actionable_failure(monkeypatch):
    monkeypatch.setattr(
        engine_adapters.subprocess, "run", lambda *a, **k: SimpleNamespace(stdout = "")
    )
    with pytest.raises(RuntimeError, match = "Could not reserve memory"):
        engine_adapters.gpu_memory_fraction(
            [0], 3072, 0.06, lambda _: engine_adapters.torch_memory_rows("/env/bin/python", {})
        )


@pytest.mark.parametrize(
    ("inherited", "expected", "rocr_after"),
    [
        ({}, "1", None),
        ({"HIP_VISIBLE_DEVICES": "1"}, "1", None),
        # HIP numbers what ROCr left: physical 1 is the second of ROCR=0,1 and the first of ROCR=1.
        ({"ROCR_VISIBLE_DEVICES": "0,1"}, "1", "0,1"),
        ({"ROCR_VISIBLE_DEVICES": "1"}, "0", "1"),
    ],
)
@_LINUX
def test_rocm_child_mask_matches_hip_and_cuda(monkeypatch, inherited, expected, rocr_after):
    for key in ("HIP_VISIBLE_DEVICES", "ROCR_VISIBLE_DEVICES", "CUDA_VISIBLE_DEVICES"):
        monkeypatch.delenv(key, raising = False)
    for key, value in inherited.items():
        monkeypatch.setenv(key, value)
    env = dict(inherited)
    mask = managed_engine._rocm_visibility(env, [1])
    assert mask == {"HIP_VISIBLE_DEVICES": expected, "CUDA_VISIBLE_DEVICES": expected}
    assert env.get("ROCR_VISIBLE_DEVICES") == rocr_after


@_LINUX
def test_rocm_engine_starts_with_matching_masks_and_measures_with_its_own_torch(
    monkeypatch, tmp_path
):
    import httpx

    monkeypatch.setattr(install, "engine_root", lambda: tmp_path)
    for key in ("HIP_VISIBLE_DEVICES", "ROCR_VISIBLE_DEVICES", "CUDA_VISIBLE_DEVICES"):
        monkeypatch.delenv(key, raising = False)
    folder = tmp_path / "vllm" / "env-rocm"
    (folder / "bin").mkdir(parents = True)
    (folder / "bin" / "python").touch()
    (tmp_path / "vllm" / "active.json").write_text(
        json.dumps({"directory": "env-rocm", "version": "0.30.0", "accelerator": "rocm"})
    )
    measured = []

    def fraction(
        gpu_ids,
        reserve,
        share,
        measure = None,
    ):
        measured.append(measure)
        return 0.5

    monkeypatch.setattr(managed_engine, "gpu_memory_fraction", fraction)
    engine = ManagedEngine("vllm")

    def command(python, model, port, key, context, memory, tensor_parallel_size):
        code = (
            "import os\n"
            "from http.server import BaseHTTPRequestHandler, HTTPServer\n"
            "class Handler(BaseHTTPRequestHandler):\n"
            " def do_GET(self):\n"
            "  self.send_response(200); self.end_headers()\n"
            "  self.wfile.write('|'.join(os.environ.get(k, '-') for k in ('HIP_VISIBLE_DEVICES', 'CUDA_VISIBLE_DEVICES', 'FLASHINFER_WORKSPACE_BASE')).encode())\n"
            " def log_message(self, *args): pass\n"
            f"HTTPServer(('127.0.0.1', {port}), Handler).serve_forever()\n"
        )
        return [sys.executable, "-u", "-c", code]

    engine.adapter = SimpleNamespace(
        command = command,
        progress = lambda _: None,
        environment = lambda _: {},
        key_environment = lambda _: {},
    )
    errors = []

    def start():
        try:
            engine.start("model", 2048, [0], {"PATH": "/usr/bin:/bin", "HIP_VISIBLE_DEVICES": "3"})
        except Exception as exc:
            errors.append(exc)

    thread = threading.Thread(target = start)
    try:
        thread.start()
        thread.join(15)
        assert not thread.is_alive() and not errors
        hip, cuda, _ = httpx.get(engine.base_url, trust_env = False).text.split("|")
        # An inherited HIP mask that disagrees with the pick would make vLLM refuse to start.
        assert hip == cuda == "0"
        assert measured and measured[0] is not None
    finally:
        assert engine.stop()
        thread.join(5)


def test_rocm_refuses_4bit_before_anything_unloads(rocm, monkeypatch, tmp_path):
    # vLLM's ROCm build has no BitsAndBytes (measured: its quantization list leaves it out).
    monkeypatch.setattr(install, "engine_root", lambda: tmp_path)
    folder = tmp_path / "vllm" / "env-rocm"
    (folder / "bin").mkdir(parents = True)
    (folder / "bin" / "python").touch()
    (tmp_path / "vllm" / "active.json").write_text(
        json.dumps(
            {
                "directory": "env-rocm",
                "version": "0.30.0",
                "accelerator": "rocm",
                "profile_digest": install.profile_digest("vllm"),
            }
        )
    )
    request = SimpleNamespace(
        gpu_ids = None, gguf_variant = None, model_path = "unsloth/Qwen2.5-0.5B-Instruct", is_lora = False
    )
    for precision in ("auto", "bf16", "int8", "fp8"):
        request.engine_precision = precision
        assert managed_engine.validate_load("vllm", request) == [0]
    request.engine_precision = "int4"
    with pytest.raises(ValueError, match = "cannot convert weights to 4-bit"):
        managed_engine.validate_load("vllm", request)
    assert install.status("vllm")["accelerator"] == "rocm"


def test_rocm_refuses_a_bitsandbytes_checkpoint(rocm, tmp_path):
    (tmp_path / "config.json").write_text(
        json.dumps({"quantization_config": {"quant_method": "bitsandbytes", "load_in_4bit": True}})
    )
    config = SimpleNamespace(is_local = True, path = str(tmp_path), identifier = None, is_vision = False)
    with pytest.raises(ValueError, match = "cannot load BitsAndBytes checkpoints"):
        managed_engine.validate_model(config, gpu_ids = [0])


def test_fp8_on_rocm_uses_the_gpu_arch_not_nvidia_smi(rocm, monkeypatch, tmp_path):
    (tmp_path / "config.json").write_text(json.dumps({"num_attention_heads": 8}))
    config = SimpleNamespace(is_local = True, path = str(tmp_path), identifier = None, is_vision = False)

    def fail(*args, **kwargs):
        raise AssertionError("nvidia-smi on an AMD host")

    monkeypatch.setattr(managed_engine.subprocess, "run", fail)
    monkeypatch.setattr(managed_engine, "_rocm_gpu_arches", lambda: {0: "gfx1151", 1: "gfx942"})
    monkeypatch.setattr(managed_engine, "rocm_host", lambda: True)
    options = managed_engine.validate_model(config, gpu_ids = [0], precision = "fp8")
    assert options["disable_cuda_graph"]
    options = managed_engine.validate_model(config, gpu_ids = [1], precision = "fp8")
    assert not options["disable_cuda_graph"]


@pytest.fixture
def windows_rocm(monkeypatch, tmp_path):
    """A Windows Studio on a ROCm torch: engines run in the WSL distro, which brings its own ROCm."""
    from core.inference import wsl_host

    monkeypatch.setattr(install.platform, "system", lambda: "Windows")
    monkeypatch.setattr(
        install, "_studio_packages", lambda: {"torch": "2.10.0+rocm7.11.0a20260106"}
    )
    monkeypatch.setattr(wsl_host, "active", lambda: True)
    monkeypatch.setattr(wsl_host, "support_reason", lambda: None)
    monkeypatch.setattr(wsl_host, "GUEST_ROOT", "/opt/unsloth")
    monkeypatch.setattr(install, "engine_root", lambda: tmp_path / "engines")
    monkeypatch.setattr(install, "_jobs", {})
    monkeypatch.setattr(install, "_rocm_gpu_arches", lambda: {0: "gfx1151"})
    monkeypatch.setattr(wsl_host, "host_dir", lambda: tmp_path / "wsl")
    return wsl_host


def test_windows_amd_studio_offers_vllm_without_a_host_rocm(windows_rocm):
    # Nothing is read from /opt/rocm on Windows: the distro's ROCm is installed with the engine.
    assert install.profile("vllm")["accelerator"] == "rocm"
    assert install.support_reason("vllm") is None
    assert "only on NVIDIA GPUs" in install.support_reason("sglang")


def test_windows_amd_install_sets_up_rocm_in_wsl_before_the_engine(windows_rocm, monkeypatch):
    wsl_host = windows_rocm
    prepared, runs, ready = [], [], iter([False, True])
    monkeypatch.setattr(
        wsl_host,
        "prepare",
        lambda progress, cancel, accelerator = "cuda": prepared.append(accelerator),
    )
    monkeypatch.setattr(wsl_host, "rocm_ready", lambda: next(ready))
    monkeypatch.setattr(wsl_host, "rocm_setup_command", lambda: ["rocm-setup"])
    monkeypatch.setattr(wsl_host, "to_guest_path", lambda path: "/mnt/c/" + Path(path).name)
    monkeypatch.setattr(wsl_host, "put", lambda *a, **k: None)
    monkeypatch.setattr(wsl_host, "distro_name", lambda: "Unsloth-Engines-test")
    monkeypatch.setattr(
        wsl_host,
        "guest",
        lambda argv, **k: json.dumps({"cuda_environment": {}, "deep_gemm_unloadable": False})
        + "\n",
    )
    monkeypatch.setattr(wsl_host, "guest_command", lambda argv, **k: (list(argv), {}))
    monkeypatch.setattr(install, "_run", lambda engine, argv, cancel, env = None: runs.append(argv))
    install._install_wsl("vllm", threading.Event())
    assert prepared == ["rocm"]
    assert runs[0] == ["rocm-setup"]
    venv = next(argv for argv in runs if "venv" in argv)
    # A uv-managed CPython: Triton compiles against Python.h, which Ubuntu's python3.12 lacks.
    assert venv[venv.index("--python") + 1] == "3.12"
    assert venv[venv.index("--python-preference") + 1] == "only-managed"
    sync = next(argv for argv in runs if "sync" in argv)
    assert "https://wheels.vllm.ai/rocm/0.30.0/rocm723" in sync
    assert sync[-1].endswith("vllm-linux-rocm723.txt")
    record = json.loads((install.engine_root() / "vllm" / "active.json").read_text())
    assert (
        record["accelerator"] == "rocm" and record["host"] == "wsl" and record["python"] == "3.12"
    )


def test_windows_amd_install_stops_when_rocm_setup_does_not_finish(windows_rocm, monkeypatch):
    wsl_host = windows_rocm
    monkeypatch.setattr(wsl_host, "prepare", lambda *a, **k: None)
    monkeypatch.setattr(wsl_host, "rocm_ready", lambda: False)
    monkeypatch.setattr(wsl_host, "rocm_setup_command", lambda: ["rocm-setup"])
    monkeypatch.setattr(wsl_host, "guest_command", lambda argv, **k: (list(argv), {}))
    monkeypatch.setattr(install, "_run", lambda *a, **k: None)
    with pytest.raises(RuntimeError, match = "Setting up ROCm in WSL did not finish"):
        install._install_wsl("vllm", threading.Event())


def test_windows_amd_download_size_is_unknown_until_rocm_is_in_wsl(windows_rocm):
    wsl_host = windows_rocm
    wsl_host.write_state(distro = "Unsloth-Engines-test")
    assert install.download_bytes("vllm") is None
    wsl_host.write_state(rocm = wsl_host.rocm_stamp())
    assert install.download_bytes("vllm") == sum(install._compat_file("vllm")["sizes"].values())


@_LINUX
def test_windows_amd_launch_masks_hip_and_measures_in_the_guest(windows_rocm, monkeypatch):
    wsl_host = windows_rocm
    measured = []

    def fraction(
        gpu_ids,
        reserve,
        share,
        measure = None,
    ):
        measured.append(measure)
        return 0.5

    def no_uuids(ids):
        raise AssertionError("nvidia-smi UUID matching for an AMD GPU")

    monkeypatch.setattr(managed_engine, "gpu_memory_fraction", fraction)
    monkeypatch.setattr(wsl_host, "guest_gpu_indices", no_uuids)
    monkeypatch.setattr(wsl_host, "guest", lambda *a, **k: "")
    monkeypatch.setattr(wsl_host, "to_guest_path", lambda path: "/mnt/c/" + Path(path).name)
    monkeypatch.setattr(wsl_host, "wsl_exe", lambda: "wsl.exe")
    monkeypatch.setattr(wsl_host, "distro_name", lambda: "Unsloth-Engines-test")
    engine = ManagedEngine("vllm")
    engine.context = 2048
    info = {"path": "/opt/unsloth/engines/vllm/env-abc", "host": "wsl", "accelerator": "rocm"}
    command, env = engine._wsl_command(info, {}, [0], None, False, "m", None, 8123)
    assert "HIP_VISIBLE_DEVICES=0" in command and "CUDA_VISIBLE_DEVICES=0" in command
    assert "HSA_ENABLE_DXG_DETECTION=1" in command
    # The rocprofiler stub has to load ahead of anything ROCm installs.
    assert "LD_LIBRARY_PATH=/opt/unsloth/lib" in command
    assert measured and measured[0] is not None


def test_rocm_lock_and_compat_name_the_index_the_profile_installs_from():
    import importlib.util

    release = install.PROFILES["vllm"]["rocm"]["releases"][0]
    folder = Path(install._REQUIREMENTS)
    assert release["index"] in (folder / f"{release['lock']}.in").read_text()
    spec = importlib.util.spec_from_file_location("engine_compat", folder / "engine_compat.py")
    engine_compat = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(engine_compat)
    assert engine_compat.TARGETS[release["lock"]] == (
        install.PROFILES["vllm"]["rocm"]["python"],
        install.PROFILES["vllm"]["rocm"]["glibc"][1],
        release["index"],
    )


def test_engine_port_stays_below_the_sglang_cap_even_when_the_os_offers_higher(monkeypatch):
    import socket as real_socket

    attempts = []

    class Socket(real_socket.socket):
        def bind(self, address):
            attempts.append(address[1])
            if address[1] == 0:
                raise AssertionError("asked the OS, which on Windows offers ports past 55535")
            # The first candidate is taken, as by another server.
            if len(attempts) == 1:
                raise OSError("in use")
            return super().bind(address)

    monkeypatch.setattr(managed_engine.socket, "socket", Socket)
    port = managed_engine._engine_port()
    assert 20000 <= port <= 55535 and port == attempts[-1] and len(attempts) == 2


_APU = {"name": "AMD Radeon(TM) 8060S Graphics", "gfx": "gfx1151", "dedicated_memory_bytes": 512 << 20}
_DISCRETE = {"name": "AMD Radeon RX 7900 XTX", "gfx": "gfx1151", "dedicated_memory_bytes": 24 << 30}


@pytest.mark.parametrize(
    ("unified", "records", "expected"),
    [
        # An APU: its small carve-out plus 80% of the host RAM Windows has available.
        (True, {1: _APU}, 512 + 0.8 * 81920),
        # A discrete card: only its own memory, whatever WSL adds from the host.
        (False, {1: _DISCRETE}, 24 * 1024),
        # Windows cannot say: no cap, the probe's own numbers stand.
        (True, {}, None),
    ],
)
def test_wsl_amd_memory_is_capped_at_what_windows_can_back(monkeypatch, unified, records, expected):
    import psutil
    import torch
    from core.inference import wsl_host
    from utils.hardware import hardware

    props = SimpleNamespace(name = "AMD Radeon(TM) 8060S Graphics", gcnArchName = "gfx1151")
    monkeypatch.setattr(torch.cuda, "device_count", lambda: 1)
    monkeypatch.setattr(torch.cuda, "get_device_properties", lambda ordinal: props)
    monkeypatch.setattr(hardware, "_torch_ordinal_physical_ids", lambda count: [0])
    monkeypatch.setattr(hardware, "_rocm_props_are_positively_unified", lambda p: unified)
    monkeypatch.setattr(hardware, "_windows_amd_adapter_records_or_none", lambda: records)
    monkeypatch.setattr(psutil, "virtual_memory", lambda: SimpleNamespace(available = 80 << 30))
    caps = managed_engine._wsl_amd_usable_mib([0])
    assert caps == (None if expected is None else [pytest.approx(expected)])

    monkeypatch.setattr(wsl_host, "guest", lambda *a, **k: "[[104495.0, 104422.0]]\n")
    rows = managed_engine.wsl_torch_memory_rows("/env/bin/python", {}, [0])
    free = 104422.0 if expected is None else min(104422.0, expected)
    assert rows == [(104495.0, pytest.approx(free))]


def test_state_files_are_replaced_past_a_reader_holding_them_open(monkeypatch, tmp_path):
    # Windows raises PermissionError while a status poll has the job file open.
    real_replace = install.os.replace
    calls = []

    def replace(source, target):
        calls.append(target)
        if len(calls) < 3:
            raise PermissionError(5, "Access is denied")
        return real_replace(source, target)

    monkeypatch.setattr(install.os, "replace", replace)
    monkeypatch.setattr(install.time, "sleep", lambda _: None)
    target = tmp_path / "vllm.job.json"
    install._atomic_json(target, {"state": "running"})
    assert json.loads(target.read_text()) == {"state": "running"} and len(calls) == 3
    assert [p.name for p in tmp_path.iterdir()] == ["vllm.job.json"]
