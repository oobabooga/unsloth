# SPDX-License-Identifier: AGPL-3.0-only
# Copyright 2026-present the Unsloth AI Inc. team. All rights reserved.

"""Opt-in serving environments. No engine packages are imported into Studio.

When Studio's own PyTorch and CUDA libraries are the ones an engine is locked to,
its environment runs on Studio's interpreter and holds only the packages Studio
lacks or pins differently; Studio's site-packages follow its own on sys.path.
Otherwise it is a complete isolated environment.

Installation is serialized across Studio processes. Environments are built at
their final paths (venv scripts contain absolute paths); only the active marker
is replaced. Runtime leases prevent removing an environment another Studio uses.
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import shutil
import subprocess

from utils.subprocess_compat import windows_hidden_subprocess_kwargs
import sys
import sysconfig
import tempfile
import threading
import time
import uuid
from collections import deque
from contextlib import contextmanager, nullcontext
from pathlib import Path

PROFILES = {
    "vllm": {
        "module": "vllm",
        "cuda": "cu130",
        "driver": 580,
        # FlashInfer fetches the trtllm kernels it uses on demand rather than the whole cubin wheel.
        # CUTLASS DSL loads its newest flavour the driver runs, and driver 580 runs CUDA 13.
        "omit": ("flashinfer-cubin", "nvidia-cutlass-dsl-libs-cu12"),
        # Newest first; each release pins one torch build (vLLM 0.27+ needs torch 2.13, 0.20-0.26 torch 2.11).
        "releases": (
            {"version": "0.30.0", "torch": "2.13.0", "lock": "vllm-linux-cu130-torch213"},
            {"version": "0.26.0", "torch": "2.11.0", "lock": "vllm-linux-cu130"},
        ),
        # AMD GPUs: vLLM's own ROCm build. It exists for CPython 3.12 only, brings its own torch and
        # links the host's ROCm libraries, so the environment is always isolated.
        "rocm": {
            "python": (3, 12),
            # The wheels are manylinux_2_39.
            "glibc": (2, 39),
            "rocm": (7, 2),
            # The offload targets vLLM's ROCm kernels are built for.
            "arches": (
                "gfx90a",
                "gfx942",
                "gfx950",
                "gfx1100",
                "gfx1101",
                "gfx1150",
                "gfx1151",
                "gfx1200",
                "gfx1201",
            ),
            "releases": (
                {
                    "version": "0.30.0",
                    "torch": "2.12.0",
                    "lock": "vllm-linux-rocm723",
                    "index": "https://wheels.vllm.ai/rocm/0.30.0/rocm723",
                },
            ),
        },
    },
    "sglang": {
        "module": "sglang",
        "cuda": "cu130",
        "driver": 580,
        # Excluded: outlines-core 0.1.26 has no py3.13 wheel; only --grammar-backend outlines needs it.
        "omit": ("outlines", "outlines-core", "flashinfer-cubin", "nvidia-cutlass-dsl-libs-cu12"),
        "releases": (
            {
                "version": "0.5.20",
                "torch": "2.13.0",
                "lock": "sglang-linux-cu130-torch213",
                # cuda-tile 1.6.0rc5 is sdist-only and SGLang never imports it.
                "omit": (
                    "outlines",
                    "outlines-core",
                    "flashinfer-cubin",
                    "nvidia-cutlass-dsl-libs-cu12",
                    "cuda-tile",
                ),
            },
            {"version": "0.5.17", "torch": "2.11.0", "lock": "sglang-linux-cu130"},
        ),
    },
}
PYTHON = (3, 13)
_BASE_PTH = "zz_unsloth_studio_base.pth"
_BASE_MODULE = "_unsloth_studio_base"
# Studio installs its own FlashInfer for NVFP4 diffusion; a jit-cache of another version fails the
# engine's flashinfer import ("flashinfer-jit-cache version ... does not match"), so the engine never sees them.
_STUDIO_BASE_SOURCE = """import pkgutil, site, sys

_HIDDEN = ("flashinfer", "flashinfer_jit_cache", "flashinfer_cubin")


class _Hidden:
    def __init__(self, finder):
        self._finder = finder

    def find_spec(self, name, target = None):
        if name.partition(".")[0] in _HIDDEN:
            return None
        spec = self._finder.find_spec(name, target)
        # A regular nvidia package here (Colab ships nvidia/__init__.py) would hide the engine's
        # own nvidia/ tree; as a namespace portion both are found, the engine's first.
        if name == "nvidia" and spec is not None and spec.submodule_search_locations:
            spec.loader = None
        return spec

    def invalidate_caches(self):
        self._finder.invalidate_caches()

    def iter_modules(self, prefix = ""):
        for info in pkgutil.iter_importer_modules(self._finder, prefix):
            if info[0][len(prefix):] not in _HIDDEN:
                yield info


for path in {paths!r}:
    site.addsitedir(path)
    for hook in sys.path_hooks:
        try:
            finder = hook(path)
        except ImportError:
            continue
        sys.path_importer_cache[path] = _Hidden(finder)
        break
"""
_REQUIREMENTS = Path(__file__).resolve().parents[2] / "requirements" / "engines"
_jobs: dict[str, dict] = {}
_cancels: dict[str, threading.Event] = {}
_lock = threading.RLock()


def engine_root() -> Path:
    from utils.paths.storage_roots import studio_root
    return studio_root() / "engines"


def rocm_host() -> bool:
    """Studio runs a ROCm PyTorch, so its GPU ids are HIP ids and engines use ROCm builds (on
    Windows inside Studio's WSL distro, which gets ROCm of its own)."""
    return platform.system() in ("Linux", "Windows") and "rocm" in (
        _studio_packages().get("torch") or ""
    )


def _release(engine: str) -> dict:
    """The release built on Studio's own torch, so the engine can share it; otherwise the newest,
    which then gets an isolated environment of its own."""
    from . import wsl_host

    releases = PROFILES[engine]["releases"]
    if wsl_host.active():
        # The WSL guest has no Studio torch to share, so it always gets the newest.
        return releases[0]
    torch = _studio_packages().get("torch")
    for release in releases:
        if _same_build(torch, release["torch"], PROFILES[engine]["cuda"]):
            return release
    return releases[0]


def profile(engine: str) -> dict:
    if engine not in PROFILES:
        raise ValueError("Unknown inference engine")
    rocm = PROFILES[engine].get("rocm")
    if rocm and rocm_host():
        # Every ROCm lock pins full local versions (torch==2.12.0+git6bbd260), so this label, which
        # PyTorch's own index appends to CUDA builds, never matches anything.
        return {
            "module": PROFILES[engine]["module"],
            "cuda": "rocm",
            "accelerator": "rocm",
            **rocm,
            **rocm["releases"][0],
        }
    return {**PROFILES[engine], "accelerator": "cuda", **_release(engine)}


def python_version(engine: str) -> tuple[int, int]:
    return profile(engine).get("python", PYTHON)


def _venv_python_args(engine: str) -> list[str]:
    """uv venv's interpreter choice. Triton compiles its driver module against the interpreter's
    Python.h at runtime, and Ubuntu's python3.12 has none without python3.12-dev, so the ROCm
    environment always gets a uv-managed CPython, which ships its headers."""
    version = "{}.{}".format(*python_version(engine))
    if profile(engine)["accelerator"] == "rocm":
        return ["--python", version, "--python-preference", "only-managed"]
    return [
        "--python",
        sys.executable if sys.version_info[:2] == python_version(engine) else version,
    ]


def requirements(engine: str) -> Path:
    return _REQUIREMENTS / f"{profile(engine)['lock']}.txt"


def profile_digest(engine: str) -> str:
    return hashlib.sha256(requirements(engine).read_bytes()).hexdigest()


def _normalize(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def _pins(engine: str) -> dict[str, tuple[str, str]]:
    """{name: (version, requirement line with its hashes)} from a uv-compiled lock."""
    entries: dict[str, tuple[str, str]] = {}
    name = None
    for line in requirements(engine).read_text(encoding = "utf-8").splitlines(keepends = True):
        match = re.match(r"([A-Za-z0-9][A-Za-z0-9_.\-]*)==([^\s;\\]+)", line)
        if match:
            name = _normalize(match.group(1))
            entries[name] = (match.group(2), line)
        elif name and line.startswith("    --hash="):
            entries[name] = (entries[name][0], entries[name][1] + line)
        else:
            name = None
    return entries


def _studio_site() -> list[str]:
    paths = sysconfig.get_paths()
    return sorted({paths["purelib"], paths["platlib"]})


_studio_seen: tuple[tuple, dict[str, str]] | None = None


def _studio_packages() -> dict[str, str]:
    """Distributions in Studio's own site-packages, excluding sidecars on sys.path. Status polls
    read this several times; the scan is redone only when an install changes a site directory."""
    global _studio_seen
    import importlib.metadata as metadata

    sites = _studio_site()
    key = tuple((site, os.stat(site).st_mtime_ns) for site in sites if os.path.isdir(site))
    if _studio_seen is None or _studio_seen[0] != key:
        _studio_seen = (
            key,
            {
                _normalize(dist.metadata["Name"]): dist.version
                for dist in metadata.distributions(path = sites)
            },
        )
    return dict(_studio_seen[1])


def _torch_runtime() -> set[str]:
    """Studio's torch and the native CUDA packages it loads, which one process can hold once."""
    import importlib.metadata as metadata
    from packaging.requirements import Requirement

    names, pending = {"torch"}, [("torch", ())]
    while pending:
        name, extras = pending.pop()
        dists = list(metadata.distributions(name = name, path = _studio_site()))
        for raw in dists[0].requires or [] if dists else []:
            requirement = Requirement(raw)
            child = _normalize(requirement.name)
            if (
                child not in names
                and child.startswith(("nvidia-", "cuda-toolkit", "triton"))
                and (
                    requirement.marker is None
                    or any(requirement.marker.evaluate({"extra": e}) for e in ("", *extras))
                )
            ):
                names.add(child)
                pending.append((child, tuple(requirement.extras)))
    return names


# nvcc's cudafe stubs need the crt headers of its own release, so mixing releases breaks
# FlashInfer's JIT (Colab: crt 13.4.59 with nvcc 13.0.88, "macro __cudaLaunch passed 2 arguments").
# Shared only when Studio holds every one at the locked version, else the engine brings all of them.
_TOOLCHAIN = frozenset({"nvidia-cuda-nvcc", "nvidia-cuda-crt", "nvidia-nvvm", "nvidia-cuda-cccl"})


def _same_build(installed: str | None, locked: str | None, cuda: str) -> bool:
    """PyTorch's index labels its wheels (2.11.0+cu130); the PyPI lock names the same build unlabelled."""
    return installed is not None and installed in (locked, f"{locked}+{cuda}")


def _compat_file(engine: str) -> dict:
    """engine_compat.py's output for the lock, or {} for a missing or stale file."""
    path = requirements(engine).with_suffix(".compat.json")
    try:
        data = json.loads(path.read_text(encoding = "utf-8"))
    except (OSError, ValueError):
        return {}
    return data if data.get("lock_sha256") == profile_digest(engine) else {}


def _compat(engine: str) -> dict[str, list[str]]:
    """What the locked packages require of each other."""
    return _compat_file(engine).get("requires", {})


def download_bytes(engine: str) -> int | None:
    """Wheel bytes an install of the selected release downloads: the lock minus what Studio provides."""
    from . import wsl_host

    sizes = _compat_file(engine).get("sizes")
    if not sizes:
        return None
    wsl = wsl_host.active()
    # A WSL engine is always a complete environment, plus the distro and uv on first setup.
    provided = {} if wsl else install_plan(engine)["provided"]
    omit = set(profile(engine).get("omit", ()))
    total = sum(
        size or 0 for name, size in sizes.items() if name not in provided and name not in omit
    )
    if wsl and not wsl_host.summary().get("distro"):
        total += wsl_host.ROOTFS["size"] + wsl_host.UV["size"]
    if wsl and profile(engine)["accelerator"] == "rocm" and not wsl_host.rocm_recorded():
        # ROCm's apt packages come too, and their size is not known here.
        return None
    return total


# Not engine dependencies, so absent from the compat file: the configs Studio's adapters build
# (Int8WeightOnlyConfig and friends) use TorchAO 0.17's API, and 0.18 removed their version 1.
_ADAPTER_REQUIRES = {"torchao": ["==0.17.0"]}


def _adapter_accepts(name: str, version: str) -> bool:
    from packaging.specifiers import SpecifierSet
    return all(
        SpecifierSet(spec).contains(version, prereleases = True)
        for spec in _ADAPTER_REQUIRES.get(name, ())
    )


def _reusable(
    engine: str, lock: dict, studio: dict[str, str], provided: dict[str, str]
) -> dict[str, str]:
    """Studio's own versions every engine dependency accepts, kept only while their own
    requirements still hold against what the engine will see."""
    from packaging.requirements import Requirement
    from packaging.specifiers import SpecifierSet
    import importlib.metadata as metadata

    compat = _compat(engine)
    if not compat:
        return {}
    hidden = {"flashinfer-python", "flashinfer-jit-cache", "flashinfer-cubin", *_TOOLCHAIN}
    reuse = {
        name: studio[name]
        for name in lock
        if name in studio
        and name not in provided
        and name not in hidden
        and _adapter_accepts(name, studio[name])
        and all(
            SpecifierSet(spec).contains(studio[name], prereleases = True)
            for spec in compat.get(name, ())
        )
    }
    requires = {}
    for name in reuse:
        dists = list(metadata.distributions(name = name, path = _studio_site()))
        requires[name] = [Requirement(r) for r in (dists[0].requires or [])] if dists else None
    while True:
        seen = {name: version for name, (version, _) in lock.items()} | provided | reuse
        drop = {
            name
            for name in reuse
            if requires[name] is None
            or any(
                _normalize(r.name) in seen
                and not r.specifier.contains(seen[_normalize(r.name)], prereleases = True)
                for r in requires[name]
                if r.marker is None or r.marker.evaluate({"extra": ""})
            )
        }
        if not drop:
            return reuse
        for name in drop:
            del reuse[name]


def install_plan(engine: str) -> dict:
    """Split the lock into packages Studio already provides and the ones to install."""
    from packaging.specifiers import SpecifierSet

    lock = _pins(engine)
    studio = _studio_packages()
    cuda = profile(engine)["cuda"]
    compat = _compat(engine)
    runtime = _torch_runtime()

    def fits(name: str) -> bool:
        if _same_build(studio.get(name), lock.get(name, (None,))[0], cuda):
            return True
        # Torch is the exact build; a CUDA library torch takes as a range (nvjitlink) only has to
        # satisfy every locked package's requirement, since the engine then loads Studio's copy.
        specs = compat.get(name)
        return bool(
            name != "torch"
            and name not in _TOOLCHAIN
            and name in lock
            and name in studio
            and specs
            and all(SpecifierSet(spec).contains(studio[name], prereleases = True) for spec in specs)
        )

    shared = (
        profile(engine)["accelerator"] == "cuda"
        and sys.implementation.name == "cpython"
        and sys.version_info[:2] == PYTHON
        and "torch" in studio
        and all(fits(name) for name in runtime - _TOOLCHAIN)
    )
    provided = {
        name: studio[name]
        for name, (version, _) in lock.items()
        if shared
        and (_same_build(studio.get(name), version, cuda) or (name in runtime and fits(name)))
    }
    if not all(name in provided for name in _TOOLCHAIN & lock.keys()):
        provided = {name: version for name, version in provided.items() if name not in _TOOLCHAIN}
    if shared:
        provided |= _reusable(engine, lock, studio, provided)
    return {
        "shared": shared,
        "provided": provided,
        "requirements": "".join(line for name, (_, line) in lock.items() if name not in provided),
    }


def _cuda_trees(env: Path, shared: bool) -> list[Path]:
    sites = [env / "lib" / "python{}.{}".format(*PYTHON) / "site-packages"]
    sites += [Path(path) for path in _studio_site()] if shared else []
    return [site / "nvidia" / "cu13" for site in sites if (site / "nvidia" / "cu13").is_dir()]


def link_cuda_home(env: Path, shared: bool) -> None:
    """FlashInfer JIT-compiles some kernels; this CUDA_HOME is the locked pip nvcc, since a host may
    have only the driver, or a toolkit of another CUDA major."""
    home = env / "cuda"
    (home / "lib64").mkdir(parents = True, exist_ok = True)
    trees = _cuda_trees(env, shared)
    # One include tree, the engine's entries first: a Studio header such as curand_kernel.h
    # quote-includes crt/ from beside itself, which then resolves to the engine's crt.
    include = home / "include"
    if include.is_symlink():
        include.unlink()
    include.mkdir(exist_ok = True)
    for tree in trees:
        if (tree / "include").is_dir():
            for entry in (tree / "include").iterdir():
                if not (include / entry.name).is_symlink():
                    (include / entry.name).symlink_to(entry)
    for name, link in (
        ("bin", home / "bin"),
        ("nvvm", home / "nvvm"),
    ):
        source = next(
            (
                tree / name
                for tree in trees
                if (tree / name / ("nvcc" if name == "bin" else "")).exists()
            ),
            None,
        )
        if source is not None and not link.is_symlink():
            link.symlink_to(source)
    # nvcc links -lcudart, and the runtime wheel ships only the versioned soname.
    cudart = next(
        (
            tree / "lib" / "libcudart.so.13"
            for tree in trees
            if (tree / "lib" / "libcudart.so.13").exists()
        ),
        None,
    )
    if cudart is not None and not (home / "lib64" / "libcudart.so").is_symlink():
        (home / "lib64" / "libcudart.so").symlink_to(cudart)


def cuda_environment(info: dict) -> dict[str, str]:
    """CUDA_HOME for the engine's JIT compiles; CPATH is its merged include tree for other compilers."""
    if info.get("host") == "wsl":
        return dict(info.get("cuda_environment") or {})
    env = Path(info["path"])
    if not (env / "cuda" / "bin" / "nvcc").exists():
        return {}
    return {"CUDA_HOME": str(env / "cuda"), "CPATH": str(env / "cuda" / "include")}


def stale(info: dict) -> bool:
    """True when Studio no longer provides what a shared engine environment was checked with."""
    if not info.get("shared"):
        return False
    if info.get("python") != platform.python_version():
        return True
    studio = _studio_packages()
    return any(
        studio.get(name) != version or not _adapter_accepts(name, version)
        for name, version in info.get("provided", {}).items()
    )


# Runs in the engine's interpreter, so it checks both layers as the engine imports them.
_CHECK = r"""
import importlib.metadata as metadata, json, re, sys
from packaging.requirements import Requirement

def normalize(name):
    return re.sub(r"[-_.]+", "-", name).lower()

omitted = set(sys.argv[2].split(",")) - {"", "-"}
cuda = sys.argv[3]
provided = json.loads(sys.argv[4]) if len(sys.argv) > 4 else {}
problems = []
for line in open(sys.argv[1], encoding = "utf-8"):
    match = re.match(r"([A-Za-z0-9][A-Za-z0-9_.\-]*)==([^\s;\\]+)", line)
    if not match:
        continue
    name, version = match.groups()
    try:
        found = metadata.version(name)
    except metadata.PackageNotFoundError:
        found = None
    if found not in (version, f"{version}+{cuda}", provided.get(normalize(name))):
        problems.append(f"{name}=={version} is required, found {found}")
        continue
    for raw in metadata.requires(name) or []:
        requirement = Requirement(raw)
        if normalize(requirement.name) in omitted or (
            requirement.marker and not requirement.marker.evaluate({"extra": ""})
        ):
            continue
        try:
            have = metadata.version(requirement.name)
        except metadata.PackageNotFoundError:
            have = None
        if have is None or not requirement.specifier.contains(have, prereleases = True):
            problems.append(f"{name} requires {requirement}, found {have}")
if problems:
    sys.exit("\n".join(problems))
"""


def _omit_argument(engine: str) -> str:
    """_CHECK's omitted packages; "-" for none, since an empty argument may not survive wsl.exe."""
    return ",".join(profile(engine).get("omit", ())) or "-"


def _extra_index_args(engine: str) -> list[str]:
    """The release's own wheel index beside PyPI. Every locked file is hash-pinned, so the strategy
    only decides where a name is looked up, never which bytes are accepted."""
    index = profile(engine).get("index")
    return ["--extra-index-url", index, "--index-strategy", "unsafe-best-match"] if index else []


def _smoke_source(engine: str) -> str:
    """Imports the engine and the quantization stacks Studio's adapters use, on the locked torch."""
    torch_version = _pins(engine)["torch"][0].split("+")[0]
    runtime = (
        "assert torch.version.hip, 'not a ROCm build'"
        if profile(engine)["accelerator"] == "rocm"
        else "assert torch.version.cuda == '13.0'"
    )
    return (
        f"import {profile(engine)['module']}; import torch; import bitsandbytes; import torchao\n"
        f"assert torch.__version__.split('+')[0] == {torch_version!r}\n"
        f"{runtime}\n"
    )


_gpu_rows: dict = {}
_gpu_rows_lock = threading.Lock()
_gpu_probe_lock = threading.Lock()
_PENDING = object()


def _cached_rows(gpu_id):
    with _gpu_rows_lock:
        cached = _gpu_rows.get(gpu_id)
    if cached is not None and (cached[1] is not None or time.monotonic() < cached[0]):
        return cached[1]
    return _PENDING


def _probe_rows(gpu_id):
    rows = None
    try:
        from utils.hardware.nvidia import _nvidia_smi_executable
        result = subprocess.run(
            [
                _nvidia_smi_executable(),
                "--query-gpu=driver_version,compute_cap",
                "--format=csv,noheader",
                *(["--id", str(gpu_id)] if gpu_id is not None else []),
            ],
            capture_output = True,
            **windows_hidden_subprocess_kwargs(),
            text = True,
            encoding = "utf-8",
            errors = "replace",
            timeout = 60,
        )
        if result.returncode == 0:
            rows = [line.split(",") for line in result.stdout.strip().splitlines()]
    except (OSError, subprocess.TimeoutExpired):
        pass
    with _gpu_rows_lock:
        _gpu_rows[gpu_id] = (time.monotonic() + 300, rows)
    return rows


def _driver_rows(gpu_id: int | None, *, wait: bool = True):
    """nvidia-smi rows, cached per process; a failure is retried after 5 minutes. A loaded
    multi-GPU host can take over 20s to answer, so ``wait=False`` (status polls) never runs the
    probe in the caller: it starts one in the background and returns ``_PENDING``."""
    rows = _cached_rows(gpu_id)
    if rows is not _PENDING:
        return rows
    if not wait:
        if _gpu_probe_lock.acquire(blocking = False):

            def probe():
                try:
                    _probe_rows(gpu_id)
                finally:
                    _gpu_probe_lock.release()

            threading.Thread(target = probe, daemon = True).start()
        return _PENDING
    with _gpu_probe_lock:
        rows = _cached_rows(gpu_id)
        return _probe_rows(gpu_id) if rows is _PENDING else rows


ROCM_HOME = Path("/opt/rocm")
# What vLLM's ROCm torch and kernels load from the host (their RUNPATH is /opt/rocm/lib).
_ROCM_LIBRARIES = (
    "libamdhip64.so.7",
    "libhiprtc.so.7",
    "libMIOpen.so.1",
    "librocblas.so.5",
    "libhipblas.so.3",
    "libhipblaslt.so.1",
    "libhipfft.so.0",
    "libhiprand.so.1",
    "libhipsparse.so.4",
    "libhipsparselt.so.0",
    "libhipsolver.so.1",
    "librocsolver.so.0",
    "librccl.so.1",
    "librocprofiler-sdk.so.1",
    # rocprofiler-sdk loads it but does not depend on its package (hsa-amd-aqlprofile).
    "libhsa-amd-aqlprofile64.so.1",
    "libroctx64.so.4",
)
# Host libraries the ROCm torch links outside ROCm; Ubuntu 24.04 ships Open MPI 4 as libopenmpi3t64.
_SYSTEM_LIBRARIES = ("libmpi.so.40", "libmpi_cxx.so.40", "libnuma.so.1")


def _host_rocm_version() -> tuple[int, ...] | None:
    try:
        text = (ROCM_HOME / ".info" / "version").read_text(encoding = "utf-8")
    except OSError:
        return None
    match = re.match(r"\s*(\d+)\.(\d+)(?:\.(\d+))?", text)
    return tuple(int(part) for part in match.groups() if part is not None) if match else None


def _system_library_present(soname: str) -> bool:
    from utils.hardware.amd import _dynamic_loader_search_dirs
    return any(
        os.path.isfile(os.path.join(folder, soname)) for folder in _dynamic_loader_search_dirs()
    )


_rocm_arches: dict[int, str] | None = None


def _rocm_gpu_arches() -> dict[int, str]:
    """{physical GPU id: the gfx target it presents} from Studio's own ROCm torch, read once. The
    engine inherits Studio's environment, so an HSA_OVERRIDE_GFX_VERSION spoof applies to both."""
    global _rocm_arches
    if _rocm_arches is not None:
        return dict(_rocm_arches)
    arches: dict[int, str] = {}
    try:
        import torch
        from utils.hardware.hardware import _props_gfx_arch, _torch_ordinal_physical_ids
        if torch.cuda.is_available():
            count = torch.cuda.device_count()
            physical = _torch_ordinal_physical_ids(count) or list(range(count))
            for ordinal, gpu_id in enumerate(physical[:count]):
                arch = _props_gfx_arch(torch.cuda.get_device_properties(ordinal))
                if arch:
                    arches[gpu_id] = arch
    except Exception:
        return {}
    _rocm_arches = arches
    return dict(arches)


def _rocm_support_reason(engine: str, gpu_id: int | None) -> str | None:
    from . import wsl_host

    name = {"vllm": "vLLM", "sglang": "SGLang"}[engine]
    rocm = PROFILES[engine].get("rocm")
    if rocm is None:
        return f"{name} currently runs only on NVIDIA GPUs. vLLM supports AMD GPUs."
    # On Windows the engine's ROCm is the one installing it puts in Studio's own WSL distro.
    reason = wsl_host.support_reason() if wsl_host.active() else _rocm_linux_reason(name, rocm)
    if reason:
        return reason
    arches = _rocm_gpu_arches()
    if not arches:
        return "Studio cannot see an AMD GPU through ROCm."
    if gpu_id is None:
        seen = set(arches.values())
    elif gpu_id in arches:
        seen = {arches[gpu_id]}
    else:
        # An id Studio cannot map to a torch ordinal: vLLM itself refuses a GPU it has no kernels for.
        return None
    if seen.isdisjoint(rocm["arches"]):
        found = f" This GPU is {next(iter(seen))}." if len(seen) == 1 else ""
        return f"{name}'s ROCm build supports AMD GPUs with {', '.join(rocm['arches'])}.{found}"
    return None


def _rocm_linux_reason(name: str, rocm: dict) -> str | None:
    """What the host must provide: vLLM's ROCm wheels link the system ROCm in /opt/rocm."""
    if platform.machine() != "x86_64":
        return "Managed engines currently require Linux x86_64 or Windows x64."
    glibc = rocm["glibc"]
    if tuple(int(x) for x in (platform.libc_ver()[1] or "0.0").split(".")[:2]) < glibc:
        return f"{name} on AMD GPUs requires glibc {glibc[0]}.{glibc[1]} or newer, such as Ubuntu 24.04."
    floor = ".".join(str(part) for part in rocm["rocm"])
    version = _host_rocm_version()
    if version is None or version[:2] < rocm["rocm"]:
        found = f" (found {'.'.join(map(str, version))})" if version else ""
        return f"{name} on AMD GPUs requires ROCm {floor} or newer installed in {ROCM_HOME}{found}."
    missing = [lib for lib in _ROCM_LIBRARIES if not (ROCM_HOME / "lib" / lib).is_file()]
    if missing:
        return (
            f"The ROCm installation in {ROCM_HOME} is missing {', '.join(missing)}. "
            "Install the full ROCm package (for example 'sudo apt install rocm'), then retry."
        )
    missing = [lib for lib in _SYSTEM_LIBRARIES if not _system_library_present(lib)]
    if missing:
        return (
            f"{name} on AMD GPUs needs {', '.join(missing)}. Install Open MPI and libnuma "
            "(on Ubuntu 24.04: sudo apt install libopenmpi3t64 libnuma1), then retry."
        )
    if not (os.environ.get("CC") or shutil.which("gcc") or shutil.which("clang")):
        # Triton builds its HIP driver module when the engine first compiles a kernel.
        return (
            f"{name} on AMD GPUs needs a C compiler (on Ubuntu: sudo apt install gcc), then retry."
        )
    return None


def support_reason(
    engine: str = "vllm",
    gpu_id: int | None = None,
    *,
    wait: bool = True,
) -> str | None:
    from . import wsl_host

    if rocm_host():
        return _rocm_support_reason(engine, gpu_id)
    if wsl_host.active():
        # WSL itself is not a prerequisite: installing the engine sets it up.
        reason = wsl_host.support_reason()
        if reason:
            return reason
    elif platform.system() != "Linux" or platform.machine() != "x86_64":
        return "Managed engines currently require Linux x86_64 or Windows x64."
    else:
        glibc = profile(engine).get("glibc", (2, 34))
        if tuple(int(x) for x in (platform.libc_ver()[1] or "0.0").split(".")[:2]) < glibc:
            return f"{engine} requires glibc {glibc[0]}.{glibc[1]} or newer."
    rows = _driver_rows(gpu_id, wait = wait)
    if rows is _PENDING:
        return "Checking for a supported NVIDIA GPU."
    try:
        if any(
            int(row[0].strip().split(".")[0]) >= profile(engine)["driver"] and float(row[1]) >= 8.0
            for row in rows or ()
            if len(row) == 2
        ):
            return None
    except ValueError:
        pass
    return f"Requires an NVIDIA GPU with compute capability 8.0 or newer and driver {profile(engine)['driver']} or newer."


def _atomic_json(path: Path, data: dict) -> None:
    tmp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        tmp.write_text(json.dumps(data), encoding = "utf-8")
        # Windows refuses to replace a file while another handle has it open, and status polls read
        # the job file every few seconds: an install failed on "[WinError 5] Access is denied" here.
        for attempt in range(100):
            try:
                os.replace(tmp, path)
                break
            except PermissionError:
                if attempt == 99:
                    raise
                time.sleep(0.02)
    finally:
        tmp.unlink(missing_ok = True)


@contextmanager
def engine_lease(
    engine: str,
    *,
    exclusive: bool = False,
    wait: float = 1.0,
):
    """``wait=0`` for status probes: real takers retry so a probe's instant hold never fails them."""
    profile(engine)
    lock, unlock = _file_lock()

    root = engine_root()
    root.mkdir(parents = True, exist_ok = True)
    with (root / f"{engine}.lock").open("a", encoding = "utf-8") as handle:
        deadline = time.monotonic() + wait
        while True:
            try:
                lock(handle, exclusive)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise RuntimeError(
                        "This engine is running or being changed in another Studio instance."
                    ) from None
                time.sleep(0.05)
        try:
            yield
        finally:
            unlock(handle)


def _file_lock():
    """(lock, unlock) raising BlockingIOError when held: flock, or LockFileEx on Windows, which
    also has shared and exclusive modes (msvcrt.locking is exclusive only)."""
    if os.name != "nt":
        import fcntl
        return (
            lambda handle, exclusive: fcntl.flock(
                handle, (fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH) | fcntl.LOCK_NB
            ),
            lambda handle: fcntl.flock(handle, fcntl.LOCK_UN),
        )
    import ctypes
    import msvcrt
    from ctypes import wintypes

    class Overlapped(ctypes.Structure):
        _fields_ = [
            ("Internal", ctypes.c_void_p),
            ("InternalHigh", ctypes.c_void_p),
            ("Offset", wintypes.DWORD),
            ("OffsetHigh", wintypes.DWORD),
            ("hEvent", wintypes.HANDLE),
        ]

    kernel32 = ctypes.WinDLL("kernel32", use_last_error = True)

    def lock(handle, exclusive):
        flags = 0x1 | (
            0x2 if exclusive else 0
        )  # LOCKFILE_FAIL_IMMEDIATELY | LOCKFILE_EXCLUSIVE_LOCK
        if not kernel32.LockFileEx(
            wintypes.HANDLE(msvcrt.get_osfhandle(handle.fileno())),
            flags,
            0,
            1,
            0,
            ctypes.byref(Overlapped()),
        ):
            raise BlockingIOError(ctypes.get_last_error(), "lock held")

    def unlock(handle):
        kernel32.UnlockFileEx(
            wintypes.HANDLE(msvcrt.get_osfhandle(handle.fileno())),
            0,
            1,
            0,
            ctypes.byref(Overlapped()),
        )

    return lock, unlock


def installed(engine: str) -> dict | None:
    profile(engine)
    root = engine_root() / engine
    if root.is_symlink():
        return None
    try:
        info = json.loads((root / "active.json").read_text(encoding = "utf-8"))
        directory = info["directory"]
        if (
            not isinstance(directory, str)
            or not directory.startswith("env-")
            or Path(directory).name != directory
        ):
            return None
        if info.get("host") == "wsl":
            # Lives in the distro; checking it would boot WSL on every status poll, so the load checks.
            from .wsl_host import GUEST_ROOT
            return {**info, "path": f"{GUEST_ROOT}/engines/{engine}/{directory}"}
        path = root / directory
        if path.is_symlink() or not (path / "bin" / "python").is_file():
            return None
        return {**info, "path": str(path)}
    except (OSError, ValueError, KeyError, TypeError):
        return None


def status(engine: str) -> dict:
    info = installed(engine)
    try:
        job = json.loads((engine_root() / f"{engine}.job.json").read_text(encoding = "utf-8"))
    except (OSError, ValueError):
        job = {"state": "idle", "phase": None, "message": ""}
    if job.get("state") == "running":
        try:
            with engine_lease(engine, wait = 0):
                job = {
                    "state": "error",
                    "phase": None,
                    "message": "Installation was interrupted. Retry to repair it.",
                }
        except (RuntimeError, ImportError):
            pass
    outdated = bool(info and stale(info))
    in_use = False
    if info and job.get("state") != "running":
        try:
            with engine_lease(engine, exclusive = True, wait = 0):
                pass
        except RuntimeError:
            in_use = True
        except ImportError:
            pass
    return {
        "engine": engine,
        "version": profile(engine)["version"],
        "accelerator": profile(engine)["accelerator"],
        "installed_version": info.get("version") if info else None,
        "installed": info is not None,
        "in_use": in_use,
        "current": bool(
            info and info.get("profile_digest") == profile_digest(engine) and not outdated
        ),
        "restored": bool(info and info.get("restored") and not outdated),
        "shared": bool(info and info.get("shared")),
        "can_rollback": bool(
            info and isinstance(info.get("previous"), dict) and not stale(info["previous"])
        ),
        "unsupported_reason": support_reason(engine, wait = False),
        # Only priced while an install or update is on offer: the plan reads Studio's packages.
        "download_bytes": None
        if info and info.get("profile_digest") == profile_digest(engine) and not outdated
        else _safe_download_bytes(engine),
        "additional_disk_bytes": None,
        "job": job,
        **_host_status(),
    }


def _host_status() -> dict:
    from . import wsl_host
    return {"host": "wsl", "wsl": wsl_host.summary()} if wsl_host.active() else {"host": "local"}


def _safe_download_bytes(engine: str) -> int | None:
    try:
        return download_bytes(engine)
    except Exception:
        return None


def _update(engine: str, **values) -> None:
    with _lock:
        job = _jobs.setdefault(engine, {})
        if "phase" in values and values["phase"] != job.get("phase"):
            values.setdefault("activity", "")
        job.update(values)
        root = engine_root()
        root.mkdir(parents = True, exist_ok = True)
        _atomic_json(root / f"{engine}.job.json", _jobs[engine])


def driver_library_path(env: dict[str, str]) -> str | None:
    """The LD_LIBRARY_PATH entries that hold the NVIDIA driver. Hosts such as Colab keep libcuda
    outside the loader cache and reach it only this way; every other entry is dropped, so a CUDA
    runtime Studio's environment points at never shadows the engine's own."""
    entries = [
        entry
        for entry in env.get("LD_LIBRARY_PATH", "").split(os.pathsep)
        if entry and os.path.isabs(entry) and (Path(entry) / "libcuda.so.1").exists()
    ]
    return os.pathsep.join(entries) or None


def install_environment() -> dict[str, str]:
    # Do not inherit Studio's resolver overrides, Python overlays or credentials.
    env = {
        key: value
        for key, value in os.environ.items()
        if key
        in {
            "HOME",
            "PATH",
            "LANG",
            "LC_ALL",
            "TMPDIR",
            "SSL_CERT_FILE",
            "SSL_CERT_DIR",
            "HTTPS_PROXY",
            "HTTP_PROXY",
            "NO_PROXY",
            "https_proxy",
            "http_proxy",
            "no_proxy",
        }
    }
    from utils.paths.storage_roots import cache_root

    recorded_cache = None
    try:
        raw = (cache_root() / "uv-cache-dir").read_bytes().decode("utf-8-sig")
        raw = raw.removesuffix("\n").removesuffix("\r")
        if Path(raw).is_absolute() and Path(raw).is_dir() and os.access(raw, os.W_OK):
            recorded_cache = raw
    except (OSError, UnicodeError, ValueError):
        pass
    env["UV_CACHE_DIR"] = (
        os.environ.get("UV_CACHE_DIR") or recorded_cache or str(cache_root() / "uv")
    )
    # The install checks import the engine, whose device detection needs the driver.
    if driver := driver_library_path(dict(os.environ)):
        env["LD_LIBRARY_PATH"] = driver
    env["PYTHONNOUSERSITE"] = "1"
    env["UV_NO_CONFIG"] = "1"
    env["UV_CONCURRENT_DOWNLOADS"] = "4"
    env["UV_HTTP_RETRIES"] = "5"
    # uv's clone fallback can hardlink: opt into clones only after probing both filesystems.
    env["UV_LINK_MODE"] = "copy"
    return env


def package_link_mode(destination: Path) -> str:
    """Probe Linux reflinks across the actual install paths, without keeping files."""
    import fcntl

    cache = Path(install_environment()["UV_CACHE_DIR"])
    try:
        cache.mkdir(parents = True, exist_ok = True)
        with (
            tempfile.TemporaryFile(dir = cache) as source,
            tempfile.TemporaryFile(dir = destination) as target,
        ):
            source.write(b"Studio package clone probe")
            source.flush()
            fcntl.ioctl(target.fileno(), 0x40049409, source.fileno())
        return "clone"
    except OSError:
        return "copy"


def _run(
    engine: str,
    argv: list[str],
    cancel: threading.Event,
    env: dict | None = None,
) -> None:
    from utils.process_lifetime import (
        adopt_pid,
        child_popen_kwargs,
        terminate_pid,
        forget_pid,
        spawn_on_lifetime_thread,
        is_process_shutting_down,
    )

    tail: deque[str] = deque(maxlen = 20)
    if cancel.is_set() or is_process_shutting_down():
        raise RuntimeError("Installation cancelled or Studio is shutting down.")
    proc = spawn_on_lifetime_thread(
        lambda: subprocess.Popen(
            argv,
            env = install_environment() if env is None else env,
            stdout = subprocess.PIPE,
            stderr = subprocess.STDOUT,
            text = True,
            encoding = "utf-8",
            errors = "replace",
            start_new_session = True,
            # A windowed Studio has no console; wsl.exe would otherwise open one.
            creationflags = 0x08000000 if sys.platform == "win32" else 0,
            **child_popen_kwargs(),
        )
    )
    adopt_pid(proc.pid)

    def drain():
        from utils.log_redaction import redact_log_text

        last_update = 0.0
        activity = ""
        for line in proc.stdout:
            line = redact_log_text(line.rstrip())[-1000:]
            if not line:
                continue
            tail.append(line)
            if line.startswith(
                (
                    "Downloading ",
                    "Downloaded ",
                    "Resolved ",
                    "Prepared ",
                    "Installed ",
                    "Uninstalled ",
                )
            ):
                activity = line
            now = time.monotonic()
            if now - last_update >= 1:
                _update(engine, activity = activity, log = list(tail))
                last_update = now
        if tail:
            _update(engine, activity = activity, log = list(tail))

    reader = threading.Thread(target = drain, daemon = True)
    deadline = time.monotonic() + 3600
    try:
        # A shutdown sweep may have finished between spawn and adoption; recheck even on clean exit.
        if is_process_shutting_down() or cancel.is_set():
            raise RuntimeError("Installation cancelled or Studio is shutting down.")
        reader.start()
        while proc.poll() is None:
            if (engine_root() / f"{engine}.cancel").exists():
                cancel.set()
            if is_process_shutting_down():
                cancel.set()
            if cancel.wait(0.2):
                raise RuntimeError("Installation cancelled.")
            if time.monotonic() > deadline:
                raise RuntimeError(
                    "Installation timed out. Retry when the connection is available."
                )
        reader.join(timeout = 2)
        if proc.returncode:
            raise RuntimeError("Engine installation failed. " + "\n".join(tail))
    finally:
        if proc.poll() is None:
            terminate_pid(proc.pid, timeout = 5, owner_verified = True)
        proc.wait(timeout = 10)
        forget_pid(proc.pid)
        if reader.ident is not None:
            reader.join(timeout = 2)
        proc.stdout.close()


def _install(
    engine: str,
    cancel: threading.Event,
    lease = None,
) -> None:
    destination = None
    try:
        with nullcontext() if lease is not None else engine_lease(engine, exclusive = True):
            _update(engine, state = "running", phase = "creating", message = "Preparing installation")
            reason = support_reason(engine)
            if reason:
                raise RuntimeError(reason)
            from . import wsl_host

            if wsl_host.active():
                _install_wsl(engine, cancel)
                return
            uv = shutil.which("uv")
            if uv is None:
                raise RuntimeError("uv is unavailable. Repair the Studio installation and retry.")
            root = engine_root() / engine
            if root.is_symlink():
                raise RuntimeError("Engine directory must not be a symbolic link.")
            root.mkdir(parents = True, exist_ok = True)
            digest = profile_digest(engine)
            destination = root / ("env-" + uuid.uuid4().hex)
            plan = install_plan(engine)
            _update(
                engine,
                phase = "creating",
                message = "Preparing an engine environment on Studio's PyTorch"
                if plan["shared"]
                else "Preparing an isolated Python environment",
            )
            _run(engine, [uv, "venv", *_venv_python_args(engine), str(destination)], cancel)
            python = str(destination / "bin" / "python")
            packages = destination / "engine-requirements.txt"
            packages.write_text(plan["requirements"], encoding = "utf-8")
            _update(
                engine, phase = "installing", message = "Downloading and installing engine packages"
            )
            _run(
                engine,
                [
                    uv,
                    "pip",
                    "sync",
                    "--python",
                    python,
                    "--link-mode",
                    package_link_mode(destination),
                    "--require-hashes",
                    "--only-binary",
                    ":all:",
                    "--index-url",
                    "https://pypi.org/simple",
                    *_extra_index_args(engine),
                    str(packages),
                ],
                cancel,
            )
            if plan["shared"]:
                # Appended after the engine's own site-packages, so its pins win.
                site = destination / "lib" / "python{}.{}".format(*PYTHON) / "site-packages"
                (site / f"{_BASE_MODULE}.py").write_text(
                    _STUDIO_BASE_SOURCE.format(paths = _studio_site()), encoding = "utf-8"
                )
                (site / _BASE_PTH).write_text(f"import {_BASE_MODULE}\n", encoding = "utf-8")
            if profile(engine)["accelerator"] == "cuda":
                link_cuda_home(destination, plan["shared"])
            _update(engine, phase = "checking", message = "Checking the installed engine")
            _run(
                engine,
                [
                    python,
                    "-I",
                    "-c",
                    _CHECK,
                    str(requirements(engine)),
                    _omit_argument(engine),
                    profile(engine)["cuda"],
                    json.dumps(plan["provided"]),
                ],
                cancel,
            )
            _run(engine, [python, "-I", "-c", _smoke_source(engine)], cancel)
            from .engine_adapters import ADAPTERS

            module = ADAPTERS[engine].module
            _run(engine, [python, "-I", "-m", module, "--help"], cancel)
            if (engine_root() / f"{engine}.cancel").exists():
                cancel.set()
            if cancel.is_set():
                raise RuntimeError("Installation cancelled.")
            prior = installed(engine)
            if profile_digest(engine) != digest:
                raise RuntimeError(
                    "Studio's engine profile changed during installation. Retry to use the updated profile."
                )
            _atomic_json(
                root / "active.json",
                {
                    "directory": destination.name,
                    "version": profile(engine)["version"],
                    "profile_digest": digest,
                    "accelerator": profile(engine)["accelerator"],
                    "shared": plan["shared"],
                    "python": platform.python_version(),
                    "provided": plan["provided"],
                    "studio_prefix": sys.prefix,
                    "previous_directory": prior["directory"] if prior else None,
                    "previous": {
                        k: v
                        for k, v in prior.items()
                        if k not in ("path", "previous", "previous_directory")
                    }
                    if prior
                    else None,
                },
            )
            # Keep the active env and one previous version; every runtime lease (any Studio) is excluded.
            keep = {destination.name, prior["directory"] if prior else None}
            for old in root.glob("env-*"):
                if old.name not in keep and old.is_dir() and not old.is_symlink():
                    shutil.rmtree(old, ignore_errors = True)
            destination = None
            _record_manifest(engine)
            _update(engine, state = "success", phase = "ready", message = "Engine installed")
    except Exception as exc:
        from .wsl_host import Waiting
        _update(
            engine,
            state = "waiting"
            if isinstance(exc, Waiting)
            else "cancelled"
            if cancel.is_set()
            else "error",
            phase = None,
            message = str(exc),
        )
    finally:
        if destination is not None:
            shutil.rmtree(destination, ignore_errors = True)
        if lease is not None:
            lease.__exit__(None, None, None)


# Runs in the engine's interpreter inside WSL: the non-shared half of link_cuda_home and
# managed_engine._deep_gemm_unloadable, whose paths Windows cannot inspect.
_GUEST_FINALIZE = r"""
import json, sys
from pathlib import Path

env = Path(sys.argv[1])
site = next(env.glob("lib/python3.*/site-packages"))
tree = site / "nvidia" / "cu13"
home = env / "cuda"
(home / "lib64").mkdir(parents = True, exist_ok = True)
for name in ("bin", "nvvm", "include"):
    if (tree / name).exists() and not (home / name).is_symlink():
        (home / name).symlink_to(tree / name)
cudart = tree / "lib" / "libcudart.so.13"
if cudart.exists() and not (home / "lib64" / "libcudart.so").is_symlink():
    (home / "lib64" / "libcudart.so").symlink_to(cudart)
vendored = site / "vllm" / "third_party" / "deep_gemm"
tag = "cpython-3" + site.parent.name.removeprefix("python3.")
print(json.dumps({
    "cuda_environment": {"CUDA_HOME": str(home), "CPATH": str(tree / "include")}
    if (home / "bin" / "nvcc").exists() else {},
    "deep_gemm_unloadable": not (site / "deep_gemm").is_dir() and vendored.is_dir()
    and not any(vendored.glob(f"_C.{tag}-*.so")) and not any(vendored.glob("_C.abi3*.so")),
}))
"""
_PROXIES = ("HTTPS_PROXY", "HTTP_PROXY", "NO_PROXY", "https_proxy", "http_proxy", "no_proxy")


def _install_wsl(engine: str, cancel: threading.Event) -> None:
    """The same hash-pinned lock and checks as on Linux, run inside Studio's WSL distro. Always
    isolated: Studio's Windows packages cannot serve a Linux interpreter."""
    from . import wsl_host

    guest_root = wsl_host.GUEST_ROOT
    accelerator = profile(engine)["accelerator"]
    _update(engine, phase = "preparing_wsl", message = "Setting up the Unsloth WSL environment")
    wsl_host.prepare(lambda text: _update(engine, activity = text), cancel, accelerator)
    if cancel.is_set():
        raise RuntimeError("Installation cancelled.")
    root = engine_root() / engine
    root.mkdir(parents = True, exist_ok = True)
    digest = profile_digest(engine)
    directory = "env-" + uuid.uuid4().hex
    base = f"{guest_root}/engines/{engine}"
    destination = f"{base}/{directory}"
    python = f"{destination}/bin/python"
    uv = f"{guest_root}/bin/uv"
    env = {
        "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        "PYTHONNOUSERSITE": "1",
        "UV_CACHE_DIR": f"{guest_root}/uv-cache",
        "UV_PYTHON_INSTALL_DIR": f"{guest_root}/python",
        "UV_NO_CONFIG": "1",
        "UV_CONCURRENT_DOWNLOADS": "4",
        "UV_HTTP_RETRIES": "5",
        # Cache and environments share the distro's ext4 disk.
        "UV_LINK_MODE": "hardlink",
    }
    secrets = {key: os.environ[key] for key in _PROXIES if os.environ.get(key)}

    def guest_run(argv):
        command, windows_env = wsl_host.guest_command(argv, env = env, secrets = secrets)
        _run(engine, command, cancel, env = windows_env)

    if accelerator == "rocm":
        # The checks below start HIP, which reaches the GPU only with this environment.
        env.update(wsl_host.rocm_environment())
        if not wsl_host.rocm_ready():
            _update(engine, phase = "preparing_wsl", message = "Installing ROCm for the AMD GPU in WSL")
            guest_run(wsl_host.rocm_setup_command())
            if not wsl_host.rocm_ready():
                raise RuntimeError("Setting up ROCm in WSL did not finish. Retry the installation.")
    try:
        _update(engine, phase = "creating", message = "Preparing an isolated Python environment")
        guest_run([uv, "venv", *_venv_python_args(engine), destination])
        _update(engine, phase = "installing", message = "Downloading and installing engine packages")
        lock = wsl_host.to_guest_path(requirements(engine))
        guest_run(
            [
                uv,
                "pip",
                "sync",
                "--python",
                python,
                "--require-hashes",
                "--only-binary",
                ":all:",
                "--index-url",
                "https://pypi.org/simple",
                *_extra_index_args(engine),
                lock,
            ]
        )
        _update(engine, phase = "checking", message = "Checking the installed engine")
        from .engine_adapters import ADAPTERS

        scripts = {
            "check.py": _CHECK,
            "finalize.py": _GUEST_FINALIZE,
            "smoke.py": _smoke_source(engine),
        }
        for name, source in scripts.items():
            wsl_host.put(f"{destination}/{name}", source)
        guest_run(
            [
                python,
                "-I",
                f"{destination}/check.py",
                lock,
                _omit_argument(engine),
                profile(engine)["cuda"],
                "{}",
            ]
        )
        guest_run([python, "-I", f"{destination}/smoke.py"])
        guest_run([python, "-I", "-m", ADAPTERS[engine].module, "--help"])
        facts = json.loads(
            wsl_host.guest([python, "-I", f"{destination}/finalize.py", destination])
            .strip()
            .splitlines()[-1]
        )
        if (engine_root() / f"{engine}.cancel").exists():
            cancel.set()
        if cancel.is_set():
            raise RuntimeError("Installation cancelled.")
        if profile_digest(engine) != digest:
            raise RuntimeError(
                "Studio's engine profile changed during installation. Retry to use the updated profile."
            )
        prior = installed(engine)
        _atomic_json(
            root / "active.json",
            {
                "directory": directory,
                "version": profile(engine)["version"],
                "profile_digest": digest,
                "accelerator": accelerator,
                "shared": False,
                "python": "{}.{}".format(*python_version(engine)),
                "provided": {},
                "host": "wsl",
                "distro": wsl_host.distro_name(),
                **facts,
                "previous_directory": prior["directory"] if prior else None,
                "previous": {
                    k: v
                    for k, v in prior.items()
                    if k not in ("path", "previous", "previous_directory")
                }
                if prior
                else None,
            },
        )
        # Committed: from here a failed cleanup must never delete the environment just activated.
        destination = None
        keep = [directory, *([prior["directory"]] if prior else [])]
        try:
            wsl_host.guest(
                ["find", base, "-mindepth", "1", "-maxdepth", "1", "-name", "env-*"]
                + [arg for name in keep for arg in ("!", "-name", name)]
                + ["-exec", "rm", "-rf", "{}", "+"]
            )
        except (OSError, RuntimeError, subprocess.TimeoutExpired):
            pass
    finally:
        if destination is not None:
            try:
                wsl_host.guest(["rm", "-rf", destination])
            except (OSError, RuntimeError, subprocess.TimeoutExpired):
                pass
    _record_manifest(engine)
    _update(engine, state = "success", phase = "ready", message = "Engine installed")


def start_install(engine: str) -> dict:
    profile(engine)
    with _lock:
        if _jobs.get(engine, {}).get("state") == "running":
            return status(engine)
        lease = engine_lease(engine, exclusive = True)
        lease.__enter__()
        cancel = threading.Event()
        _cancels[engine] = cancel
        try:
            (engine_root() / f"{engine}.cancel").unlink(missing_ok = True)
            _update(
                engine,
                state = "running",
                phase = "queued",
                message = "Preparing installation",
                activity = "",
                log = [],
            )
            threading.Thread(target = _install, args = (engine, cancel, lease), daemon = True).start()
        except Exception:
            lease.__exit__(None, None, None)
            raise
    return status(engine)


def cancel_install(engine: str) -> dict:
    profile(engine)
    with _lock:
        event = _cancels.get(engine)
        if event:
            event.set()
        if status(engine)["job"].get("state") == "running":
            (engine_root() / f"{engine}.cancel").touch()
    return status(engine)


def remove(engine: str) -> dict:
    with engine_lease(engine, exclusive = True):
        root = engine_root() / engine
        if root.is_symlink():
            raise RuntimeError("Engine directory must not be a symbolic link.")
        from . import wsl_host

        if (
            wsl_host.active()
            and not wsl_host.distro_ready()
            and wsl_host.wsl_exe() is not None
            and wsl_host.distro_name() in wsl_host.registered_distros()
        ):
            # Forgetting the engine now would strand its files inside the distro.
            raise RuntimeError("WSL is not responding, so the engine cannot be removed. Try again.")
        if wsl_host.active() and wsl_host.distro_ready():
            # The compile caches live beside the environments, not under them.
            wsl_host.guest(
                [
                    "rm",
                    "-rf",
                    f"{wsl_host.GUEST_ROOT}/engines/{engine}",
                    f"{wsl_host.GUEST_ROOT}/cache/{engine}",
                ]
            )
        shutil.rmtree(root, ignore_errors = False) if root.exists() else None
        with _lock:
            _jobs.pop(engine, None)
        (engine_root() / f"{engine}.job.json").unlink(missing_ok = True)
        (engine_root() / f"{engine}.cancel").unlink(missing_ok = True)
    _record_manifest(engine)
    return status(engine)


def remove_wsl_environment() -> list[dict]:
    """Unregister the private distro. Every engine lives in it, so all must be idle."""
    from contextlib import ExitStack
    from . import wsl_host

    if not wsl_host.active():
        raise RuntimeError("Studio only creates a WSL environment on Windows.")
    with ExitStack() as stack:
        for engine in PROFILES:
            stack.enter_context(engine_lease(engine, exclusive = True))
        wsl_host.unregister()
        for engine in PROFILES:
            root = engine_root() / engine
            if root.exists() and not root.is_symlink():
                shutil.rmtree(root)
            (engine_root() / f"{engine}.job.json").unlink(missing_ok = True)
            with _lock:
                _jobs.pop(engine, None)
    for engine in PROFILES:
        _record_manifest(engine)
    return [status(engine) for engine in PROFILES]


def rollback(engine: str) -> dict:
    with engine_lease(engine, exclusive = True):
        info = installed(engine)
        previous = info.get("previous") if info else None
        directory = previous.get("directory") if isinstance(previous, dict) else None
        if (
            not isinstance(directory, str)
            or not directory.startswith("env-")
            or Path(directory).name != directory
        ):
            raise RuntimeError("No previous engine installation is available.")
        root = engine_root() / engine
        path = root / directory
        if previous.get("host") == "wsl":
            from . import wsl_host
            try:
                wsl_host.guest(
                    ["test", "-f", f"{wsl_host.GUEST_ROOT}/engines/{engine}/{directory}/bin/python"]
                )
                present = True
            except (OSError, RuntimeError, subprocess.TimeoutExpired):
                present = False
        else:
            present = not path.is_symlink() and (path / "bin" / "python").is_file()
        if not present:
            raise RuntimeError(
                "The previous engine installation is unavailable. Repair the engine instead."
            )
        if stale(previous):
            raise RuntimeError(
                "The previous engine installation was built on packages Studio no longer has. Repair the engine instead."
            )
        _atomic_json(
            root / "active.json",
            {
                **previous,
                "restored": True,
                "previous_directory": info["directory"],
                "previous": {
                    k: v
                    for k, v in info.items()
                    if k not in ("path", "previous", "previous_directory")
                },
            },
        )
        _update(
            engine, state = "success", phase = "ready", message = "Previous engine installation restored"
        )
    _record_manifest(engine)
    return status(engine)


def _record_manifest(engine: str) -> None:
    try:
        from studio.install_manifest import update_manifest

        info = installed(engine)
        from utils.paths.storage_roots import studio_root

        update_manifest(
            root = studio_root(),
            **{
                f"optional_engine_{engine}": {
                    "installed": info is not None,
                    "version": info.get("version") if info else None,
                    "profile_digest": info.get("profile_digest") if info else None,
                }
            },
        )
    except ImportError:
        pass
