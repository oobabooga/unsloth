# Unsloth Zoo - Utilities for Unsloth
# Copyright 2023-present Daniel Han-Chen, Michael Han-Chen & the Unsloth team. All rights reserved.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

__all__ = [
    "unsloth_fused_ce_loss",
    "apply_autograd_function",
    "compute_fused_ce_loss",
    "unsloth_count_aware_cross_entropy",
    "unsloth_loss_count_kwargs",
    "unsloth_fsdp_unshard",
]

import torch
from typing import Optional, Tuple, Callable, Dict
import inspect
import weakref
import functools
import math
import os
import sys
from unsloth_zoo.temporary_patches.common import UNSLOTH_ENABLE_LOGGING, torch_compile_options, logger
from unsloth_zoo.temporary_patches.common import CHUNK_ALIGN_ROWS, chunk_row_bounds
from unsloth_zoo.device_type import DEVICE_TYPE
from unsloth_zoo.fused_losses import chunked_logprob as _chunked_logprob
        

TARGET_GB = os.environ.get("UNSLOTH_CE_LOSS_TARGET_GB", None)
N_CHUNKS = os.environ.get("UNSLOTH_CE_LOSS_N_CHUNKS", None)
# Opt-in: accumulate a trainable lm_head weight gradient across chunks in float32 (one
# extra float32 copy of the head while the loss runs). The bias gradient always is.
FP32_HEAD_GRAD = os.environ.get("UNSLOTH_CE_FP32_HEAD_GRAD", "0") == "1"
_HALF_DTYPES = (torch.float16, torch.bfloat16)

# Register grad_and_value_impl in trace_rules (grad_impl is registered but
# grad_and_value_impl is not, which can cause GB0149 "Unsupported functorch
# tracing attempt" in some configurations).
try:
    from torch._dynamo.trace_rules import manual_torch_name_rule_map as _trace_map
    from torch._dynamo.variables.higher_order_ops import FunctorchHigherOrderVariable as _FHOV
    _key = "torch._functorch.eager_transforms.grad_and_value_impl"
    if _key not in _trace_map:
        _trace_map[_key] = _FHOV
        torch._dynamo.trace_rules.get_torch_obj_rule_map.cache_clear()
except Exception:
    pass

# Module-level flag: None = untested, True = works, False = skip compile.
_FUSED_CE_COMPILE_DISABLED = os.environ.get("UNSLOTH_FUSED_CE_COMPILE_DISABLE", "0") == "1"
_FUSED_CE_COMPILE_SUPPORTED = None if not _FUSED_CE_COMPILE_DISABLED else False

@functools.cache
def _get_mapping(autograd):
    parameters = inspect.signature(getattr(autograd, "forward")).parameters
    parameters = dict(parameters)
    parameters.pop("ctx", None)
    return tuple(parameters.keys()), tuple([x.default for x in parameters.values()])
pass

def _nonzero_count(n_items):
    """0 -> 1 so an all-masked batch gives loss 0, not 0 / 0."""
    if torch.is_tensor(n_items):
        return torch.where(n_items == 0, torch.ones_like(n_items), n_items)
    return n_items if n_items != 0 else 1
pass

@torch.compiler.disable
def _fsdp_unshard(module):
    module.unshard()
pass

def unsloth_fsdp_unshard(module):
    # All Unsloth Zoo code licensed under LGPLv3
    """All-gather an FSDP2-sharded module (lm_head) whose weight the fused losses read without calling it.

    FSDP2 unshards in the module's pre-forward hook, which never fires here; accelerate shards an
    untied lm_head in its own group, so the weight would reach the matmul as a DTensor (unsloth-zoo#1751).
    Traceable unless an FSDP2 unit is found, so compiled non-FSDP forwards keep one graph.
    """
    if module is None or not torch.distributed.is_available() or not torch.distributed.is_initialized():
        return
    # fully_shard lives here, so no FSDP2 unit can exist before this module was imported.
    FSDPModule = getattr(sys.modules.get("torch.distributed.fsdp"), "FSDPModule", None)
    if FSDPModule is None:
        return
    for submodule in module.modules():
        if isinstance(submodule, FSDPModule):
            # No-op once unsharded; post-backward reshards it and reduce-scatters its gradient.
            _fsdp_unshard(submodule)
pass

def apply_autograd_function(autograd, mapping):
    parameters, defaults = _get_mapping(autograd)
    return getattr(autograd, "apply")(*(
        mapping.get(old_key, default) \
        for old_key, default in zip(parameters, defaults)
    ))
pass

def compute_fused_ce_loss(
    hidden_states  : torch.Tensor,
    lm_head_weight : torch.Tensor,
    lm_head_bias   : Optional[torch.Tensor],
    labels         : torch.Tensor,
    n_items        : Optional[torch.Tensor] = None,
    scaling        : Optional[float] = None,
    shift_labels   : bool = True,
    **kwargs,
) -> Tuple[torch.Tensor, Tuple[torch.Tensor,],]:
    """
    Computes cross_entropy_loss(X @ W + b, labels)
    * shift_labels does hidden_states[..., :-1] and labels[..., 1:]
    * If n_items is not given, does mean(ce_loss), otherwise sum(ce_loss)/n_items
    * Allows scaling factor from mixed precision fp16, fp8
    * Upcasts to float32 and allows kwargs to have:
    1) logit_scale_multiply (X = X * logit_scale_multiply)
    2) logit_scale_divide   (X = X / logit_scale_divide)
    3) logit_softcapping    (X = tanh(X / logit_softcapping) * logit_softcapping)
    4) ignore_index         (passed to F.cross_entropy; defaults to -100)
    5) label_smoothing      (passed to F.cross_entropy; defaults to 0.0)
    6) logits_bias          (X = X + logits_bias, right after the head; no gradient)
    """
    ignore_index = int(kwargs.get("ignore_index", -100))
    label_smoothing = float(kwargs.get("label_smoothing", 0.0))
    device = lm_head_weight.device
    if shift_labels:
        # Get shifted labels first
        _labels = torch.empty_like(labels, device = device)
        _labels[..., :-1] = labels[..., 1:]
        _labels[..., -1] = ignore_index
        labels = _labels
    pass

    logits = torch.nn.functional.linear(
        hidden_states.to(dtype = lm_head_weight.dtype, device = device),
        lm_head_weight,
        lm_head_bias,
    )
    # Extra vocab bias added after the head (Bart `final_logits_bias`), with the stock dtype promotion.
    logits_bias = kwargs.get("logits_bias", None)
    if logits_bias is not None:
        # Promote before the add: torch 2.7 inductor folds a bare add into a mixed dtype addmm under autocast.
        logits_bias = logits_bias.to(device = device)
        logits = logits.to(torch.promote_types(logits.dtype, logits_bias.dtype)) + logits_bias
    vocab_size = lm_head_weight.shape[0]

    # Apply softcapping and other functions
    logit_scale_multiply = kwargs.get("logit_scale_multiply", None)
    logit_scale_divide = kwargs.get("logit_scale_divide", None)
    logit_softcapping = kwargs.get("logit_softcapping", None)
    if logit_scale_multiply != 0 and logit_scale_multiply is not None:
        logits = logits * logit_scale_multiply
    if logit_scale_divide != 0 and logit_scale_divide is not None:
        logits = logits / logit_scale_divide
    if logit_softcapping != 0 and logit_softcapping is not None:
        logits = logits / logit_softcapping
        logits = torch.tanh(logits)
        logits = logits * logit_softcapping

    # sum / n_items, else sum / labelled tokens (the stock mean)
    target = labels.view(-1).to(device).contiguous()
    loss = torch.nn.functional.cross_entropy(
        input  = logits.view(-1, vocab_size).float().contiguous(),
        target = target,
        reduction = "sum",
        ignore_index = ignore_index,
        label_smoothing = label_smoothing,
    )
    loss = loss / _nonzero_count(n_items if n_items is not None else (target != ignore_index).sum())
    # Scale loss if needed for mixed precision training
    scaled_loss = loss * scaling if scaling is not None else loss
    # Must add .loss.detach otherwise autograd uses 2x VRAM
    return scaled_loss, (loss.detach(),)
pass


# Per (token x vocab) element over the whole eager chain: bf16 logits + float32
# upcast + saved log_softmax + backward gradient = 14, and 16 under softcapping.
# 4 counted the logits alone.
_CE_BYTES_PER_LOGIT = 16.0

# Cap per-chunk target: on very large GPUs half the free pool rounds to a single chunk,
# materializing full float32 logits and dominating peak memory.
_CE_TARGET_GB_CAP = 4.0


def _free_target_gb(device = None):
    """Half the memory actually available on `device` (None = current device), capped.

    `_default_target_gb` already answers this for every backend the zoo supports, and it
    answers it for the reason this needed: it checks `is_available()` before asking a device
    how much memory it has, and budgets CPU, MPS and other unified-memory backends from host
    RAM. `DEVICE_TYPE` is legitimately "cpu" or "mlx", and on a torch built without CUDA
    `mem_get_info` does not return a number, it raises "Torch not compiled with CUDA enabled".
    That query sat under the ordinary forward, so a CPU or Apple Silicon run died inside a
    memory lookup rather than on anything it was computing.

    Reused rather than reimplemented: a second copy that measured something different would be
    the same bug again, one module over.
    """

    # Absolute, not `from ..tiled_mlp`: transformers' dynamic_module_utils builds the path by
    # joining the raw regex capture onto this directory, so the relative spelling sends it looking
    # for fused_losses/.tiled_mlp.py and every remote-code save walking this graph fails.
    from unsloth_zoo.tiled_mlp import _default_target_gb  # noqa: PLC0415  (avoids an import cycle)

    return min(_default_target_gb(device), _CE_TARGET_GB_CAP)


@functools.cache
def _measured_target_gb(device = None):
    # Read once per device: a per-call reading costs a host query and a graph break each forward.
    return _free_target_gb(device)


@functools.cache
def _get_chunk_multiplier(vocab_size, target_gb = None, fixed_gb = 0.0, device = None):
    """Chunk multiplier sized to fit target max memory usage."""
    if target_gb is None:
        target_gb = _measured_target_gb(device)
    pass

    # Prevent ZeroDivisionError when GPU memory is exhausted
    if target_gb <= 1e-9: # Use a small epsilon for float comparison
        raise RuntimeError("Unsloth: No or negligible GPU memory available for fused cross entropy.")

    # Unchunkable allocations share the budget; if they alone exceed the target
    # no chunk count helps, so keep the full budget instead.
    if 0.0 < fixed_gb < target_gb:
        target_gb = target_gb - fixed_gb
    pass

    multiplier = (vocab_size * _CE_BYTES_PER_LOGIT / 1024 / 1024 / 1024) / (target_gb)
    multiplier = multiplier / 4 # Output only multiples of 4
    return multiplier
pass
_clear_chunk_multipliers = _get_chunk_multiplier.cache_clear
def _clear_chunk_budget_caches():
    _clear_chunk_multipliers()
    _measured_target_gb.cache_clear()
pass
_get_chunk_multiplier.cache_clear = _clear_chunk_budget_caches
_get_explicit_chunk_multiplier = _get_chunk_multiplier

def get_chunk_size(bsz, qlen, vocab_size, target_gb = None, fixed_gb = 0.0, device = None):
    """Number of chunks that fits the target max memory usage."""
    if target_gb is None:
        multiplier = _get_chunk_multiplier(vocab_size, None, fixed_gb, device)
    else:
        multiplier = _get_explicit_chunk_multiplier(vocab_size, target_gb, fixed_gb)
    n_splits = (bsz*qlen) * multiplier
    # n_splits * 4 == (chunk transient GiB) / target. Round UP: nearest-rounding
    # (round(0.5) -> 0) collapses a large transient into one uncapped chunk.
    exact = n_splits * 4
    if exact <= 1.0 + 1e-9:
        return 1
    n_chunks = math.ceil(exact / 4 - 1e-9) * 4
    return min(n_chunks, bsz*qlen)
pass

class UnslothFusedLoss(torch.autograd.Function):
    # Log the "scaling=0" info message at most once per process.
    _scaling_zero_logged = False

    @staticmethod
    def forward(
        ctx,
        loss_function  : Callable,
        hidden_states  : torch.Tensor,
        lm_head_weight : torch.Tensor,
        lm_head_bias   : Optional[torch.Tensor],
        labels         : torch.Tensor,
        mask           : Optional[torch.Tensor] = None,
        n_items        : Optional[torch.Tensor] = None,
        scaling        : Optional[float] = None,
        shift_labels   : Optional[bool] = True,
        target_gb      : Optional[int] = None,
        torch_compile  : Optional[bool] = True,
        overwrite      : Optional[bool] = False,
        extra_kwargs   : Optional[Dict] = None,
        compute_gradients : bool = True,
    ):
        """
        Computes chunked fused loss_function(chunk(X) @ W + b, chunk(labels))
        * If n_items is not given, does mean(loss), otherwise sum(loss)/n_items
        * shift_labels does hidden_states[..., :-1] and labels[..., 1:]
        * Allows scaling factor from mixed precision fp16, fp8
        * target_gb specifies the max GB memory the fused loss can use - default detects VRAM left
        * overwrite allows hidden_states to be overwritten with gradients
        * Place extra args in extra_kwargs which will be passed to (loss_function)
        """
        device = lm_head_weight.device
        if extra_kwargs is None: extra_kwargs = {}
        # Thread ignore_index through label-shift and the inner CE call.
        ignore_index = int(extra_kwargs.get("ignore_index", -100))

        # Get shifted labels first
        if shift_labels:
            _labels = torch.empty_like(labels, device = device)
            _labels[..., :-1] = labels[..., 1:]
            # Also check mask
            if mask is not None:
                mask = mask.to(device = device)
                _labels[..., :-1][mask[..., 1:] == 0] = ignore_index
            pass
            _labels[..., -1] = ignore_index
            _labels = _labels.view(-1)
            labels = _labels
        else:
            # Caller already shifted (e.g. trl padding_free passes
            # shift_labels=<tensor>). Flatten so chunking aligns with
            # hidden_states.reshape(-1, hd).
            labels = labels.contiguous().view(-1).to(device = device)
        pass

        # N items divisor
        divisor = n_items if n_items is not None else (labels != ignore_index).sum()
        if not torch.is_tensor(divisor):
            divisor = torch.tensor(divisor, dtype = torch.float32, device = device)
        # Counteract DataParallel having multiple items since it does scatter & gather
        if divisor.numel() != 1: divisor = divisor.ravel()[0]
        divisor = _nonzero_count(divisor.to(dtype = torch.float32, device = device))
        # Check what needs gradients
        lm_head_requires_grad = lm_head_weight is not None and lm_head_weight.requires_grad
        lm_head_bias_requires_grad = lm_head_bias is not None and lm_head_bias.requires_grad
        vocab_size = lm_head_weight.shape[0]

        # Create backwards output
        grad_inputs = None
        if compute_gradients:
            grad_inputs = torch.empty_like(hidden_states, device = device) if not overwrite else hidden_states
        # Summing per-chunk half precision gradients in half precision rounds once per chunk:
        # at 16 chunks the bias gradient is 2-15x further from an fp64 oracle than unfused.
        grad_lm_head = torch.zeros_like(
            lm_head_weight, device = device,
            dtype = torch.float32 if FP32_HEAD_GRAD and lm_head_weight.dtype in _HALF_DTYPES else None,
        ) if compute_gradients and lm_head_requires_grad else None
        grad_lm_head_bias = torch.zeros_like(
            lm_head_bias, device = device,
            dtype = torch.float32 if lm_head_bias.dtype in _HALF_DTYPES else None,
        ) if compute_gradients and lm_head_bias_requires_grad else None

        bsz, qlen, hd = hidden_states.shape
        # 0-dim, not a [0] view: MoE forwards on transformers 4.x add their aux loss in place.
        accumulated_loss = torch.zeros((), device = device)
        # Chunk hidden_states and labels
        if "n_chunks" in extra_kwargs:
            n_chunks = extra_kwargs.pop("n_chunks")
        else:
            # Memory no chunk count can shrink. Under overwrite grad_inputs
            # aliases hidden_states; the head gradient counts twice (per chunk).
            fixed_bytes = 0
            if grad_inputs is not None and not overwrite:
                fixed_bytes += grad_inputs.numel() * grad_inputs.element_size()
            if grad_lm_head is not None:
                fixed_bytes += 2 * grad_lm_head.numel() * grad_lm_head.element_size()
            if grad_lm_head_bias is not None:
                fixed_bytes += 2 * grad_lm_head_bias.numel() * grad_lm_head_bias.element_size()
            n_chunks = get_chunk_size(
                bsz, qlen, vocab_size, target_gb = target_gb,
                fixed_gb = fixed_bytes / 1024 / 1024 / 1024,
                device = device,
            )
        if UNSLOTH_ENABLE_LOGGING:
            logger.info(f"Fused CE Loss [bsz={bsz}][qlen={qlen}][vocab_size={vocab_size}][n_chunks={n_chunks}]")
        bounds = chunk_row_bounds(bsz * qlen, n_chunks, align = CHUNK_ALIGN_ROWS)
        if bounds is not None:
            ranges = list(zip(bounds[:-1], bounds[1:]))
            _flat_states = hidden_states.reshape(-1, hd)
            __shift_labels = [labels[a:b]       for a, b in ranges]
            __shift_states = [_flat_states[a:b] for a, b in ranges]
            if compute_gradients:
                _flat_grads = grad_inputs.view(-1, hd)
                __grad_inputs = [_flat_grads[a:b] for a, b in ranges]
        else:
            __shift_labels = torch.chunk(labels,                     n_chunks, dim = 0)
            __shift_states = torch.chunk(hidden_states.reshape(-1, hd), n_chunks, dim = 0)
            if compute_gradients:
                __grad_inputs = torch.chunk(grad_inputs.view(-1, hd), n_chunks, dim = 0)
        if not compute_gradients:
            __grad_inputs = (None,) * len(__shift_states)

        def accumulate_chunk(
            n_chunks,
            grad_inputs_j,
            grad_lm_head,
            grad_lm_head_bias,
            hidden_states_j,
            lm_head_weight,
            lm_head_bias,
            labels_j,
            divisor = None,
            scaling = None,
            shift_labels = False,
            **kwargs,
        ):
            if not compute_gradients:
                chunk_loss, (unscaled_loss,) = loss_function(
                    hidden_states_j,
                    lm_head_weight,
                    lm_head_bias,
                    labels_j,
                    divisor,
                    scaling,
                    False,
                    **kwargs,
                )
            elif lm_head_requires_grad and lm_head_bias_requires_grad:
                (chunk_grad_input, chunk_grad_lm_head, chunk_grad_lm_head_bias,), \
                (chunk_loss, (unscaled_loss,)) = \
                torch.func.grad_and_value(
                    loss_function,
                    argnums = (0, 1, 2,),
                    has_aux = True,
                )(
                    hidden_states_j,
                    lm_head_weight,
                    lm_head_bias,
                    labels_j,
                    divisor,
                    scaling,
                    False, # Outer pre-shifted (or caller did); inner skips
                    **kwargs,
                )
                grad_lm_head.add_(chunk_grad_lm_head)
                grad_lm_head_bias.add_(chunk_grad_lm_head_bias)
            elif lm_head_requires_grad:
                (chunk_grad_input, chunk_grad_lm_head,), \
                (chunk_loss, (unscaled_loss,)) = torch.func.grad_and_value(
                    loss_function,
                    argnums = (0, 1,),
                    has_aux = True,
                )(
                    hidden_states_j,
                    lm_head_weight,
                    lm_head_bias,
                    labels_j,
                    divisor,
                    scaling,
                    False, # Outer pre-shifted (or caller did); inner skips
                    **kwargs,
                )
                grad_lm_head.add_(chunk_grad_lm_head)
            elif lm_head_bias_requires_grad:
                (chunk_grad_input, chunk_grad_lm_head_bias,), \
                (chunk_loss, (unscaled_loss,)) = torch.func.grad_and_value(
                    loss_function,
                    argnums = (0, 2,),
                    has_aux = True,
                )(
                    hidden_states_j,
                    lm_head_weight,
                    lm_head_bias,
                    labels_j,
                    divisor,
                    scaling,
                    False, # Outer pre-shifted (or caller did); inner skips
                    **kwargs,
                )
                grad_lm_head_bias.add_(chunk_grad_lm_head_bias)
            else:
                (chunk_grad_input,), \
                (chunk_loss, (unscaled_loss,)) = torch.func.grad_and_value(
                    loss_function,
                    argnums = (0,),
                    has_aux = True,
                )(
                    hidden_states_j,
                    lm_head_weight,
                    lm_head_bias,
                    labels_j,
                    divisor,
                    scaling,
                    False, # Outer pre-shifted (or caller did); inner skips
                    **kwargs,
                )
            pass
            accumulated_loss.add_(unscaled_loss)
            if compute_gradients:
                grad_inputs_j[:] = chunk_grad_input
        pass
        global _FUSED_CE_COMPILE_SUPPORTED
        uncompiled_accumulate_chunk = accumulate_chunk

        if torch_compile and _FUSED_CE_COMPILE_SUPPORTED is not False:
            try:
                accumulate_chunk = torch.compile(
                    accumulate_chunk,
                    dynamic = True,
                    fullgraph = True,
                    options = torch_compile_options,
                )
            except Exception:
                _FUSED_CE_COMPILE_SUPPORTED = False
                accumulate_chunk = uncompiled_accumulate_chunk

        # Probe path: first-ever forward pass, test if compiled version works
        if _FUSED_CE_COMPILE_SUPPORTED is None and torch_compile and \
            accumulate_chunk is not uncompiled_accumulate_chunk:

            _iter = iter(zip(__grad_inputs, __shift_states, __shift_labels))
            grad_inputs_j, hidden_states_j, labels_j = next(_iter)
            try:
                accumulate_chunk(
                    n_chunks = n_chunks,
                    grad_inputs_j = grad_inputs_j,
                    grad_lm_head = grad_lm_head,
                    grad_lm_head_bias = grad_lm_head_bias,
                    hidden_states_j = hidden_states_j,
                    lm_head_weight = lm_head_weight,
                    lm_head_bias = lm_head_bias,
                    labels_j = labels_j,
                    divisor = divisor,
                    scaling = scaling,
                    shift_labels = shift_labels,
                    **extra_kwargs,
                )
                # A loss-only graph does not prove the grad_and_value graph compiles.
                if compute_gradients: _FUSED_CE_COMPILE_SUPPORTED = True
            except Exception:
                _FUSED_CE_COMPILE_SUPPORTED = False
                torch._dynamo.reset()
                accumulated_loss.zero_()
                if grad_inputs is not None and not overwrite:
                    grad_inputs.zero_()
                if grad_lm_head is not None: grad_lm_head.zero_()
                if grad_lm_head_bias is not None: grad_lm_head_bias.zero_()
                accumulate_chunk = uncompiled_accumulate_chunk
                accumulate_chunk(
                    n_chunks = n_chunks,
                    grad_inputs_j = grad_inputs_j,
                    grad_lm_head = grad_lm_head,
                    grad_lm_head_bias = grad_lm_head_bias,
                    hidden_states_j = hidden_states_j,
                    lm_head_weight = lm_head_weight,
                    lm_head_bias = lm_head_bias,
                    labels_j = labels_j,
                    divisor = divisor,
                    scaling = scaling,
                    shift_labels = shift_labels,
                    **extra_kwargs,
                )
            # Process remaining chunks via fast path
            for (grad_inputs_j, hidden_states_j, labels_j,) in _iter:
                accumulate_chunk(
                    n_chunks = n_chunks,
                    grad_inputs_j = grad_inputs_j,
                    grad_lm_head = grad_lm_head,
                    grad_lm_head_bias = grad_lm_head_bias,
                    hidden_states_j = hidden_states_j,
                    lm_head_weight = lm_head_weight,
                    lm_head_bias = lm_head_bias,
                    labels_j = labels_j,
                    divisor = divisor,
                    scaling = scaling,
                    shift_labels = shift_labels,
                    **extra_kwargs,
                )
        else:
            # Fast path: compile status already known, original main branch loop
            for (grad_inputs_j, hidden_states_j, labels_j,) in \
                zip(__grad_inputs, __shift_states, __shift_labels,):
                accumulate_chunk(
                    n_chunks = n_chunks,
                    grad_inputs_j = grad_inputs_j,
                    grad_lm_head = grad_lm_head,
                    grad_lm_head_bias = grad_lm_head_bias,
                    hidden_states_j = hidden_states_j,
                    lm_head_weight = lm_head_weight,
                    lm_head_bias = lm_head_bias,
                    labels_j = labels_j,
                    divisor = divisor,
                    scaling = scaling,
                    shift_labels = shift_labels,
                    **extra_kwargs,
                )
        pass
        if compute_gradients:
            if grad_lm_head is not None: grad_lm_head = grad_lm_head.to(lm_head_weight.dtype)
            if grad_lm_head_bias is not None: grad_lm_head_bias = grad_lm_head_bias.to(lm_head_bias.dtype)
            ctx.save_for_backward(grad_inputs, grad_lm_head, grad_lm_head_bias)
            ctx.scaling = scaling
        return accumulated_loss
    pass

    @staticmethod
    def backward(ctx, grad_output,):
        # DDP can scale grad_output by world size; normalize to expected scaling.
        scaling = ctx.scaling if ctx.scaling is not None else 1.0
        (grad_inputs, grad_lm_head, grad_lm_head_bias, ) = ctx.saved_tensors

        # Collapse tensor scaling to a Python float at the boundary. All current
        # callers pass a Python float (GradScaler.get_scale() returns float); a
        # future tensor caller pays a single .item() sync here and then takes
        # the scalar path. This keeps one code path, one semantics.
        if torch.is_tensor(scaling):
            scaling = float(scaling.detach().item())

        # scaling == 0 lost the saved gradient: forward's grad_and_value
        # differentiated scaled_loss = loss * scaling, so saved = scaling *
        # d(loss)/d(hidden) = 0. The Function returns the unscaled loss though,
        # so the correct answer is grad_output * d(loss)/d(hidden) - which we
        # cannot recover from saved=0. Only safe when grad_output is also 0
        # (chain rule: 0 * anything = 0); otherwise raise.
        if scaling == 0.0:
            if torch.is_tensor(grad_output):
                go_is_zero = bool(torch.all(grad_output == 0).item())
            else:
                go_is_zero = float(grad_output) == 0.0
            if not go_is_zero:
                raise RuntimeError(
                    "Fused CE loss: scaling=0 with non-zero grad_output. The "
                    "saved gradient was zeroed by scaling in the forward pass "
                    "and the unscaled gradient cannot be recovered. Likely a "
                    "misconfigured GradScaler."
                )
            if UNSLOTH_ENABLE_LOGGING and not UnslothFusedLoss._scaling_zero_logged:
                UnslothFusedLoss._scaling_zero_logged = True
                logger.info(
                    "Fused CE loss: scaling=0 with grad_output=0; returning zero "
                    "gradients. This message is logged once per process."
                )
            return (
                None, grad_inputs, grad_lm_head, grad_lm_head_bias,
                None, None, None, None, None, None, None, None, None, None,
            )

        if torch.is_tensor(grad_output):
            grad_scale = grad_output.detach().float().mean()
        else:
            grad_scale = torch.tensor(float(grad_output), device=grad_inputs.device, dtype=grad_inputs.dtype)

        scale_factor = grad_scale / scaling

        if UNSLOTH_ENABLE_LOGGING:
            if torch.is_tensor(grad_output):
                grad_scale_val = float(grad_scale.detach().cpu().item())
            else:
                grad_scale_val = float(grad_output)
            scale_factor_val = float(scale_factor.detach().cpu().item())
            if scale_factor_val == 1.0:
                torch._assert(
                    torch.all(grad_output == scaling),
                    f"Fused losses expect grad_output to be all {scaling}, but got {grad_output.ravel()[:10]}",
                )
            else:
                world_size = None
                try:
                    import torch.distributed as dist
                    if dist.is_available() and dist.is_initialized():
                        world_size = dist.get_world_size()
                except Exception:
                    world_size = None
                if world_size is not None:
                    logger.info(
                        f"Fused losses grad_output scaled by {scale_factor_val} (got {grad_scale_val}, expected {scaling} or {scaling * world_size})"
                    )
                else:
                    logger.info(
                        f"Fused losses grad_output scaled by {scale_factor_val} (got {grad_scale_val}, expected {scaling})"
                    )

        # Out-of-place mul so ctx.saved_tensors' version counter doesn't bump,
        # keeping retain_graph / double-backward flows working. Measured peak
        # memory delta vs in-place is <3 MB across 14 configs.
        grad_inputs = grad_inputs * scale_factor
        if grad_lm_head is not None: grad_lm_head = grad_lm_head * scale_factor
        if grad_lm_head_bias is not None: grad_lm_head_bias = grad_lm_head_bias * scale_factor

        return (None, grad_inputs, grad_lm_head, grad_lm_head_bias, None, None, None, None, None, None, None, None, None, None,)
    pass
pass

# Resolved once here, not per call: under torch.compile dynamo ignores functools.cache, traces
# inspect.signature and graph-breaks (it cannot key a dict on, or getattr, an autograd.Function).
_FUSED_LOSS_PARAMETERS, _FUSED_LOSS_DEFAULTS = _get_mapping(UnslothFusedLoss)

# torch 2.11 alone traces UnslothFusedLoss into a graph that saves zero gradients (right loss, nothing trains).
_FUSED_LOSS_OPAQUE = torch.__version__.split("+")[0].split(".")[:2] == ["2", "11"]

@torch.compiler.disable
def _fused_loss_opaque(*args):
    return UnslothFusedLoss.apply(*args)

# UNSLOTH_CHUNKED_CE=0 keeps the torch.func path below for every call.
_CHUNKED_CE = os.environ.get("UNSLOTH_CHUNKED_CE", "1") != "0"
_CHUNKED_CE_KWARGS = frozenset(("ignore_index", "logit_scale_multiply", "logit_scale_divide", "logit_softcapping"))
# The fused linear kernel also implements these; UNSLOTH_FUSED_LINEAR=0 sends them back to the torch.func path.
_FUSED_LINEAR_CE_KWARGS = _CHUNKED_CE_KWARGS | frozenset(("label_smoothing", "logits_bias"))


def _use_chunked_ce(kwargs, target_gb):
    # n_chunks and explicit memory targets keep the old path.
    if not _CHUNKED_CE or target_gb is not None or TARGET_GB or N_CHUNKS:
        return False
    # The fused-CE compile opt-out keeps the path it was written for.
    if _FUSED_CE_COMPILE_DISABLED:
        return False
    if _chunked_logprob._FUSED_LINEAR:
        return all(k in _FUSED_LINEAR_CE_KWARGS for k in kwargs)
    # Without the fused linear kernel: plain token CE only, fp32 head-gradient accumulation stays on the old path.
    if FP32_HEAD_GRAD:
        return False
    if float(kwargs.get("label_smoothing", 0.0) or 0.0) != 0.0:
        return False
    return all(k in _CHUNKED_CE_KWARGS or k == "label_smoothing" for k in kwargs)


def _scaler_scale(scaling):
    """GradScaler -> its scale as a device tensor (get_scale() is a host sync, and a graph break when compiled)."""
    if not hasattr(scaling, "get_scale"):
        return scaling
    # GradScaler's attributes, not is_enabled() / get_scale(): dynamo skips torch.amp methods, so each call was a
    # graph break in every compiled step.
    enabled = getattr(scaling, "_enabled", None)
    if enabled is None and hasattr(scaling, "is_enabled"):
        enabled = scaling.is_enabled()
    if enabled is False:
        return None
    scale = getattr(scaling, "_scale", None)
    if torch.is_tensor(scale):
        return scale.detach().reshape(())
    # Step 0: the first scaler.scale() has not allocated the scale yet, so it is still the initial value.
    init = getattr(scaling, "_init_scale", None)
    return float(init) if init is not None else scaling.get_scale()


def _chunked_ce(hidden_states, lm_head_weight, lm_head_bias, labels, mask, n_items, scaling, shift_labels, kwargs):
    # Traceable with the fused linear op: the row compaction and every chunk loop run inside it, so a compiled forward
    # keeps one graph through the loss. Without it (UNSLOTH_FUSED_LINEAR=0) the eager chunked path boolean-indexes
    # rows and reads the scale on the host, so it stays opaque to dynamo as before.
    if not _chunked_logprob._FUSED_LINEAR:
        return _chunked_ce_opaque(
            hidden_states, lm_head_weight, lm_head_bias, labels, mask, n_items, scaling, shift_labels, kwargs,
        )
    return _chunked_ce_traced(
        hidden_states, lm_head_weight, lm_head_bias, labels, mask, n_items, scaling, shift_labels, kwargs,
    )


def _chunked_ce_traced(hidden_states, lm_head_weight, lm_head_bias, labels, mask, n_items, scaling, shift_labels,
                       kwargs):
    return _chunked_logprob.unsloth_chunked_ce_loss(
        hidden_states, lm_head_weight, lm_head_bias, labels, mask = mask, n_items = n_items,
        scaling = _scaler_scale(scaling), shift_labels = shift_labels,
        ignore_index = int(kwargs.get("ignore_index", -100)),
        logit_scale_multiply = kwargs.get("logit_scale_multiply", 0.0),
        logit_scale_divide = kwargs.get("logit_scale_divide", 0.0),
        logit_softcapping = kwargs.get("logit_softcapping", 0.0),
        label_smoothing = float(kwargs.get("label_smoothing", 0.0) or 0.0),
        logits_bias = kwargs.get("logits_bias", None),
        fp32_head_grad = FP32_HEAD_GRAD,
    )


@torch.compiler.disable
def _chunked_ce_opaque(hidden_states, lm_head_weight, lm_head_bias, labels, mask, n_items, scaling, shift_labels,
                       kwargs):
    return _chunked_ce_traced(
        hidden_states, lm_head_weight, lm_head_bias, labels, mask, n_items, scaling, shift_labels, kwargs,
    )


def unsloth_fused_ce_loss(
    trainer,
    hidden_states  : torch.Tensor,
    lm_head_weight : torch.Tensor,
    lm_head_bias   : Optional[torch.Tensor],
    labels         : torch.Tensor,
    mask           : Optional[torch.Tensor] = None,
    n_items        : Optional[torch.Tensor] = None,
    scaling        : Optional[float] = None,
    target_gb      : Optional[int] = None,
    torch_compile  : Optional[bool] = True,
    overwrite      : Optional[bool] = False,
    shift_labels   : bool = True,
    **kwargs,
):
    """
    Computes chunked fused cross_entropy_loss(chunk(X) @ W + b, chunk(labels))
    * If n_items is not given, does mean(ce_loss), otherwise sum(ce_loss)/n_items
    * shift_labels=True (default) shifts internally: hidden_states[..., :-1] and labels[..., 1:].
      Set False when caller already pre-shifted (e.g. trl padding_free).
    * Allows scaling factor from mixed precision fp16, fp8
    * target_gb specifies the max GB memory the fused loss can use - default detects VRAM left
    * Upcasts to float32 and allows kwargs to have:
    1) logit_scale_multiply (X = X * logit_scale_multiply)
    2) logit_scale_divide   (X = X / logit_scale_divide)
    3) logit_softcapping    (X = tanh(X / logit_softcapping) * logit_softcapping)
    """
    scaler = trainer.accelerator.scaler if trainer is not None else None
    # Get mixed precision scaling if seen (read lazily: get_scale() syncs the host)
    scaling = scaler if scaler is not None else scaling
    if TARGET_GB: target_gb = float(TARGET_GB)
    elif N_CHUNKS: kwargs["n_chunks"] = max(int(N_CHUNKS), 1)

    # Move hidden_states to lm_head's device if they differ (e.g. multi-GPU
    # device_map="balanced"). torch.func.grad_and_value wraps inputs and fails
    # with "Cannot access storage of TensorWrapper" when tensors span devices.
    # Autograd tracks .to() and moves gradients back to the original device.
    device = lm_head_weight.device
    if hidden_states.device != device:
        hidden_states = hidden_states.to(device = device)

    if _use_chunked_ce(kwargs, target_gb):
        return _chunked_ce(
            hidden_states, lm_head_weight, lm_head_bias, labels, mask, n_items, scaling, shift_labels, kwargs,
        )
    if hasattr(scaling, "get_scale"): scaling = scaling.get_scale()

    mapping = dict(
        loss_function = compute_fused_ce_loss,
        hidden_states = hidden_states,
        lm_head_weight = lm_head_weight,
        lm_head_bias = lm_head_bias,
        labels = labels,
        mask = mask,
        n_items = n_items,
        scaling = scaling,
        shift_labels = shift_labels,
        target_gb = target_gb,
        torch_compile = torch_compile,
        overwrite = overwrite,
        extra_kwargs = kwargs,
        # autograd.Function.forward disables grad mode even during training.
        compute_gradients = torch.is_grad_enabled(),
    )
    apply = _fused_loss_opaque if _FUSED_LOSS_OPAQUE else UnslothFusedLoss.apply
    return apply(*(
        mapping.get(key, default) \
        for key, default in zip(_FUSED_LOSS_PARAMETERS, _FUSED_LOSS_DEFAULTS)
    ))
pass


def unsloth_count_aware_cross_entropy(
    logits,
    labels,
    n_items = None,
    *,
    shift = True,
    ignore_index = -100,
    mask = None,
    vocab_size = None,
):
    # All Unsloth Zoo code licensed under LGPLv3
    """Token CE as sum / n_items when the GA count is given, else the stock mean.

    Runs in the logits' own dtype as stock does (no fp32 copy); with a count the per-token losses are
    summed in fp32 so a half precision sum cannot overflow.
    """
    if shift:
        logits = logits[..., :-1, :]
        labels = labels[..., 1:]
    if mask is not None:
        keep = mask[:, -logits.shape[1]:].to(logits.device) != 0
        logits = logits[keep]
        labels = labels[keep.to(labels.device)]
    if vocab_size is None:
        vocab_size = logits.shape[-1]
    logits = logits.reshape(-1, vocab_size)
    labels = labels.reshape(-1).to(logits.device)
    if n_items is None:
        return torch.nn.functional.cross_entropy(logits, labels, ignore_index = ignore_index)
    loss = torch.nn.functional.cross_entropy(
        logits, labels, ignore_index = ignore_index, reduction = "none",
    ).float().sum()
    if torch.is_tensor(n_items):
        # A DataParallel replica gets a one-element slice of the repeated count: keep the loss 0-dim.
        n_items = n_items.to(loss.device)
        if n_items.ndim > 0: n_items = n_items.reshape(-1)[0]
    return loss / _nonzero_count(n_items)
pass


_LOSS_TAKES_COUNT = weakref.WeakKeyDictionary()

def _loss_takes_count(loss_function):
    # All Unsloth Zoo code licensed under LGPLv3
    # Module.__call__ is (*args, **kwargs), so read forward; keyed on the function to hold no module alive.
    target = loss_function.forward if isinstance(loss_function, torch.nn.Module) else loss_function
    key = getattr(target, "__func__", target)
    try:
        return _LOSS_TAKES_COUNT[key]
    except (KeyError, TypeError):
        pass
    try:
        parameters = inspect.signature(target).parameters.values()
        takes = any(
            p.kind == inspect.Parameter.VAR_KEYWORD
            or (p.name == "num_items_in_batch" and p.kind != inspect.Parameter.POSITIONAL_ONLY)
            for p in parameters
        )
    except Exception:
        takes = False
    try:
        _LOSS_TAKES_COUNT[key] = takes
    except TypeError:
        pass
    return takes
pass


def unsloth_loss_count_kwargs(loss_function, n_items):
    # All Unsloth Zoo code licensed under LGPLv3
    """`{"num_items_in_batch": n_items}`, or {} without a count or for a loss that cannot take it."""
    if n_items is None or not _loss_takes_count(loss_function):
        return {}
    return {"num_items_in_batch": n_items}
pass

# Unsloth Zoo - Utilities for Unsloth
# Copyright 2023-present Daniel Han-Chen, Michael Han-Chen & the Unsloth team. All rights reserved.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
